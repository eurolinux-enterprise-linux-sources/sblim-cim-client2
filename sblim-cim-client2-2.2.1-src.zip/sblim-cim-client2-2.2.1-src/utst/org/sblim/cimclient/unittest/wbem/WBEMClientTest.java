/**
 * (C) Copyright IBM Corp. 2012
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Alexander Wolf-Reber, IBM, a.wolf-reber@de.ibm.com
 *           Dave Blaschke, IBM, blaschke@us.ibm.com
 * 
 * Change History
 * Flag       Date        Prog         Description
 *------------------------------------------------------------------------------- 
 * 3522904    2012-05-02  blaschke-oss Add new API WBEMClientSBLIM.isActive()
 */

package org.sblim.cimclient.unittest.wbem;

import javax.cim.CIMObjectPath;
import javax.security.auth.Subject;
import javax.wbem.client.WBEMClientConstants;
import javax.wbem.client.WBEMClientFactory;

import org.sblim.cimclient.WBEMClientSBLIM;
import org.sblim.cimclient.unittest.TestCase;

/**
 * Class WBEMClientTest is responsible to test the WBEMClient(SBLIM) class.
 */
public class WBEMClientTest extends TestCase {

	/**
	 * Tests if the settings are picked up by the client
	 * 
	 * @throws Exception
	 */
	public void testClientIsActive() throws Exception {
		WBEMClientSBLIM client = (WBEMClientSBLIM) WBEMClientFactory
				.getClient(WBEMClientConstants.PROTOCOL_CIMXML);
		boolean isActive = client.isActive();
		verify("Client active before initialization!", isActive == false);
		client.initialize(new CIMObjectPath("https", "127.0.0.1", "5989", "root", null, null),
				new Subject(), null);
		isActive = client.isActive();
		verify("Client not active after initialization!", isActive == true);
		client.close();
		isActive = client.isActive();
		verify("Client active after close!", isActive == false);
	}
}
