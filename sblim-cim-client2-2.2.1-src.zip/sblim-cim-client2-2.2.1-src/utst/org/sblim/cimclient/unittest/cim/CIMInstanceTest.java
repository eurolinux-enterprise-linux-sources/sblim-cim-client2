/**
 * (C) Copyright IBM Corp. 2006, 2012
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Endre Bak, ebak@de.ibm.com  
 * 
 * Flag       Date        Prog         Description
 * -------------------------------------------------------------------------------
 * 1776114    2007-08-21  ebak         Cannot derive instance of class CIM_IndicationSubscription
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2797550    2009-06-01  raman_arora  JSR48 compliance - add Java Generics
 * 3521119    2012-04-24  blaschke-oss JSR48 1.0.0: remove CIMObjectPath 2/3/4-parm ctors
 * 3529151    2012-08-22  blaschke-oss TCK: CIMInstance property APIs include keys from COP
 */

package org.sblim.cimclient.unittest.cim;

import javax.cim.CIMDataType;
import javax.cim.CIMInstance;
import javax.cim.CIMObjectPath;
import javax.cim.CIMProperty;

import org.sblim.cimclient.unittest.TestCase;

/**
 * Class CIMInstanceTest is responsible for testing CIMInstance.
 * 
 */
public class CIMInstanceTest extends TestCase {

	private static CIMProperty<Object> mkProp(String pName, Object pValue, boolean pKey,
			boolean pPropagated, String pOriginClass) {
		return new CIMProperty<Object>(pName, CIMDataType.getDataType(pValue), pValue, pKey,
				pPropagated, pOriginClass);
	}

	private static CIMProperty<Object> mkKey(String pName, Object pValue) {
		return mkProp(pName, pValue, true, false, null);
	}

	private static CIMProperty<CIMObjectPath> mkProp(String pName, String pRefClassName,
			CIMObjectPath pPath) {
		return new CIMProperty<CIMObjectPath>(pName, new CIMDataType(pRefClassName), pPath, false,
				false, null);
	}

	private static final CIMProperty<?>[] KEY_PROPS = { mkKey("StringProp", "Hello") };

	private static final CIMProperty<?>[] INST_PROPS = {
			mkKey("StringProp", "Hello"),
			mkProp("RefProp0", "BaseClass", new CIMObjectPath(null, null, null, "root/cimv2",
					"Clazz", new CIMProperty[] { mkKey("KeyProp", "ZzZzzz...") })) };

	private static final CIMProperty<?>[] DERIVED_PROPS = {
			mkKey("StringProp", "Hallo"),
			mkProp("RefProp0", "DerivedClass", new CIMObjectPath(null, null, null, "root/cimv2",
					"Clazz", new CIMProperty[] { mkKey("KeyProp", "ZzZzzz...") })) };

	private static final CIMInstance INST = new CIMInstance(new CIMObjectPath(null, null, null,
			"root/cimv2", "CIM_Anything", KEY_PROPS), INST_PROPS);

	private static final CIMInstance DERIVED_INST = new CIMInstance(new CIMObjectPath(null, null,
			null, "root/cimv2", "CIM_Anything", KEY_PROPS), DERIVED_PROPS);

	/**
	 * tests CIMInstance.deriveInstance(CIMProperty[])
	 */
	public void testDeriveInstanceProperties() {
		CIMInstance derived = INST.deriveInstance(DERIVED_PROPS);
		verify("Wrong deriveInstance() result! :\n" + derived + "\nExpected result is :\n"
				+ DERIVED_INST, DERIVED_INST.equals(derived));
	}

}
