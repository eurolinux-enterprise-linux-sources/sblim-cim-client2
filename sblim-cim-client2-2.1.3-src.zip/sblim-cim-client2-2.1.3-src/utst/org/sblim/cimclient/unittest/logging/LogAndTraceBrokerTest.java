/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Alexander Wolf-Reber, IBM, a.wolf-reber@de.ibm.com
 * 
 * Change History
 * Flag       Date        Prog         Description
 *------------------------------------------------------------------------------- 
 * 1565892    2006-11-23  lupusalex    Make SBLIM client JSR48 compliant
 * 1698278    2006-04-11  lupusalex    Unit tests fail on Hungarian locale
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2531371    2009-02-10  raman_arora  Upgrade client to JDK 1.5 (Phase 2) 
 */

package org.sblim.cimclient.unittest.logging;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;

import org.sblim.cimclient.LogListener;
import org.sblim.cimclient.TraceListener;
import org.sblim.cimclient.WBEMConfigurationProperties;
import org.sblim.cimclient.internal.logging.LogAndTraceBroker;
import org.sblim.cimclient.internal.logging.Messages;
import org.sblim.cimclient.unittest.TestCase;

/**
 * Class LogAndTraceBrokerTest is responsible to test the LogAndTraceBroker
 * 
 */
public class LogAndTraceBrokerTest extends TestCase {

	private static final String TEST = "TEST";

	/**
	 * SUPPORTED_LANGUAGES
	 * 
	 * @invariant The array must be sorted in ascending order
	 */
	protected static final String[] SUPPORTED_LANGUAGES = new String[] { "de", "en" };

	private int iLogMessages = 0;

	private int iTraceMessages = 0;

	// message, message, trace, trace, register internal listener

	/**
	 * Returns logMessages
	 * 
	 * @return The value of logMessages.
	 */
	public int getLogMessages() {
		return this.iLogMessages;
	}

	/**
	 * Sets logMessages
	 * 
	 * @param pLogMessages
	 *            The new value of logMessages.
	 */
	public void setLogMessages(int pLogMessages) {
		this.iLogMessages = pLogMessages;
	}

	/**
	 * Returns traceMessages
	 * 
	 * @return The value of traceMessages.
	 */
	public int getTraceMessages() {
		return this.iTraceMessages;
	}

	/**
	 * Sets traceMessages
	 * 
	 * @param pTraceMessages
	 *            The new value of traceMessages.
	 */
	public void setTraceMessages(int pTraceMessages) {
		this.iTraceMessages = pTraceMessages;
	}

	/**
	 * Tests if all three internal listeners come up correctly
	 */
	public void testInternalListeners() {

		LogAndTraceBroker broker = LogAndTraceBroker.getBroker();
		broker.clearLogListeners();
		broker.clearTraceListeners();

		System.setProperty(WBEMConfigurationProperties.LOG_CONSOLE_LEVEL, "SEVERE");
		System.setProperty(WBEMConfigurationProperties.LOG_FILE_LEVEL, "SEVERE");
		System.setProperty(WBEMConfigurationProperties.TRACE_FILE_LEVEL, "SEVERE");
		broker.registerInternalListeners();

		List<?> listeners = broker.getLogListeners();
		verify("Count of internal log listeners", EQUAL, new Integer(listeners.size()),
				new Integer(2));
		listeners = broker.getTraceListeners();
		verify("Count of internal trace listeners", EQUAL, new Integer(listeners.size()),
				new Integer(1));

		System.setProperty(WBEMConfigurationProperties.LOG_CONSOLE_LEVEL, "OFF");
		System.setProperty(WBEMConfigurationProperties.LOG_FILE_LEVEL, "OFF");
		System.setProperty(WBEMConfigurationProperties.TRACE_FILE_LEVEL, "OFF");
		broker.clearLogListeners();
		broker.clearTraceListeners();
	}

	/**
	 * Tests if a log message is forwarded correctly to the log&trace listeners
	 * This test checks the message level, locale, parameter.
	 */
	public void testMessage1() {
		LogAndTraceBroker broker = LogAndTraceBroker.getBroker();
		broker.clearLogListeners();
		broker.clearTraceListeners();

		broker.addLogListener(new LogListener() {

			/**
			 * @param pParameters
			 */
			public void log(Level pLevel, String pMessageKey, String pMessage, Object[] pParameters) {
				setLogMessages(getLogMessages() + 1);
				if (pMessageKey.equals(Messages.TEST_MESSAGE)) {
					verify("Message level", EQUAL, pLevel, Level.SEVERE);
					verify("Message param", EQUAL, pParameters[0], TEST);
					final String messageLanguage = pMessage.substring(0, 2);
					verifyLanguage(messageLanguage);
				}
			}
		});

		broker.addTraceListener(new TraceListener() {

			/**
			 * @param pLevel
			 * @param pOrigin
			 * @param pMessage
			 * @param pThrown
			 */
			public void trace(Level pLevel, StackTraceElement pOrigin, String pMessage,
					Throwable pThrown) {
				setTraceMessages(getTraceMessages() + 1);
			}

			public void trace(Level pLevel, StackTraceElement pOrigin, String pMessage) {
				setTraceMessages(getTraceMessages() + 1);
				if (pMessage.startsWith(Messages.TEST_MESSAGE)) {
					verify("Message level", EQUAL, pLevel, Level.SEVERE);
					verify("Message locale", EQUAL, pMessage.substring(Messages.TEST_MESSAGE
							.length() + 1, Messages.TEST_MESSAGE.length() + 3), Locale.ENGLISH
							.getLanguage());
					verify("Message param", EQUAL, pMessage.substring(Messages.TEST_MESSAGE
							.length() + 4), TEST);
					verify("Origin", EQUAL, pOrigin.getMethodName(), "testMessage1");
				}
			}
		});

		setLogMessages(0);
		setTraceMessages(0);
		broker.message(Messages.TEST_MESSAGE, TEST);
		verify("Message count logged", EQUAL, new Integer(getLogMessages()), new Integer(1));
		verify("Message count traced", EQUAL, new Integer(getTraceMessages()), new Integer(1));

		broker.clearLogListeners();
		broker.clearTraceListeners();
	}

	/**
	 * Tests if a log message is forwarded correctly to the log&trace listeners
	 * This test checks the message level, locale, exception parameter.
	 */
	public void testMessage2() {
		LogAndTraceBroker broker = LogAndTraceBroker.getBroker();
		broker.clearLogListeners();
		broker.clearTraceListeners();

		broker.addLogListener(new LogListener() {

			/**
			 * @param pParameters
			 */
			public void log(Level pLevel, String pMessageKey, String pMessage, Object[] pParameters) {
				setLogMessages(getLogMessages() + 1);
				if (pMessageKey.equals(Messages.TEST_MESSAGE)) {
					verify("Message level", EQUAL, pLevel, Level.SEVERE);
					final String messageLanguage = pMessage.substring(0, 2);
					verifyLanguage(messageLanguage);
				}
			}
		});

		broker.addTraceListener(new TraceListener() {

			public void trace(Level pLevel, StackTraceElement pOrigin, String pMessage,
					Throwable pThrown) {
				setTraceMessages(getTraceMessages() + 1);
				if (pMessage.startsWith(Messages.TEST_MESSAGE)) {
					verify("Message level", EQUAL, pLevel, Level.SEVERE);
					verify("Message locale", EQUAL, pMessage.substring(Messages.TEST_MESSAGE
							.length() + 1, Messages.TEST_MESSAGE.length() + 3), Locale.ENGLISH
							.getLanguage());
					verify("Message param", EQUAL, pThrown.getMessage(), TEST);
					verify("Origin", EQUAL, pOrigin.getMethodName(), "testMessage2");
				}
			}

			/**
			 * @param pLevel
			 * @param pOrigin
			 * @param pMessage
			 */
			public void trace(Level pLevel, StackTraceElement pOrigin, String pMessage) {
				setTraceMessages(getTraceMessages() + 1);
			}
		});

		setLogMessages(0);
		setTraceMessages(0);
		broker.message(Messages.TEST_MESSAGE, new RuntimeException(TEST));
		verify("Message count logged", EQUAL, new Integer(getLogMessages()), new Integer(1));
		verify("Message count traced", EQUAL, new Integer(getTraceMessages()), new Integer(1));

		broker.clearLogListeners();
		broker.clearTraceListeners();
	}

	/**
	 * Tests if a log message is forwarded correctly to the log&trace listeners
	 * This test checks the message level, locale, exception parameter.
	 */
	public void testTrace() {
		LogAndTraceBroker broker = LogAndTraceBroker.getBroker();
		broker.clearLogListeners();
		broker.clearTraceListeners();

		broker.addLogListener(new LogListener() {

			/**
			 * @param pLevel
			 * @param pMessageKey
			 * @param pMessage
			 * @param pParameters
			 */
			public void log(Level pLevel, String pMessageKey, String pMessage, Object[] pParameters) {
				setLogMessages(getLogMessages() + 1);
			}
		});

		broker.addTraceListener(new TraceListener() {

			public void trace(Level pLevel, StackTraceElement pOrigin, String pMessage,
					Throwable pThrown) {
				setTraceMessages(getTraceMessages() + 1);
				if (pMessage.startsWith(TEST)) {
					verify("Message level", EQUAL, pLevel, Level.FINE);
					verify("Message text", EQUAL, pMessage, TEST);
					verify("Message param", EQUAL, pThrown.getMessage(), TEST);
					verify("Origin", EQUAL, pOrigin.getMethodName(), "testTrace");
				}
			}

			public void trace(Level pLevel, StackTraceElement pOrigin, String pMessage) {
				setTraceMessages(getTraceMessages() + 1);
				if (pMessage.startsWith(TEST)) {
					verify("Message level", EQUAL, pLevel, Level.FINEST);
					verify("Message text", EQUAL, pMessage, TEST);
					verify("Origin", EQUAL, pOrigin.getMethodName(), "testTrace");
				}
			}
		});

		setLogMessages(0);
		setTraceMessages(0);
		broker.trace(Level.FINEST, TEST);
		broker.trace(Level.FINE, TEST, new RuntimeException(TEST));
		verify("Message count logged", EQUAL, new Integer(getLogMessages()), new Integer(0));
		verify("Message count traced", EQUAL, new Integer(getTraceMessages()), new Integer(2));

		broker.clearLogListeners();
		broker.clearTraceListeners();
	}

	protected void verifyLanguage(final String messageLanguage) {
		final String jvmLanguage = Locale.getDefault().getLanguage();
		if (Arrays.binarySearch(SUPPORTED_LANGUAGES, jvmLanguage) >= 0) {
			verify("Message locale", EQUAL, messageLanguage, jvmLanguage);
		} else {
			warning("Unsupported language: " + jvmLanguage);
			verify("Message locale", EQUAL, messageLanguage, Locale.ENGLISH.getLanguage());
		}
	}
}
