/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Endre Bak, ebak@de.ibm.com  
 * 
 * Flag       Date        Prog         Description
 * -------------------------------------------------------------------------------
 * 1776114    2007-08-21  ebak         Cannot derive instance of class CIM_IndicationSubscription
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2797550    2009-06-01  raman_arora  JSR48 compliance - add Java Generics
 */

package org.sblim.cimclient.unittest.cim;

import javax.cim.CIMDataType;
import javax.cim.CIMInstance;
import javax.cim.CIMObjectPath;
import javax.cim.CIMProperty;

import org.sblim.cimclient.unittest.TestCase;

/**
 * Class CIMInstanceTest is responsible for testing CIMInstance.
 * 
 */
public class CIMInstanceTest extends TestCase {

	private static CIMProperty<Object> mkProp(String pName, Object pValue, boolean pKey,
			boolean pPropagated, String pOriginClass) {
		return new CIMProperty<Object>(pName, CIMDataType.getDataType(pValue), pValue, pKey,
				pPropagated, pOriginClass);
	}

	private static CIMProperty<Object> mkProp(String pName, Object pValue) {
		return mkProp(pName, pValue, false, false, null);
	}

	private static CIMProperty<Object> mkKey(String pName, Object pValue) {
		return mkProp(pName, pValue, true, false, null);
	}

	private static CIMProperty<CIMObjectPath> mkProp(String pName, String pRefClassName,
			CIMObjectPath pPath) {
		return new CIMProperty<CIMObjectPath>(pName, new CIMDataType(pRefClassName), pPath, false,
				false, null);
	}

	private static final CIMProperty<?>[] INST_PROPS = {
			mkKey("StringProp", "Hello"),
			mkProp("RefProp0", "BaseClass", new CIMObjectPath("Clazz", "root/cimv2",
					new CIMProperty[] { mkProp("KeyProp", "ZzZzzz...") })) };

	private static final CIMProperty<?>[] DERIVED_PROPS = {
			mkKey("StringProp", "Hallo"),
			mkProp("RefProp0", "DerivedClass", new CIMObjectPath("Clazz", "root/cimv2",
					new CIMProperty[] { mkProp("KeyProp", "ZzZzzz...") })) };

	private static final CIMInstance INST = new CIMInstance(new CIMObjectPath("CIM_Anything",
			"root/cimv2", INST_PROPS), INST_PROPS);

	private static final CIMInstance DERIVED_INST = new CIMInstance(new CIMObjectPath(
			"CIM_Anything", "root/cimv2", DERIVED_PROPS), DERIVED_PROPS);

	/**
	 * tests CIMInstance.deriveInstance(CIMProperty[])
	 */
	public void testDeriveInstanceProperties() {
		CIMInstance derived = INST.deriveInstance(DERIVED_PROPS);
		verify("Wrong deriveInstance() result! :\n" + derived + "\nExpected result is :\n"
				+ DERIVED_INST, DERIVED_INST.equals(derived));
	}

}
