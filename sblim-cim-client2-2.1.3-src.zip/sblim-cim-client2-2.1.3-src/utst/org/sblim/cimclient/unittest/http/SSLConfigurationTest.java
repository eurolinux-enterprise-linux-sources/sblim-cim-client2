/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Alexander Wolf-Reber, IBM, a.wolf-reber@de.ibm.com
 * 
 * Change History
 * Flag       Date        Prog         Description
 *------------------------------------------------------------------------------- 
 * 1660743    2007-02-15  lupusalex    SSLContext is static
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 */
package org.sblim.cimclient.unittest.http;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.util.Properties;

import javax.net.ssl.SSLServerSocket;

import org.sblim.cimclient.WBEMConfigurationProperties;
import org.sblim.cimclient.internal.http.HttpSocketFactory;
import org.sblim.cimclient.internal.util.WBEMConfiguration;
import org.sblim.cimclient.unittest.TestCase;

/**
 * Class SSLConfigurationTest is responsible for testing the HTTP SSL
 * configuration. If keystore / truststore settings are not applied correctly
 * test from this class will fail.
 * 
 */
public class SSLConfigurationTest extends TestCase {

	private static final String HELLO_CLIENT = "Hello Client!";

	private static final String HELLO_SERVER = "Hello Server!";

	/**
	 * Tests basic SSL connection
	 * 
	 * @throws Exception
	 */
	public void testBasicConnect() throws Exception {
		warning("JSSE implementation: "
				+ WBEMConfiguration.getGlobalConfiguration().getSslSocketProvider());
		System.setProperty(WBEMConfigurationProperties.HTTP_TIMEOUT, "1000");
		URL keystore = getClass().getResource("keystore.pks");
		System.setProperty(WBEMConfigurationProperties.KEYSTORE_PATH, keystore.getFile());
		System.setProperty(WBEMConfigurationProperties.KEYSTORE_PASSWORD, "password");
		System.setProperty(WBEMConfigurationProperties.TRUSTSTORE_PATH, "");
		System.setProperty(WBEMConfigurationProperties.TRUSTSTORE_PASSWORD, "");
		connect(WBEMConfiguration.getGlobalConfiguration(), WBEMConfiguration
				.getGlobalConfiguration());
	}

	/**
	 * Test if the client correctly evaluates the authentication of the server.<br />
	 * Uses four keystores:
	 * 
	 * <em>keystore</em> and <em>stranger</em> contain a full private/public key
	 * each; <em>truststore</em> contains the public key from keystore;
	 * <em>notrust</em> is empty<br />
	 * 
	 * @throws Exception
	 */
	public void testClientTrust() throws Exception {
		System.setProperty(WBEMConfigurationProperties.HTTP_TIMEOUT, "1000");
		System.setProperty(WBEMConfigurationProperties.KEYSTORE_PATH, "");
		System.setProperty(WBEMConfigurationProperties.KEYSTORE_PASSWORD, "");
		System.setProperty(WBEMConfigurationProperties.TRUSTSTORE_PATH, "");
		System.setProperty(WBEMConfigurationProperties.TRUSTSTORE_PASSWORD, "");
		URL stranger = getClass().getResource("stranger.pks");
		URL keystore = getClass().getResource("keystore.pks");
		URL truststore = getClass().getResource("truststore.pks");
		URL notrust = getClass().getResource("notrust.pks");

		Properties clientConfiguration = new Properties();
		Properties serverConfiguration = new Properties();

		serverConfiguration.setProperty(WBEMConfigurationProperties.KEYSTORE_PATH, keystore
				.getFile());
		serverConfiguration.setProperty(WBEMConfigurationProperties.KEYSTORE_PASSWORD, "password");
		connect(new WBEMConfiguration(clientConfiguration), new WBEMConfiguration(
				serverConfiguration));

		clientConfiguration.setProperty(WBEMConfigurationProperties.TRUSTSTORE_PATH, truststore
				.getFile());
		clientConfiguration
				.setProperty(WBEMConfigurationProperties.TRUSTSTORE_PASSWORD, "password");
		connect(new WBEMConfiguration(clientConfiguration), new WBEMConfiguration(
				serverConfiguration));

		serverConfiguration.setProperty(WBEMConfigurationProperties.KEYSTORE_PATH, stranger
				.getFile());
		try {
			connect(new WBEMConfiguration(clientConfiguration), new WBEMConfiguration(
					serverConfiguration));
			fail("Connection established without trusted certificate (1)");
		} catch (Exception e) {
			warning("JSSE implementation throws " + e.getClass().getName()
					+ " on untrusted server certificate.");
		}

		try {
			serverConfiguration.setProperty(WBEMConfigurationProperties.KEYSTORE_PATH, "");
			connect(new WBEMConfiguration(clientConfiguration), new WBEMConfiguration(
					serverConfiguration));
			fail("Connection established without trusted certificate (2)");
		} catch (Exception e) {
			warning("JSSE implementation throws " + e.getClass().getName()
					+ " when server doesn't show a certificate.");
		}

		serverConfiguration.setProperty(WBEMConfigurationProperties.KEYSTORE_PATH, keystore
				.getFile());
		clientConfiguration.setProperty(WBEMConfigurationProperties.TRUSTSTORE_PATH, notrust
				.getFile());
		try {
			connect(new WBEMConfiguration(clientConfiguration), new WBEMConfiguration(
					serverConfiguration));
			fail("Connection established without trusted certificate (3)");
		} catch (Exception e) {
			warning("JSSE implementation throws " + e.getClass().getName()
					+ " when client's trust store is empty.");
		}
	}

	/**
	 * Test if the server correctly evaluates the authentication of the client.<br />
	 * Uses four keystores:
	 * 
	 * <em>keystore</em> and <em>stranger</em> contain a full private/public key
	 * each; <em>truststore</em> contains the public key from keystore;
	 * <em>notrust</em> is empty<br />
	 * 
	 * @throws Exception
	 */
	public void testServerTrust() throws Exception {
		System.setProperty(WBEMConfigurationProperties.HTTP_TIMEOUT, "1000");
		System.setProperty(WBEMConfigurationProperties.KEYSTORE_PATH, "");
		System.setProperty(WBEMConfigurationProperties.KEYSTORE_PASSWORD, "");
		System.setProperty(WBEMConfigurationProperties.TRUSTSTORE_PATH, "");
		System.setProperty(WBEMConfigurationProperties.TRUSTSTORE_PASSWORD, "");
		URL keystore = getClass().getResource("keystore.pks");
		URL stranger = getClass().getResource("stranger.pks");
		URL truststore = getClass().getResource("truststore.pks");
		URL notrust = getClass().getResource("notrust.pks");

		Properties clientConfiguration = new Properties();
		Properties serverConfiguration = new Properties();

		serverConfiguration.setProperty(WBEMConfigurationProperties.KEYSTORE_PATH, keystore
				.getFile());
		serverConfiguration.setProperty(WBEMConfigurationProperties.KEYSTORE_PASSWORD, "password");
		serverConfiguration.setProperty(WBEMConfigurationProperties.TRUSTSTORE_PATH, truststore
				.getFile());
		serverConfiguration
				.setProperty(WBEMConfigurationProperties.TRUSTSTORE_PASSWORD, "password");
		clientConfiguration.setProperty(WBEMConfigurationProperties.KEYSTORE_PATH, keystore
				.getFile());
		clientConfiguration.setProperty(WBEMConfigurationProperties.KEYSTORE_PASSWORD, "password");
		connect(new WBEMConfiguration(clientConfiguration), new WBEMConfiguration(
				serverConfiguration));

		clientConfiguration.setProperty(WBEMConfigurationProperties.KEYSTORE_PATH, stranger
				.getFile());
		try {
			connect(new WBEMConfiguration(clientConfiguration), new WBEMConfiguration(
					serverConfiguration));
			fail("Connection established without trusted certificate (1)");
		} catch (Exception e) {
			warning("JSSE implementation throws " + e.getClass().getName()
					+ " on untrusted client certificate.");
		}

		clientConfiguration.setProperty(WBEMConfigurationProperties.KEYSTORE_PATH, "");
		try {
			connect(new WBEMConfiguration(clientConfiguration), new WBEMConfiguration(
					serverConfiguration));
			fail("Connection established without trusted certificate (2)");
		} catch (Exception e) {
			warning("JSSE implementation throws " + e.getClass().getName()
					+ " when client doesn't show a certificate.");
		}

		clientConfiguration.setProperty(WBEMConfigurationProperties.KEYSTORE_PATH, keystore
				.getFile());
		serverConfiguration.setProperty(WBEMConfigurationProperties.TRUSTSTORE_PATH, notrust
				.getFile());
		try {
			connect(new WBEMConfiguration(clientConfiguration), new WBEMConfiguration(
					serverConfiguration));
			fail("Connection established without trusted certificate (3)");
		} catch (Exception e) {
			warning("JSSE implementation throws " + e.getClass().getName()
					+ " when server's trust store is empty.");
		}
	}

	/**
	 * Starts a server, creates a client connection and exchange greetings.
	 * 
	 * @param pClientConfiguration
	 *            The client configuration
	 * @param pServerConfiguration
	 *            The server configuration
	 * @throws Exception
	 */
	private void connect(WBEMConfiguration pClientConfiguration,
			WBEMConfiguration pServerConfiguration) throws Exception {

		int port = startServer(pServerConfiguration);

		Socket socket = HttpSocketFactory.getInstance().getClientSSLContext(pClientConfiguration)
				.getSocketFactory().createSocket("127.0.0.1", port);
		try {
			socket.setSoTimeout(1000);
			socket.getOutputStream().write(HELLO_SERVER.getBytes());
			socket.getOutputStream().flush();

			int read = 0;
			byte[] buffer = new byte[32];
			while (read <= 0) {
				read = socket.getInputStream().read(buffer);
			}
			verify("Message from server", EQUAL, new String(buffer, 0, read), HELLO_CLIENT);
		} finally {
			socket.close();
		}

	}

	/**
	 * Creates a server socket and starts a thread that listens on the socket.
	 * When a connection comes in, greeting are exchanged and the socket is
	 * closed.
	 * 
	 * @param pConfiguration
	 * @return The port of the server socket
	 * @throws IOException
	 */
	private int startServer(final WBEMConfiguration pConfiguration) throws IOException {
		final ServerSocket socket = HttpSocketFactory.getInstance().getServerSSLContext(
				pConfiguration).getServerSocketFactory().createServerSocket(0);

		if (socket instanceof SSLServerSocket && pConfiguration.getSslTrustStorePath() != null
				&& pConfiguration.getSslTrustStorePath().length() != 0) {
			((SSLServerSocket) socket).setNeedClientAuth(true);
		}
		Thread server = new Thread(new Runnable() {

			public void run() {
				while (true) {
					try {
						socket.setSoTimeout(1000);
						Socket connection = socket.accept();
						try {
							if (connection != null) {
								try {
									// System.out.println(((SSLSocket)
									// connection).getSession());
									int read = 0;
									byte[] buffer = new byte[32];
									while (read <= 0) {
										read = connection.getInputStream().read(buffer);
									}
									if (HELLO_SERVER.equals(new String(buffer, 0, read))) {
										connection.getOutputStream().write(HELLO_CLIENT.getBytes());
										connection.getOutputStream().flush();
									}
								} finally {
									connection.close();
								}
							}
							return;
						} finally {
							socket.close();
						}
					} catch (IOException e) {
						return;
					}
				}
			}
		});
		server.setDaemon(true);
		server.start();
		return socket.getLocalPort();
	}
}
