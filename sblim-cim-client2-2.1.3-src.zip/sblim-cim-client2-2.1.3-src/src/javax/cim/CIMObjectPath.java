/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Endre Bak, ebak@de.ibm.com  
 * 
 * Flag       Date        Prog         Description
 * -------------------------------------------------------------------------------
 * 1565892    2006-10-06  ebak         Make SBLIM client JSR48 compliant
 * 1669961    2006-04-16  lupusalex    CIMTypedElement.getType() =>getDataType()
 * 1716991    2006-05-11  lupusalex    FVT: CIMObjectPath.equals() should ignore host name
 * 1737141    2007-06-18  ebak         Sync up with JSR48 evolution
 * 1917321    2008-05-29  rgummada     javadoc update to constructors with 2 and more parms
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2763216    2009-04-14  blaschke-oss Code cleanup: visible spelling/grammar errors
 * 2797550    2009-06-01  raman_arora  JSR48 compliance - add Java Generics
 * 2845128    2009-09-24  blaschke-oss CIMObjectPath.toString() misses host
 */

package javax.cim;

import java.io.Serializable;
import java.util.Arrays;

import org.sblim.cimclient.internal.cim.CIMElementSorter;
import org.sblim.cimclient.internal.uri.BooleanValue;
import org.sblim.cimclient.internal.uri.CharValue;
import org.sblim.cimclient.internal.uri.DateTimeValue;
import org.sblim.cimclient.internal.uri.IntegerValue;
import org.sblim.cimclient.internal.uri.KeyValuePair;
import org.sblim.cimclient.internal.uri.KeyValuePairs;
import org.sblim.cimclient.internal.uri.RealValue;
import org.sblim.cimclient.internal.uri.ReferenceValue;
import org.sblim.cimclient.internal.uri.StringValue;
import org.sblim.cimclient.internal.uri.URI;
import org.sblim.cimclient.internal.uri.URIString;
import org.sblim.cimclient.internal.uri.Value;
import org.sblim.cimclient.internal.util.MOF;

/**
 * A <code>CIMObjectPath</code> is a reference to a specified CIM class, CIM
 * instance or CIM qualifier. It is only valid in context of an active
 * connection to a CIM object manager on a host. In order to uniquely identify a
 * given object on a host, a CIM object path includes the namespace, object name
 * and keys (if the object is an instance). The namespace is relative to the
 * namespace to which the <code>CIMClient</code> is currently connected. One or
 * more Key properties are used to uniquely identify an instance of a class. Key
 * properties are marked with the KEY qualifier.<br>
 * <br>
 * 
 * For example, the object path:<br>
 * <br>
 * <code>
 * http://myserver/root/cimv2:My_ComputerSystem.Name=mycomputer,
 * CreationClassName=My_ComputerSystem
 * </code><br>
 * <br>
 * has two parts:<br>
 * <br>
 * <ul type="disc"> <li> <code>http://myserver/root/cimv2</code>- Specifies the
 * <code>"root/cimv2"</code> namespace on the host <code>myserver</code>.</li>
 * <li>
 * <code>My_ComputerSystem.Name=mycomputer,CreationClassName=My_ComputerSystem
 * 		</code> - Specifies a <code>My_ComputerSystem</code> object which is
 * uniquely identified by two key properties and their corresponding values in
 * the format (key=value): <ul type="disc"> <li><code>Name=mycomputer</code></li>
 * <li><code>CreationClassName=My_ComputerSystem</code></li> </ul> </li> </ul>
 */
public class CIMObjectPath extends Object implements Serializable {

	private static final long serialVersionUID = 4593259690658425064L;

	private String iScheme, iHost, iPort, iNamespace, iObjectName;

	private CIMProperty<?>[] iKeys;

	/**
	 * Class TypeValuePair
	 */
	/**
	 * Class TypeValuePair is responsible for
	 * 
	 */
	private static class TypeValuePair {

		private CIMDataType iType;

		private Object iValue;

		/**
		 * Ctor.
		 * 
		 * @param pType
		 * @param pValue
		 */
		public TypeValuePair(CIMDataType pType, Object pValue) {
			this.iType = pType;
			this.iValue = pValue;
		}

		/**
		 * Ctor.
		 * 
		 * @param intVal
		 */
		public TypeValuePair(IntegerValue intVal) {
			if (intVal.isSigned()) {
				switch (intVal.getBitWidth()) {
					case 8:
						this.iType = CIMDataType.SINT8_T;
						this.iValue = new Byte(intVal.byteValue());
						break;
					case 16:
						this.iType = CIMDataType.SINT16_T;
						this.iValue = new Short(intVal.shortValue());
						break;
					case 32:
						this.iType = CIMDataType.SINT32_T;
						this.iValue = new Integer(intVal.intValue());
						break;
					default:
						this.iType = CIMDataType.SINT64_T;
						this.iValue = new Long(intVal.longValue());
				}

			} else { // unsigned integers
				switch (intVal.getBitWidth()) {
					case 8:
						this.iType = CIMDataType.UINT8_T;
						this.iValue = new UnsignedInteger8(intVal.shortValue());
						break;
					case 16:
						this.iType = CIMDataType.UINT16_T;
						this.iValue = new UnsignedInteger16(intVal.intValue());
						break;
					case 32:
						this.iType = CIMDataType.UINT32_T;
						this.iValue = new UnsignedInteger32(intVal.longValue());
						break;
					default:
						this.iType = CIMDataType.UINT64_T;
						this.iValue = new UnsignedInteger64(intVal.bigIntValue());
				}
			}
		}

		/**
		 * Ctor.
		 * 
		 * @param pRealVal
		 */
		public TypeValuePair(RealValue pRealVal) {
			// TODO: handle precision
			if (pRealVal.isDouble()) {
				this.iType = CIMDataType.REAL64_T;
				this.iValue = new Double(pRealVal.doubleValue());
			} else {
				this.iType = CIMDataType.REAL32_T;
				this.iValue = new Float(pRealVal.floatValue());
			}
		}

		/**
		 * @return CIMDataType
		 */
		public CIMDataType getType() {
			return this.iType;
		}

		/**
		 * @return Object
		 */
		public Object getValue() {
			return this.iValue;
		}

	}

	private CIMProperty<?>[] getKeysFromURI(URI pURI) {
		KeyValuePairs pairs = pURI.getKeyValuePairs();
		if (pairs == null) return null;
		CIMProperty<?>[] keys = new CIMProperty[pairs.size()];
		for (int i = 0; i < pairs.size(); i++) {
			KeyValuePair pair = (KeyValuePair) pairs.elementAt(i);
			String name = pair.getKey();
			Value uriVal = pair.getValue();
			TypeValuePair typeValue;
			if (uriVal instanceof StringValue) {
				typeValue = new TypeValuePair(CIMDataType.STRING_T, uriVal.toString());
			} else if (uriVal instanceof ReferenceValue) {
				ReferenceValue refVal = (ReferenceValue) uriVal;
				CIMObjectPath op = new CIMObjectPath(refVal.getRef());
				typeValue = new TypeValuePair(new CIMDataType(op.getObjectName()), op);
			} else if (uriVal instanceof BooleanValue) {
				typeValue = new TypeValuePair(CIMDataType.BOOLEAN_T, ((BooleanValue) uriVal)
						.getBoolean());
			} else if (uriVal instanceof CharValue) {
				typeValue = new TypeValuePair(CIMDataType.CHAR16_T, ((CharValue) uriVal)
						.getCharacter());
			} else if (uriVal instanceof IntegerValue) {
				typeValue = new TypeValuePair((IntegerValue) uriVal);
			} else if (uriVal instanceof RealValue) {
				typeValue = new TypeValuePair((RealValue) uriVal);
			} else if (uriVal instanceof DateTimeValue) {
				typeValue = new TypeValuePair(CIMDataType.DATETIME_T, ((DateTimeValue) uriVal)
						.getDateTime());
			} else {
				// TODO: error or warning tracing
				typeValue = new TypeValuePair(CIMDataType.INVALID_T, null);
			}
			keys[i] = new CIMProperty<Object>(name, typeValue.getType(), typeValue.getValue(),
					true, false, null);
		}
		return (CIMProperty[]) CIMElementSorter.sort(keys);
	}

	private void setURI(URI pURI) {
		this.iNamespace = pURI.getNamespaceName();
		this.iScheme = pURI.getNamespaceType();
		this.iHost = pURI.getHost();
		this.iPort = pURI.getPort();
		this.iObjectName = pURI.getClassName();
		this.iKeys = getKeysFromURI(pURI);
	}

	private CIMObjectPath(URI pURI) {
		setURI(pURI);
	}

	/**
	 * Constructs a CIM Object Path referencing a CIM element. The name can
	 * refer to a class name or a qualifier type name, depending on the
	 * particular CIM element identified. In order to refer to an instance, the
	 * key properties and their corresponding values must be set.<br>
	 * <br>
	 * Should be able to handle strings, like:<br>
	 * <code>
	 * http://myserver.org:5066/root/cimv2:My_ComputerSystem.Name="mycmp",CreationClassName="My_ComputerSystem"
	 * <br>
	 * http://myserver.org/root/cimv2:My_ComputerSystem.Name="mycmp",CreationClassName="My_ComputerSystem"
	 * <br>
	 * //myserver.org/root/cimv2:My_ComputerSystem<br>
	 * /root/cimv2:My_ComputerSystem
	 * </code>
	 * 
	 * @param pObjectPath
	 *            <p style="margin-left: 20px;"> The string representation of an
	 *            object path for a CIM element that which will be parsed and
	 *            used to initialize the object. </p>
	 */
	public CIMObjectPath(String pObjectPath) {
		URI uri;
		try {
			uri = URI.parse(pObjectPath);
		} catch (IllegalArgumentException asURI) {
			try {
				uri = URI.parseRef(new URIString(pObjectPath), false);
			} catch (IllegalArgumentException asUntypedRef) {
				try {
					uri = URI.parseRef(new URIString(pObjectPath), true);
				} catch (IllegalArgumentException asTypedRef) {
					String msg = "Parsing of ObjectPath string has failed!\n"
							+ "Nested error messages:\n" + "When parsing as normal URI string:\n"
							+ asURI.getMessage() + "When parsing as untyped reference:\n"
							+ asUntypedRef.getMessage() + "When parsing as typed reference:\n"
							+ asTypedRef.getMessage();
					// TODO: tracing
					throw new IllegalArgumentException(msg);
				}
			}
		}
		setURI(uri);
	}

	/**
	 * Constructs a CIM Object Path referencing a CIM element along in the
	 * specified namespace. The name can refer to a class name or a qualifier
	 * type name, depending on the particular CIM element identified. In order
	 * to refer to an instance, key properties and their corresponding values
	 * must be set. (Note: When using this API against Pegasus CIMOMs, do not
	 * provide the preceding '/' to the namespace parameter. For example,
	 * Pegasus will accept "root/cimv2" as a namespace but will not accept
	 * "/root/cimv2").
	 * 
	 * @param pElementName
	 *            - The name of a CIM element.
	 * @param pNamespace
	 *            - The namespace relative to the current namespace.
	 */
	public CIMObjectPath(String pElementName, String pNamespace) {
		this(pElementName, pNamespace, null);
	}

	/**
	 * Constructs a CIM Object Path referencing an instance of the specified CIM
	 * element as defined in the specified namespace and identified by the given
	 * key properties and their corresponding values. (Note: When using this API
	 * against Pegasus CIMOMs, do not provide the preceding '/' to the namespace
	 * parameter. For example, Pegasus will accept "root/cimv2" as a namespace
	 * but will not accept "/root/cimv2").
	 * 
	 * @param pObjectName
	 *            - The name of the CIM element referenced.
	 * @param pNamespace
	 *            - The namespace in which the CIM element is defined.
	 * @param pKeys
	 *            - <code>CIMProperty[]</code> The keys and their corresponding
	 *            values that identify an instance of the CIM element.
	 */
	public CIMObjectPath(String pObjectName, String pNamespace, CIMProperty<?>[] pKeys) {
		this(null, pNamespace, pObjectName, pKeys);
	}

	/**
	 * Constructs a CIM Object Path referencing an instance of the specified CIM
	 * element as defined in the specified namespace on the specified host and
	 * identified by the given key properties and their corresponding values.
	 * (Note: When using this API against Pegasus CIMOMs, do not provide the
	 * preceding '/' to the namespace parameter. For example, Pegasus will
	 * accept "root/cimv2" as a namespace but will not accept "/root/cimv2").
	 * 
	 * @param pHost
	 *            - The host name or IP Address.
	 * @param pNamespace
	 *            - The namepace in which the CIM element is defined.
	 * @param pObjectName
	 *            - The name of the CIM element referenced.
	 * @param pKeys
	 *            - <code>CIMProperty[]</code> The keys and their corresponding
	 *            values that identify an instance of the CIM element.
	 */
	public CIMObjectPath(String pHost, String pNamespace, String pObjectName, CIMProperty<?>[] pKeys) {
		this(null, pHost, null, pNamespace, pObjectName, pKeys);
	}

	/**
	 * Constructs a CIM Object Path referencing an instance of the specified CIM
	 * element as defined in the specified namespace on the specified host and
	 * identified by the given key properties and their corresponding values.
	 * Note that the connection mechanism and the port number to which a client
	 * connection is established are also specified. (Note: When using this API
	 * against Pegasus CIMOMs, do not provide the preceding '/' to the namespace
	 * parameter. For example, Pegasus will accept "root/cimv2" as a namespace
	 * but will not accept "/root/cimv2").
	 * 
	 * @param pScheme
	 *            - The connection scheme to the host (e.g. http, https, ...)
	 * @param pHost
	 *            - The host name or IP Address.
	 * @param pPort
	 *            - The port on the host to which the connection was established
	 * @param pNamespace
	 *            - The namepace in which the CIM element is defined.
	 * @param pObjectName
	 *            - The name of the CIM element referenced.
	 * @param pKeys
	 *            - <code>CIMProperty[]</code> The keys and their corresponding
	 *            values that identify an instance of the CIM element.
	 */
	public CIMObjectPath(String pScheme, String pHost, String pPort, String pNamespace,
			String pObjectName, CIMProperty<?>[] pKeys) {
		this.iScheme = pScheme;
		this.iHost = pHost;
		this.iPort = pPort;
		this.iNamespace = pNamespace;
		this.iObjectName = pObjectName;
		this.iKeys = (CIMProperty[]) CIMElementSorter.sort(pKeys);
	}

	/**
	 * Constructs a CIM Object Path referencing an instance of the specified CIM
	 * element as defined in the specified namespace on the specified host and
	 * identified by the given key properties and their corresponding values.
	 * Note that the connection mechanism and the port number to which a client
	 * connection is established are also specified. (Note: When using this API
	 * against Pegasus CIMOMs, do not provide the preceding '/' to the namespace
	 * parameter. For example, Pegasus will accept "root/cimv2" as a namespace
	 * but will not accept "/root/cimv2").
	 * 
	 * @param pScheme
	 *            The connection scheme to the host (e.g. http, https, ...)
	 * @param pHost
	 *            The host name or IP Address.
	 * @param pPort
	 *            The port on the host to which the connection was established.
	 * @param pNamespace
	 *            The namepace in which the CIM element is defined.
	 * @param pObjectName
	 *            The name of the CIM element referenced.
	 * @param pKeys
	 *            <code>CIMProperty[]</code> The keys and their corresponding
	 *            values that identify an instance of the CIM element.
	 * @param pXmlSchemaName
	 *            The name of the XML Schema for this object. This is only
	 *            needed for protocols that require this information.
	 */
	public CIMObjectPath(String pScheme, String pHost, String pPort, String pNamespace,
			String pObjectName, CIMProperty<?>[] pKeys, String pXmlSchemaName) {
		this(pScheme, pHost, pPort, pNamespace, pObjectName, pKeys);
	}

	/**
	 * Compares this CIM object path with the specified CIM object path for
	 * equality.
	 * 
	 * @param pObj
	 *            - The object to compare to this CIM object path. Only the
	 *            model paths are compared.
	 * @return <code>true</code> if the specified path references the same
	 *         object, otherwise <code>false</code> is returned.
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object pObj) {
		if (!(pObj instanceof CIMObjectPath)) return false;
		CIMObjectPath that = (CIMObjectPath) pObj;
		// hostname information is not any longer part of the comparison, since
		// there is no reliable way to attach hostnames
		return (this.iNamespace == null ? that.iNamespace == null : this.iNamespace
				.equalsIgnoreCase(that.iNamespace))
				&& (this.iObjectName == null ? that.iObjectName == null : this.iObjectName
						.equalsIgnoreCase(that.iObjectName)) && keysEqual(that);
	}

	/**
	 * CIMProperty.equals() shouldn't be used for keys, because the XML doesn't
	 * contain originClass and propagated information
	 */
	private boolean keysEqual(CIMObjectPath pThat) {
		if (pThat == this) return true;
		if (this.iKeys == null) return pThat.iKeys == null;
		if (pThat.iKeys == null) return false;
		if (this.iKeys.length != pThat.iKeys.length) return false;
		for (int i = 0; i < this.iKeys.length; i++) {
			CIMProperty<?> thisKey = this.iKeys[i], thatKey = pThat.iKeys[i];
			if (!equals(thisKey, thatKey)) { return false; }
		}
		return true;
	}

	private boolean equals(CIMProperty<?> pThis, CIMProperty<?> pThat) {
		if (pThis.getDataType() != null && pThis.getDataType().isArray()) { return ncEqualsIC(pThis
				.getName(), pThat.getName())
				&& ncEquals(pThis.getDataType(), pThat.getDataType())
				&& Arrays.equals((Object[]) pThis.getValue(), (Object[]) pThat.getValue());

		}
		return ncEqualsIC(pThis.getName(), pThat.getName())
				&& ncEquals(pThis.getDataType(), pThat.getDataType())
				&& ncEquals(pThis.getValue(), pThat.getValue());
	}

	private boolean ncEquals(Object pThis, Object pThat) {
		return pThis == null ? pThat == null : pThis.equals(pThat);
	}

	private boolean ncEqualsIC(String pThis, String pThat) {
		return pThis == null ? pThat == null : pThis.equalsIgnoreCase(pThat);
	}

	/**
	 * @param pModelPath
	 * @return boolean
	 */
	public boolean equalsModelPath(CIMObjectPath pModelPath) {
		// FIXME: what should this function do?
		return equals(pModelPath);
	}

	/**
	 * Gets the host.
	 * 
	 * @return The name of the host.
	 */
	public String getHost() {
		return this.iHost;
	}

	/**
	 * Gets a key property by name.
	 * 
	 * @param pName
	 *            - The name of the key property to retrieve.
	 * @return The <code>CIMProperty</code> with the given name, or
	 *         <code>null</code> if it is not found.
	 */
	public CIMProperty<?> getKey(String pName) {
		return (CIMProperty<?>) CIMElementSorter.find(this.iKeys, pName);
	}

	/**
	 * Gets all key properties.
	 * 
	 * @return The container of key properties.
	 */
	public CIMProperty<?>[] getKeys() {
		return this.iKeys == null ? new CIMProperty[0] : this.iKeys;
	}

	/**
	 * Gets the namespace.
	 * 
	 * @return The name of the namespace.
	 */
	public String getNamespace() {
		return this.iNamespace;
	}

	/**
	 * Gets the object name. Depending on the type of CIM element referenced,
	 * this may be either a class name or a qualifier type name.
	 * 
	 * @return The name of this CIM element.
	 */
	public String getObjectName() {
		return this.iObjectName;
	}

	/**
	 * Gets the the port on the host to which the connection was established.
	 * 
	 * @return The port on the host.
	 */
	public String getPort() {
		return this.iPort;
	}

	/**
	 * Get the connection scheme.
	 * 
	 * @return The connection scheme (e.g. http, https,...)
	 */
	public String getScheme() {
		return this.iScheme;
	}

	/**
	 * Computes the hash code for this object path.
	 * 
	 * @return The integer representing the hash code for this object path.
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	/**
	 * Returns a <code>String</code> representation of the CIM object path. This
	 * method is intended to be used only for debugging purposes. The format of
	 * the value returned may vary between implementations. The string returned
	 * may be empty but may not be <code>null</code>.
	 * 
	 * @return A string representation of this CIM object path.
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return MOF.objectHandle(this, false, true);
	}

}
