/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Endre Bak, ebak@de.ibm.com  
 * 
 * Flag       Date        Prog         Description
 * -------------------------------------------------------------------------------
 * 1565892    2006-10-06  ebak         Make SBLIM client JSR48 compliant
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2750520    2009-04-10  blaschke-oss Code cleanup from empty statement et al
 * 2797550    2009-06-01  raman_arora  JSR48 compliance - add Java Generics
 */

package javax.cim;

import org.sblim.cimclient.internal.util.MOF;

/**
 * The <code>CIMQualifierType</code> class represents a CIM Qualifier Type as an
 * object. A Qualifier Type supplies a type for a qualifier. A qualifier must
 * have a qualifier type. An Object of type <code>CIMQualifierType</code>
 * contains the following:
 * <ul>
 * <li><code>Name</code> - The name of the qualifier type.</li>
 * <li><code>Data Type</code> - The data type of the qualifier type.</li>
 * <li><code>Value</code> - The default value of the qualifier type (can be
 * <code>null</code>/uninitialized)</li>
 * <li><code>Scopes</code> - The scopes applicable to this qualifier type. In
 * other words what CIM Elements can this qualifiers based on this type be
 * applied to.</li>
 * <li><code>Flavors</code> - The flavors applicable to this qualifier type.
 * Flavors describe the propagation and override rules for a qualifier. CIM
 * Qualifier Types are defined in the CIM Infrastructure Specification. The
 * specification is available from the DMTF (Distributed Management Task Force)
 * at <code>http://dmtf.org/</code>.</li>
 * </ul>
 * 
 * @param <E>
 *            : Type Parameter
 */
public class CIMQualifierType<E> extends CIMValuedElement<E> implements CIMNamedElementInterface {

	private static final long serialVersionUID = -4563643521754840535L;

	private CIMObjectPath iObjPath;

	private int iScope, iFlavor;

	/**
	 * Constructs a new CIM qualifier type, using the name, type of the
	 * specified CIM qualifier type.
	 * 
	 * @param pPath
	 *            - The <code>CIMObjectPath</code> of a CIM qualifier type.
	 * @param pType
	 *            - The <code>CIMDataType</code> of the qualifier type.
	 * @param pValue
	 *            - The default value or <code>null</code> if no default value.
	 * @param pScope
	 *            - The applicable scopes for the qualifier type.
	 * @param pFlavor
	 *            - The applicable flavors for the qualifier type.
	 * @throws IllegalArgumentException
	 *             - If the value/data type does not match
	 */
	public CIMQualifierType(CIMObjectPath pPath, CIMDataType pType, E pValue, int pScope,
			int pFlavor) throws IllegalArgumentException {
		super(pPath.getObjectName(), pType, pValue);
		this.iObjPath = pPath;
		this.iScope = pScope;
		this.iFlavor = pFlavor;
	}

	/**
	 * Compares this object against the specified object. The result is
	 * <code>true</code> if and only if the argument is not <code>null</code>
	 * and is a <code>CIMQualifierType</code> object that represents the same
	 * value as this object.
	 * 
	 * @param pObj
	 *            - The object to compare.
	 * @return <code>true</code> if the specified object it is the same as this
	 *         <code>CIMQualifierType</code>. Otherwise, <code>false</code>.
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object pObj) {
		if (!(pObj instanceof CIMQualifierType)) return false;
		if (!super.equals(pObj)) return false;
		CIMQualifierType<?> that = (CIMQualifierType<?>) pObj;
		return this.iObjPath.equals(that.iObjPath) && this.iScope == that.iScope;
	}

	/**
	 * Returns the flavors of this qualifier type as a <code>BitSet</code>.
	 * 
	 * @return <code>BitSet</code> of flavors for this qualifier type.
	 */
	public int getFlavor() {
		return this.iFlavor;
	}

	/**
	 * @see javax.cim.CIMNamedElementInterface#getObjectPath()
	 */
	public CIMObjectPath getObjectPath() {
		return this.iObjPath;
	}

	/**
	 * Returns the scopes of this qualifier type as a bit set.
	 * 
	 * @return Bit set of CIM element scopes for which this qualifier type is
	 *         applicable.
	 */
	public int getScope() {
		return this.iScope;
	}

	/**
	 * Returns a <code>String</code> representation of the
	 * <code>CIMQualifierType</code> This method is intended to be used only for
	 * debugging purposes, and the format of the returned string may vary
	 * between implementations. The returned string may be empty but <b>may not
	 * be <code>null</code></b>.
	 * 
	 * @return A string representation of this qualifier type.
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return MOF.qualifierDeclaration(this);
	}

}
