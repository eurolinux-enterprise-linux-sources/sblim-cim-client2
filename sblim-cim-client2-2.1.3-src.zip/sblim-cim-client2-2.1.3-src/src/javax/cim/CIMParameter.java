/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Endre Bak, ebak@de.ibm.com  
 * 
 * Flag       Date        Prog         Description
 * -------------------------------------------------------------------------------
 * 1565892    2006-10-06  ebak         Make SBLIM client JSR48 compliant
 * 1660756    2007-02-22  ebak         Embedded object support
 * 1737141    2007-06-19  ebak         Sync up with JSR48 evolution
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2750520    2009-04-10  blaschke-oss Code cleanup from empty statement et al
 * 2797550    2009-06-01  raman_arora  JSR48 compliance - add Java Generics
 */

package javax.cim;

import org.sblim.cimclient.internal.cim.CIMQualifiedElementInterfaceImpl;
import org.sblim.cimclient.internal.util.MOF;

/**
 * The <code>CIMParameter</code> class wraps a CIM parameter that is used to
 * define an input, output or input/output parameter to a CIM method. A
 * <code>CIMParameter</code> object consists of a name, data type and a list of
 * qualifiers. NOTE: Parameters do not have values - so you can not set a
 * default value. CIM Parameters are defined in the CIM Infrastructure
 * Specification. The specification is available from the DMTF (Distributed
 * Management Task Force) at http://dmtf.org/.
 * 
 * @param <E>
 *            : Type Parameter
 * 
 * @see CIMMethod
 */
public class CIMParameter<E> extends CIMTypedElement implements CIMQualifiedElementInterface {

	private static final long serialVersionUID = -4741931597423829396L;

	private CIMQualifiedElementInterfaceImpl iQualiImpl;

	/**
	 * Constructs a <code>CIMParameter</code> object using the specified name,
	 * data type and qualifiers. Takes a string for the name of an existing CIM
	 * parameter and creates a new instance of a CIM parameter, using the name
	 * and identifier of the existing CIM parameter.
	 * 
	 * @param pName
	 *            - name of this parameter
	 * @param pType
	 *            - data type of this parameter
	 * @param pQualifiers
	 *            - qualifiers for this parameter
	 */
	public CIMParameter(String pName, CIMDataType pType, CIMQualifier<?>[] pQualifiers) {
		super(pName, pType);
		this.iQualiImpl = new CIMQualifiedElementInterfaceImpl(pQualifiers, false, true);
	}

	/**
	 * @see javax.cim.CIMTypedElement#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object pObj) {
		if (!(pObj instanceof CIMParameter)) return false;
		if (!super.equals(pObj)) return false;
		CIMParameter<?> that = (CIMParameter<?>) pObj;
		return this.iQualiImpl.equals(that.iQualiImpl);
	}

	/**
	 * Returns a CIMParameter filtered as specified.
	 * 
	 * @param pIncludeQualifiers
	 *            If true all qualifiers are returned; otherwise no qualifiers.
	 * @param pLocalOnly
	 *            If true only the qualifiers that were not propagated will be
	 *            included.
	 * @return A filtered CIMParameter.
	 */
	public CIMParameter<E> filter(boolean pIncludeQualifiers, boolean pLocalOnly) {
		return new CIMParameter<E>(getName(), getDataType(), pIncludeQualifiers ? this.iQualiImpl
				.getQualifiers(pLocalOnly) : null);
	}

	/**
	 * @see javax.cim.CIMQualifiedElementInterface#getQualifier(int)
	 */
	public CIMQualifier<?> getQualifier(int pIndex) {
		return this.iQualiImpl.getQualifier(pIndex);
	}

	/**
	 * @see javax.cim.CIMQualifiedElementInterface#getQualifier(java.lang.String)
	 */
	public CIMQualifier<?> getQualifier(String pName) {
		return this.iQualiImpl.getQualifier(pName);
	}

	/**
	 * @see javax.cim.CIMQualifiedElementInterface#getQualifierValue(java.lang.String)
	 */
	public Object getQualifierValue(String pName) {
		return this.iQualiImpl.getQualifierValue(pName);
	}

	/**
	 * @see javax.cim.CIMQualifiedElementInterface#getQualifierCount()
	 */
	public int getQualifierCount() {
		return this.iQualiImpl.getQualifierCount();
	}

	/**
	 * @see javax.cim.CIMQualifiedElementInterface#getQualifiers()
	 */
	public CIMQualifier<?>[] getQualifiers() {
		return this.iQualiImpl.getQualifiers();
	}

	/**
	 * @see javax.cim.CIMQualifiedElementInterface#hasQualifier(java.lang.String)
	 */
	public boolean hasQualifier(String pName) {
		return this.iQualiImpl.hasQualifier(pName);
	}

	/**
	 * @see javax.cim.CIMQualifiedElementInterface#hasQualifierValue(java.lang.String,
	 *      java.lang.Object)
	 */
	public boolean hasQualifierValue(String pName, Object pValue) {
		return this.iQualiImpl.hasQualifierValue(pName, pValue);
	}

	/**
	 * Returns a <code>String</code> representation of the
	 * <code>CIMParameter</code>. This method is intended to be used only for
	 * debugging purposes, and the format of the returned string may vary
	 * between implementations. The returned string may be empty but may not be
	 * <code>null</code>.
	 * 
	 * @return string representation of this parameter
	 */
	@Override
	public String toString() {
		return MOF.parameter(this, MOF.EMPTY);
	}

}
