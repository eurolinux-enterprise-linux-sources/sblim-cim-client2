/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Endre Bak, ebak@de.ibm.com  
 * 
 * Flag       Date        Prog         Description
 * -------------------------------------------------------------------------------
 * 1565892    2006-10-06  ebak         Make SBLIM client JSR48 compliant
 * 1737141    2007-06-18  ebak         Sync up with JSR48 evolution
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2750520    2009-04-10  blaschke-oss Code cleanup from empty statement et al
 * 2763216    2009-04-14  blaschke-oss Code cleanup: visible spelling/grammar errors
 * 2797550    2009-06-01  raman_arora  JSR48 compliance - add Java Generics
 */

package javax.cim;

import org.sblim.cimclient.internal.util.MOF;

/**
 * The <code>CIMProperty</code> class wraps the value of a CIM Property. A CIM
 * Property Object consists of a name, data type and value. The CIM Property
 * object also includes a flag to signify whether the property is a key property
 * (used as part of the name of the CIM element), a flag to signify whether it
 * was propagated from a parent class (or default value) and the class origin
 * information (where the property was originally defined or last overridden). A
 * CIM Property is defined in the CIM Infrastructure Specification. The
 * specification is available from the DMTF (Distributed Management Task Force)
 * at http://dmtf.org/.
 * 
 * @param <E>
 *            : Type Parameter
 */
public class CIMProperty<E> extends CIMValuedElement<E> {

	private static final long serialVersionUID = -4741931597423829396L;

	private boolean iKey, iPropagated;

	private String iOriginClass;

	/**
	 * Constructs a CIMProperty to be used in instances. For a CIMClass
	 * CIMClassProperty should be used. This can only be used for non-Key
	 * properties, non-propagated properties and when the the origin class is
	 * not needed.
	 * 
	 * @param pName
	 *            - The name of the property.
	 * @param pType
	 *            - The CIMDataType of the property.
	 * @param pValue
	 *            - The value of the property.
	 */
	public CIMProperty(String pName, CIMDataType pType, E pValue) {
		this(pName, pType, pValue, false, false, null);
	}

	/**
	 * Constructs a <code>CIMProperty</code> to be used in instances. For a
	 * <code>CIMClass CIMClassProperty</code> should be used.
	 * 
	 * @param pName
	 *            - The name of the property.
	 * @param pType
	 *            - The <code>CIMDataType</code> of the property.
	 * @param pValue
	 *            - The value of the property.
	 * @param pKey
	 *            - <code>true</code> if the property is a key; otherwise
	 *            <code>false</code>.
	 * @param pPropagated
	 *            - <code>true</code> if the value was propagated from the
	 *            class.
	 * @param pOriginClass
	 *            - The class in which this property was defined or overridden.
	 */
	public CIMProperty(String pName, CIMDataType pType, E pValue, boolean pKey,
			boolean pPropagated, String pOriginClass) {
		super(pName, pType, pValue);
		this.iKey = pKey;
		this.iPropagated = pPropagated;
		this.iOriginClass = pOriginClass;
	}

	/**
	 * Returns the class or instance in which this property was defined.
	 * 
	 * @return Name of class where this property was defined.
	 */
	public String getOriginClass() {
		return this.iOriginClass;
	}

	/**
	 * Convenience method for determining if this property is a Key.
	 * 
	 * @return <code>true</code> if this property is a key.
	 */
	public boolean isKey() {
		return this.iKey;
	}

	/**
	 * Determines if this property is Propagated. When this property is part of
	 * a class, this value designates that the class origin value is the same as
	 * the class name. For an instance, this designates if the value of this
	 * property was inherited from the class or if it was set as part of this
	 * instance.
	 * 
	 * @return <code>true</code> if this property is propagated.
	 */
	public boolean isPropagated() {
		return this.iPropagated;
	}

	/**
	 * Compares this object against the specified object. The result is
	 * <code>true</code> if and only if the argument is not <code>null</code>
	 * and is a <code>CIMValuedObject</code> that represents the same name, type
	 * and value as this object.
	 * 
	 * @param pObj
	 *            - the object to compare with.
	 * @return <code>true</code> if the objects are the same; <code>false</code>
	 *         otherwise.
	 */
	@Override
	public boolean equals(Object pObj) {
		if (!(pObj instanceof CIMProperty)) return false;
		if (!super.equals(pObj)) return false;
		CIMProperty<?> that = (CIMProperty<?>) pObj;
		return this.iKey == that.iKey
				&& this.iPropagated == that.iPropagated
				&& (this.iOriginClass == null ? that.iOriginClass == null : this.iOriginClass
						.equalsIgnoreCase(that.iOriginClass));
	}

	/**
	 * Returns a <code>String</code> representation of the
	 * <code>CIMElement</code> This method is intended to be used only for
	 * debugging purposes, and the format of the returned string may vary
	 * between implementations. The returned string may be empty but may not be
	 * <code>null</code>.
	 * 
	 * @return string representation of this element.
	 */
	@Override
	public String toString() {
		return MOF.propertyDeclaration(this, MOF.EMPTY);
	}

}
