/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Endre Bak, ebak@de.ibm.com  
 * 
 * Flag       Date        Prog         Description
 * -------------------------------------------------------------------------------
 * 1565892    2006-10-09  ebak         Make SBLIM client JSR48 compliant
 * 1737123    2007-06-15  ebak         Differences to JSR48 public review draft
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2531371    2009-02-10  raman_arora  Upgrade client to JDK 1.5 (Phase 2)
 * 2750520    2009-04-10  blaschke-oss Code cleanup from empty statement et al
 * 2795671    2009-05-22  raman_arora  Add Type to Comparable <T>
 */

package javax.cim;

/**
 * The <code>UnsignedInteger8</code> class wraps the value of an uint8. This
 * class was created to represent an uint8 data type as defined by the CIM
 * Infrastructure Specification. The specification is available from the DMTF
 * (Distributed Management Task Force) at http://dmtf.org/
 */
public class UnsignedInteger8 extends Number implements Comparable<UnsignedInteger8> {

	private static final long serialVersionUID = 4392496278679167896L;

	/**
	 * The maximum possible value for an <code>UnsignedInteger8</code>.
	 */
	public static final short MAX_VALUE = 255;

	/**
	 * The minimum possible value for an <code>UnsignedInteger8</code>.
	 */
	public static final short MIN_VALUE = 0;

	private short iValue;

	/**
	 * Constructs an unsigned 8-bit integer object for the specified short
	 * value. Only the lower 8 bits are considered.
	 * 
	 * @param pValue
	 *            - the short to be represented as an unsigned 8-bit integer
	 *            object.
	 * @throws NumberFormatException
	 *             - if the number is out of range.
	 */
	public UnsignedInteger8(short pValue) throws NumberFormatException {
		if (pValue > MAX_VALUE || pValue < MIN_VALUE) {
			String msg = "uint8:" + pValue + " is out of range!";
			throw new NumberFormatException(msg);
		}
		this.iValue = pValue;
	}

	/**
	 * Constructs an unsigned 8-bit integer object for the specified string.
	 * Only the lower 8 bits are considered.
	 * 
	 * @param pValue
	 *            - the string to be represented as an unsigned 8-bit integer.
	 * @throws NumberFormatException
	 *             - if the number is out of range.
	 */
	public UnsignedInteger8(String pValue) throws NumberFormatException {
		this.iValue = Short.parseShort(pValue);
		if (this.iValue > MAX_VALUE || this.iValue < MIN_VALUE) {
			String msg = "uint8:" + this.iValue + " is out of range!";
			throw new NumberFormatException(msg);
		}
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object pObj) {
		if (!(pObj instanceof UnsignedInteger8)) return false;
		return this.iValue == ((UnsignedInteger8) pObj).iValue;
	}

	/**
	 * Returns the value of this unsigned integer object as a byte.
	 * 
	 * @return the byte value of this unsigned integer object
	 */
	@Override
	public byte byteValue() {
		return (byte) this.iValue;
	}

	/**
	 * Returns the value of this unsigned integer object as a short.
	 * 
	 * @return value of this unsigned integer object as a short
	 */
	@Override
	public short shortValue() {
		return this.iValue;
	}

	/**
	 * Returns the value of this unsigned integer object as a <code>long</code>.
	 * 
	 * @return Value of this unsigned integer object as a <code>long</code>.
	 */
	@Override
	public long longValue() {
		return this.iValue;
	}

	/**
	 * doubleValue
	 * 
	 * @return double
	 */
	@Override
	public double doubleValue() {
		return this.iValue;
	}

	/**
	 * floatValue
	 * 
	 * @return float
	 */
	@Override
	public float floatValue() {
		return this.iValue;
	}

	/**
	 * intValue
	 * 
	 * @return int
	 */
	@Override
	public int intValue() {
		return this.iValue;
	}

	/**
	 * Compares this <code>UnsignedInteger8</code> with the specified
	 * <code>UnsignedInteger8</code>. This method is provided in preference to
	 * individual methods for each of the six boolean comparison operators (<,
	 * ==, >, >=, !=, <=). The suggested idiom for performing these comparisons
	 * is: <code>(x.compareTo(y) &lt;op&gt; 0)</code>, where &lt;op&gt; is one
	 * of the six comparison operators.
	 * 
	 * @param pOther
	 *            - Object to which this <code>UnsignedInteger8</code> is to be
	 *            compared. Throws a <code>ClassCastException</code> if the
	 *            input object is not an <code>UnsignedInteger8</code>.
	 * @return -1, 0 or 1 as this <code>UnsignedInteger8</code> is numerically
	 *         less than, equal to, or greater than val.
	 * @see java.lang.Comparable#compareTo(Object o)
	 */
	public int compareTo(UnsignedInteger8 pOther) {
		UnsignedInteger8 that = pOther;
		int d = this.iValue - that.iValue;
		if (d == 0) return 0;
		return d < 0 ? -1 : 1;
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return Short.toString(this.iValue);
	}

}
