/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Endre Bak, ebak@de.ibm.com
 * 
 * Flag       Date        Prog         Description
 * -------------------------------------------------------------------------------
 * 1565892    2006-10-06  ebak         Make SBLIM client JSR48 compliant
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2750520    2009-04-10  blaschke-oss Code cleanup from empty statement et al
 * 2797550    2009-06-01  raman_arora  JSR48 compliance - add Java Generics
 */

package javax.cim;

/**
 * <code>CIMArgument</code> represents an instance of a
 * <code>CIMParameter</code> used for method invocation. A
 * <code>CIMArgument</code> has a name, data type and value. A
 * <code>CIMArgument</code> corresponds to a <code>CIMParameter</code> defined
 * for a <code>CIMMethod</code>.
 * 
 * @param <E>
 *            : Type Parameter
 */
public class CIMArgument<E> extends CIMValuedElement<E> {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 4727439564059428267L;

	/**
	 * Constructs a <code>CIMArgument</code> to be used for method invocations.
	 * A <code>CIMArgument</code> corresponds to a <code>CIMParameter</code>.
	 * For each <code>CIMParameter</code> being populated during a method
	 * invocation a <code>CIMArgument</code> object must be created.
	 * 
	 * @param pName
	 *            - Name of the CIM argument.
	 * @param pType
	 *            - <code>CIMDataType</code> of the argument.
	 * @param pValue
	 *            - Value of the argument.
	 * @throws IllegalArgumentException
	 *             - If the value does not match the type.
	 * @see CIMParameter
	 */
	public CIMArgument(String pName, CIMDataType pType, E pValue) throws IllegalArgumentException {
		super(pName, pType, pValue);
	}

	/**
	 * Compares this object against the specified object. The result is
	 * <code>true</code> if and only if the argument is not <code>null</code>
	 * and is a <code>CIMValuedObject</code> that represents the same name, type
	 * and value as this object.
	 * 
	 * @param pObj
	 *            - The object to compare with.
	 * @return <code>true</code> if the objects are the same; <code>false</code>
	 *         otherwise.
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object pObj) {
		if (!(pObj instanceof CIMArgument)) return false;
		return super.equals(pObj);
	}

	/**
	 * Returns a <code>String</code> representation of the
	 * <code>CIMElement</code>. This method is intended to be used only for
	 * debugging purposes, and the format of the returned string may vary
	 * between implementations. The returned string may be empty but <b>may not
	 * be <code>null</code></b>.
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return super.toString();
	}
}
