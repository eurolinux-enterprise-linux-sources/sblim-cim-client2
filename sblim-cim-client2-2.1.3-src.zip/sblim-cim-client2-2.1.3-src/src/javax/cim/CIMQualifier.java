/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Endre Bak, ebak@de.ibm.com  
 * 
 * Flag       Date        Prog         Description
 * -------------------------------------------------------------------------------
 * 1565892    2006-10-06  ebak         Make SBLIM client JSR48 compliant
 * 1737141    2007-06-18  ebak         Sync up with JSR48 evolution
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2750520    2009-04-10  blaschke-oss Code cleanup from empty statement et al
 * 2763216    2009-04-14  blaschke-oss Code cleanup: visible spelling/grammar errors
 * 2797550    2009-06-01  raman_arora  JSR48 compliance - add Java Generics
 */

package javax.cim;

import org.sblim.cimclient.internal.util.MOF;

/**
 * The <code>CIMQualifier</code> class wraps a CIM qualifier. A qualifier
 * provides additional information about classes, associations, indications,
 * methods, parameters, properties, and/or references. A
 * <code>CIMQualifier</code> must have a CIM Qualifier Type. A qualifier and its
 * qualifier type must have the same name and dataType. CIM Qualifiers can only
 * be applied to elements that are allowed by the scope defined by the CIM
 * Qualifier Type. CIM Qualifiers are defined in the CIM Infrastructure
 * Specification. The specification is available from the DMTF (Distributed
 * Management Task Force) at http://dmtf.org/.
 * 
 * @param <E>
 *            : Type Parameter
 */
public class CIMQualifier<E> extends CIMValuedElement<E> {

	private static final long serialVersionUID = 3568987946093931214L;

	private int iFlavor;

	private boolean iPropagated;

	/**
	 * Constructs a CIM qualifier with the specified name, type, value, and
	 * flavors.
	 * 
	 * @param pName
	 *            - The name of the qualifier.
	 * @param pType
	 *            - The data type of the qualifier.
	 * @param pValue
	 *            - The value of the qualifier.
	 * @param pFlavor
	 *            - a list of override permissions. Flavors can be overridden
	 *            from the Qualifier Type definition to either restrict the
	 *            subclassing of a qualifier or to allow it. For the list of CIM
	 *            Flavors see the <code>CIMFlavor</code> class.
	 */
	public CIMQualifier(String pName, CIMDataType pType, E pValue, int pFlavor) {
		this(pName, pType, pValue, pFlavor, false);
	}

	/**
	 * Constructs a CIM qualifier with the specified name, type, value, and
	 * flavors.
	 * 
	 * @param pName
	 *            - The name of the qualifier.
	 * @param pType
	 *            - The data type of the qualifier.
	 * @param pValue
	 *            - The value of the qualifier.
	 * @param pFlavor
	 *            - a list of override permissions. Flavors can be overridden
	 *            from the Qualifier Type definition to either restrict the
	 *            subclassing of a qualifier or to allow it. For the list of CIM
	 *            Flavors see the <code>CIMFlavor</code> class.
	 * @param pIsPropagated
	 *            -
	 * 
	 */
	public CIMQualifier(String pName, CIMDataType pType, E pValue, int pFlavor,
			boolean pIsPropagated) {
		super(pName, pType, pValue);
		this.iFlavor = pFlavor;
		this.iPropagated = pIsPropagated;
	}

	/**
	 * Compares this object against the specified object. The result is
	 * <code>true</code> if and only if the argument is not <code>null</code>
	 * and is a <code>CIMScope</code> object that represents the same value as
	 * this object.
	 * 
	 * @param pObj
	 *            - the object to compare.
	 * @return <code>true</code> if the input qualifier is equal, otherwise
	 *         <code>false</code>.
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object pObj) {
		if (!(pObj instanceof CIMQualifier)) return false;
		if (!super.equals(pObj)) return false;
		CIMQualifier<?> that = (CIMQualifier<?>) pObj;
		return this.iFlavor == that.iFlavor && this.iPropagated == that.iPropagated;
	}

	/**
	 * Determines if this qualifier is propagated. If the qualifier was
	 * inherited, this value will be true. If the qualifier was applied to the
	 * element directly, this value will be false.
	 * 
	 * @return true if this property is propagated; false otherwise.
	 */
	public boolean isPropagated() {
		return this.iPropagated;
	}

	/**
	 * Returns the CIM flavors for this CIM qualifier.
	 * 
	 * @return A <code>BitSet</code> of CIM flavors in this CIM qualifier.
	 */
	public int getFlavor() {
		return this.iFlavor;
	}

	/**
	 * Returns a <code>String</code> representation of the
	 * <code>CIMQualifier</code>. This method is intended to be used only for
	 * debugging purposes, and the format of the returned string may vary
	 * between implementations. The returned string may be empty but may not be
	 * <code>null</code>.
	 * 
	 * @return A string representation of this qualifier.
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return MOF.qualifier(this);
	}

}
