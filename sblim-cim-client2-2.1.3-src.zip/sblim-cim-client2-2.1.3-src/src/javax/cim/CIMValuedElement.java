/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Endre Bak, ebak@de.ibm.com  
 * 
 * Flag       Date        Prog         Description
 * -------------------------------------------------------------------------------
 * 1565892    2006-10-06  ebak         Make SBLIM client JSR48 compliant
 * 1669961    2006-04-16  lupusalex    CIMTypedElement.getType() =>getDataType()
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2797550    2009-06-01  raman_arora  JSR48 compliance - add Java Generics
 */

package javax.cim;

import java.util.Arrays;

import org.sblim.cimclient.internal.util.MOF;

/**
 * Not implemented yet.
 */
/**
 * Class <code>CIMValuedElement</code> is the base class of all valued CIM
 * element.
 * 
 * @param <E>
 *            : Type Parameter
 */
public abstract class CIMValuedElement<E> extends CIMTypedElement {

	private static final long serialVersionUID = 4234L;

	private E iValue;

	/**
	 * Super constructor for inherited classes.
	 * 
	 * @param pType
	 * @param pValue
	 */
	protected CIMValuedElement(String pName, CIMDataType pType, E pValue) {
		super(pName, pType);
		this.iValue = pValue;
	}

	/**
	 * Compares this object against the specified object. The result is
	 * <code>true</code> if and only if the argument is not <code>null</code>
	 * and is a <code>CIMValuedObject</code> that represents the same name, type
	 * and value as this object.
	 * 
	 * @param pObj
	 *            - The object to compare with.
	 * @return <code>true</code> if the objects are the same; <code>false</code>
	 *         otherwise.
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object pObj) {
		if (!(pObj instanceof CIMValuedElement)) return false;
		CIMValuedElement<?> that = (CIMValuedElement<?>) pObj;
		if (!super.equals(that)) return false;
		if (getDataType().isArray()) { return Arrays.equals((Object[]) this.iValue,
				(Object[]) that.iValue); }
		return this.iValue == null ? that.iValue == null : this.iValue.equals(that.iValue);
	}

	/**
	 * Returns the value for this CIM Element.
	 * 
	 * @return The value of the CIM Element. <code>null</code> is a valid value.
	 */
	public E getValue() {
		return this.iValue;
	}

	/**
	 * Returns the String representation of the valued element.
	 * 
	 * @see javax.cim.CIMTypedElement#toString()
	 */
	@Override
	public String toString() {
		return MOF.valuedElement(this, MOF.EMPTY);
	}

}
