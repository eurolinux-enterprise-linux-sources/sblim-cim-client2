/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Endre Bak, ebak@de.ibm.com  
 * 
 * Flag       Date        Prog         Description
 * -------------------------------------------------------------------------------
 * 1565892    2006-10-06  ebak         Make SBLIM client JSR48 compliant
 * 1669961    2006-04-16  lupusalex    CIMTypedElement.getType() =>getDataType()
 * 1776114    2007-08-21  ebak         Cannot derive instance of class CIM_IndicationSubscription
 * 1855726    2008-02-11  blaschke-oss CIMInstance.deriveInstance is setting wrong CIMObjectPath
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2204488 	  2008-10-28  raman_arora  Fix code to remove compiler warnings
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2531371    2009-02-10  raman_arora  Upgrade client to JDK 1.5 (Phase 2) 
 * 2797550    2009-06-01  raman_arora  JSR48 compliance - add Java Generics
 */

package javax.cim;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;

import org.sblim.cimclient.internal.cim.CIMElementSorter;
import org.sblim.cimclient.internal.cim.CIMInstanceBuilder;
import org.sblim.cimclient.internal.logging.LogAndTraceBroker;
import org.sblim.cimclient.internal.util.MOF;
import org.sblim.cimclient.internal.util.StringSorter;

/**
 * The <code>CIMInstance</code> class represents an instance of a CIM class.
 */
public class CIMInstance extends Object implements CIMNamedElementInterface, Serializable {

	private static final long serialVersionUID = -249160087013230559L;

	private static final CIMProperty<?>[] EMPTY_PROP_A = new CIMProperty[0];

	private CIMObjectPath iObjPath;

	private CIMProperty<?>[] iProps;

	/**
	 * Constructs a <code>CIMInstance</code> object using the name and
	 * properties specified.
	 * 
	 * @param pName
	 *            - The objectpath for this <code>CIMInstance</code>
	 * @param pProps
	 *            - The properties for this <code>CIMInstance</code>
	 * @throws IllegalArgumentException
	 *             <p style="margin-left: 20px"> <code>name</code> is
	 *             <code>null</code> or <code>name.getObjectName()</code> is
	 *             <code>null</code>.<br>
	 *             [OPTIONAL] - If the key property values do not match the
	 *             values in the property array. This is optional due to the
	 *             cost of the verification. Some implementations may leave it
	 *             up to the developer to ensure that the values match.
	 */
	public CIMInstance(CIMObjectPath pName, CIMProperty<?>[] pProps)
			throws IllegalArgumentException {
		if (pName == null) {
			String msg = "CIMObjectPath parameter cannot be null!";
			// TODO: tracing
			throw new IllegalArgumentException(msg);
		}
		if (pName.getObjectName() == null) {
			String msg = "ObjectName cannot be null!";
			// TODO: tracing
			throw new IllegalArgumentException(msg);
		}
		/*
		 * CIMObjectPath param have to contain the key properties only.
		 * VALUE.NAMEDINSTANCE->INSTANCENAME->KEYBINDING CIMProperty[] param
		 * have to contain all properties.
		 * VALUE.NAMEDINSTANCE->INSTANCE->PROPERTY The implementation merges the
		 * properties from both params. From CIMObjectPath's keys only the type
		 * and value information is considered.
		 */
		CIMInstanceBuilder instBuilder = new CIMInstanceBuilder(pName, pProps);
		this.iObjPath = instBuilder.setKeys(pName);
		this.iProps = instBuilder.getAllPropertis();
	}

	/**
	 * Returns a </code>CIMInstance</code> with the updated
	 * <code>CIMObjectPath</code>.
	 * 
	 * @param pPath
	 *            The complete <code>CIMObjectPath</code> for this instance.
	 * @return <code>CIMInstance</code> a new <code>CIMInstance</code> with the
	 *         updated <code>CIMObjectPath</code>.
	 */
	public CIMInstance deriveInstance(CIMObjectPath pPath) {
		return new CIMInstance(pPath, this.iProps);
	}

	/**
	 * Returns a <code>CIMInstance</code> with the updated values for the
	 * properties in <code>pPropA</code>. Any new properties are ignored.
	 * 
	 * @param pPropA
	 *            - The array of properties to update.
	 * @return A new <code>CIMInstance</code> with the updated properties.
	 */
	public CIMInstance deriveInstance(CIMProperty<?>[] pPropA) {
		if (pPropA == null) return this;
		CIMProperty<?>[] newPropA = new CIMProperty[getPropertyCount()];
		for (int i = 0; i < newPropA.length; i++)
			newPropA[i] = this.iProps[i];
		for (int i = 0; i < pPropA.length; i++) {
			CIMProperty<?> newProp = pPropA[i];
			int idx = CIMElementSorter.findIdx(newPropA, newProp.getName());
			if (idx < 0) continue;
			CIMProperty<?> oldProp = newPropA[idx];
			/*
			 * 1776114 -> reference type comparison shouldn't be sensitive to
			 * the referenced class name due to derivation
			 */
			if (!typesEqual(oldProp, newProp)) {
				LogAndTraceBroker.getBroker().trace(
						Level.FINE,
						"CIMInstance.deriveInstance() can update only property "
								+ "values but not property types!\n" + "original property: "
								+ oldProp + "\nnew property: " + newProp);
				continue;
			}
			newPropA[idx] = new CIMProperty<Object>(oldProp.getName(), newProp.getDataType(),
					newProp.getValue(), oldProp.isKey(), oldProp.isPropagated(), oldProp
							.getOriginClass());
		}
		return new CIMInstance(new CIMObjectPath(this.iObjPath.getScheme(),
				this.iObjPath.getHost(), this.iObjPath.getPort(), this.iObjPath.getNamespace(),
				this.iObjPath.getObjectName(), null), newPropA);
	}

	/**
	 * Indicates whether some other instance is "equal to" this one. Two
	 * <code>CIMInstances</code> are considered equal if the names are the same.
	 * This method does NOT compare each property value.
	 * 
	 * @param o
	 *            - The object to compare.
	 * @return <code>true</code> if the specified path references the same
	 *         instance, otherwise <code>false</code>.
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object o) {
		if (!(o instanceof CIMInstance)) return false;
		CIMInstance that = (CIMInstance) o;
		return this.iObjPath.equals(that.iObjPath) && Arrays.equals(this.iProps, that.iProps);
	}

	/**
	 * This method returns a new <code>CIMInstance</code> with properties
	 * filtered according to the input parameters. Inclusion of class origin and
	 * qualifiers can also be controlled.
	 * 
	 * @param pLocalOnly
	 *            - Include only the properties values that were instantiated in
	 *            this instance.
	 * @param pIncludeClassOrigin
	 *            - classOrigins are only included if <code>true</code>.
	 * @param pPropertyList
	 *            <p style="margin-left:20px"> If the <code>propertyList</code>
	 *            input parameter is <b>not <code>null</code></b>, the members
	 *            of the array define one or more Property names. The returned
	 *            Instance does not include elements for any Properties missing
	 *            from this list.<br>
	 *            If the <code>propertyList</code> input parameter is an
	 *            <b>empty array</b> this signifies that no Properties are
	 *            included in each returned class.<br>
	 *            If the <code>propertyList</code> input parameter is <b>
	 *            <code>null</code></b> this specifies that all Properties are
	 *            included in each returned class.<br>
	 *            If the <code>propertyList</code> contains duplicate elements
	 *            or invalid property names, they are ignored. </p>
	 * @return <code>CIMInstance</code> matching the input filter.
	 */
	public CIMInstance filterProperties(boolean pLocalOnly, boolean pIncludeClassOrigin,
			String[] pPropertyList) {
		StringSorter.sort(pPropertyList);
		ArrayList<CIMProperty<?>> propAList = new ArrayList<CIMProperty<?>>();
		for (int i = 0; i < getPropertyCount(); i++) {
			CIMProperty<?> prop = getProperty(i);
			if (pLocalOnly && prop.isPropagated()) continue;
			if (pPropertyList != null && !StringSorter.find(pPropertyList, prop.getName())) continue;
			propAList.add(new CIMProperty<Object>(prop.getName(), prop.getDataType(), prop
					.getValue(), prop.isKey(), prop.isPropagated(), pIncludeClassOrigin ? prop
					.getOriginClass() : null));
		}
		return new CIMInstance(new CIMObjectPath(this.iObjPath.getScheme(),
				this.iObjPath.getHost(), this.iObjPath.getPort(), this.iObjPath.getNamespace(),
				this.iObjPath.getObjectName(), null), propAList.toArray(EMPTY_PROP_A));
	}

	/**
	 * Get the name of the class that instantiates this CIM instance.
	 * 
	 * @return Name of class that instantiates this CIM instance.
	 */
	public String getClassName() {
		return this.iObjPath.getObjectName();
	}

	/**
	 * Get the key properties for this instance.
	 * 
	 * @return An array of key properties.
	 */
	public CIMProperty<?>[] getKeys() {
		ArrayList<CIMProperty<?>> keyALst = new ArrayList<CIMProperty<?>>();
		for (int i = 0; i < this.iProps.length; i++) {
			CIMProperty<?> prop = this.iProps[i];
			if (prop.isKey()) keyALst.add(prop);
		}
		return keyALst.toArray(EMPTY_PROP_A);
	}

	/**
	 * Returns the <code>CIMObjectPath</code> that represents this instance.
	 * 
	 * @return The <code>CIMObjectPath</code> that represents this instance.
	 */
	public CIMObjectPath getObjectPath() {
		return this.iObjPath;
	}

	/**
	 * Retrieve an array of the properties for this instance.
	 * 
	 * @return An array of the CIM properties for this instance
	 */
	public CIMProperty<?>[] getProperties() {
		return this.iProps == null ? new CIMProperty[0] : this.iProps;
	}

	/**
	 * Get a class property by index.
	 * 
	 * @param pIndex
	 *            - The index of the class property to retrieve.
	 * @return The <code>CIMProperty</code> at the specified index.
	 */
	public CIMProperty<?> getProperty(int pIndex) {
		return this.iProps[pIndex];
	}

	/**
	 * Returns the specified property.
	 * 
	 * @param pName
	 *            - The text string for the name of the property.
	 * @return The property requested or <code>null</code> if the property does
	 *         not exist.
	 */
	public CIMProperty<?> getProperty(String pName) {
		return getProperty(pName, null);
	}

	/**
	 * Returns the specified <code>CIMProperty</code>.
	 * 
	 * @param pName
	 *            - The string name of the property to get.
	 * @param pOriginClass
	 *            - (Optional) The string name of the class in which the
	 *            property was defined.
	 * @return <code>null</code> if the property does not exist, otherwise
	 *         returns the CIM property.
	 */
	public CIMProperty<?> getProperty(String pName, String pOriginClass) {
		CIMProperty<?> prop = (CIMProperty<?>) CIMElementSorter.find(this.iProps, pName);
		if (prop == null) return null;
		if (pOriginClass == null) return prop;
		if (pOriginClass.equalsIgnoreCase(prop.getOriginClass())) return prop;
		return null;
	}

	/**
	 * Get the number of properties defined in this <code>CIMClass</code>.
	 * 
	 * @return The number of properties defined in the <code>CIMClass</code>.
	 */
	public int getPropertyCount() {
		return this.iProps == null ? 0 : this.iProps.length;
	}

	/**
	 * Returns the value of a property of this CIM Instance.
	 * 
	 * @param name
	 *            - The name of the property.
	 * @return The value for the specified property name or <code>null</code> if
	 *         the property does not exist.
	 */
	public Object getPropertyValue(String name) {
		CIMProperty<?> prop = getProperty(name);
		return prop == null ? null : prop.getValue();
	}

	/**
	 * Computes the hash code for this instance. The hash code will be the
	 * object path of the instance not including the host or namespace
	 * information.
	 * 
	 * @see java.lang.Object#hashCode()
	 * @return The integer representing the hash code for this object path.
	 */
	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	/**
	 * Returns a <code>String</code> representation of the
	 * <code>CIMInstance</code>. This method is intended to be used only for
	 * debugging purposes, and the format of the returned string may vary
	 * between implementations. The <b>returned string</b> may be empty but
	 * <b>may not be <code>null</code></b>.
	 * 
	 * @see java.lang.Object#toString()
	 * @return String representation of this instance.
	 */
	@Override
	public String toString() {
		return MOF.instanceDeclaration(this, MOF.EMPTY);
	}

	/**
	 * @param pProp1
	 */
	private static boolean typesEqual(CIMProperty<?> pProp0, CIMProperty<?> pProp1) {
		CIMDataType type0 = pProp0.getDataType(), type1 = pProp0.getDataType();
		return type0.getType() == type1.getType() && type0.isArray() == type1.isArray();

	}

}
