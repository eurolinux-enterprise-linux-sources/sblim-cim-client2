/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Endre Bak, ebak@de.ibm.com  
 * 
 * Flag       Date        Prog         Description
 * -------------------------------------------------------------------------------
 * 1565892    2006-10-09  ebak         Make SBLIM client JSR48 compliant
 * 1737123    2007-06-15  ebak         Differences to JSR48 public review draft
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2531371    2009-02-10  raman_arora  Upgrade client to JDK 1.5 (Phase 2)
 * 2750520    2009-04-10  blaschke-oss Code cleanup from empty statement et al
 * 2795671    2009-05-22  raman_arora  Add Type to Comparable <T>
 */

package javax.cim;

/**
 * The <code>UnsignedInteger32</code> class wraps the value of an uint32. This
 * class was created to represent an uint32 data type as defined by the CIM
 * Infrastructure Specification. The specification is available from the DMTF
 * (Distributed Management Task Force) at http://dmtf.org/
 */
public class UnsignedInteger32 extends Number implements Comparable<UnsignedInteger32> {

	private static final long serialVersionUID = -8861436527534071393L;

	/**
	 * The maximum value for an UnsignedInteger32.
	 */
	public static final long MAX_VALUE = 4294967295l;

	/**
	 * The minimum value for an UnsignedInteger32.
	 */
	public static final long MIN_VALUE = 0l;

	private long iValue;

	private void setValue(long pValue) throws NumberFormatException {
		if (pValue > MAX_VALUE || pValue < MIN_VALUE) {
			String msg = "uint32:" + pValue + " is out of range!";
			throw new NumberFormatException(msg);
		}
		this.iValue = pValue;
	}

	/**
	 * Constructs an unsigned 32-bit integer object for the specified long
	 * value. Only the lower 32 bits are considered.
	 * 
	 * @param pValue
	 *            - the long to be represented as an unsigned 32-bit integer.
	 * @throws NumberFormatException
	 *             - If the number is out of range.
	 */
	public UnsignedInteger32(long pValue) throws NumberFormatException {
		setValue(pValue);
	}

	/**
	 * Constructs an unsigned 32-bit integer object for the specified string.
	 * Only the lower 32 bits are considered.
	 * 
	 * @param pValue
	 *            - The long to be represented as an unsigned 32-bit integer.
	 * @throws NumberFormatException
	 *             - If the number is out of range.
	 */
	public UnsignedInteger32(String pValue) throws NumberFormatException {
		setValue(Long.parseLong(pValue));
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object pObj) {
		if (!(pObj instanceof UnsignedInteger32)) return false;
		return this.iValue == ((UnsignedInteger32) pObj).iValue;
	}

	/**
	 * Returns the value of this unsigned integer object as a byte.
	 * 
	 * @return the byte value of this unsigned integer object
	 */
	@Override
	public byte byteValue() {
		return (byte) this.iValue;
	}

	/**
	 * Returns the value of this unsigned integer object as a short.
	 * 
	 * @return value of this unsigned integer object as a short
	 */
	@Override
	public short shortValue() {
		return (short) this.iValue;
	}

	/**
	 * Returns the value of this unsigned integer object as a <code>long</code>.
	 * 
	 * @return Value of this unsigned integer object as a <code>long</code>.
	 */
	@Override
	public long longValue() {
		return this.iValue;
	}

	/**
	 * @see java.lang.Number#doubleValue()
	 */
	@Override
	public double doubleValue() {
		return this.iValue;
	}

	/**
	 * @see java.lang.Number#floatValue()
	 */
	@Override
	public float floatValue() {
		return this.iValue;
	}

	/**
	 * @see java.lang.Number#intValue()
	 */
	@Override
	public int intValue() {
		return (int) this.iValue;
	}

	/**
	 * Compares this <code>UnsignedInteger32</code> with the specified
	 * <code>UnsignedInteger32</code>. This method is provided in preference to
	 * individual methods for each of the six boolean comparison operators (<,
	 * ==, >, >=, !=, <=). The suggested idiom for performing these comparisons
	 * is: <code>(x.compareTo(y) &lt;op&gt; 0)</code>, where &lt;op&gt; is one
	 * of the six comparison operators.
	 * 
	 * @param pOther
	 *            - Object to which this <code>UnsignedInteger32</code> is to be
	 *            compared. Throws a <code>ClassCastException</code> if the
	 *            input object is not an <code>UnsignedInteger32</code>.
	 * @return -1, 0 or 1 as this <code>UnsignedInteger32</code> is numerically
	 *         less than, equal to, or greater than val.
	 * @see java.lang.Comparable#compareTo(Object o)
	 */
	public int compareTo(UnsignedInteger32 pOther) {
		UnsignedInteger32 that = pOther;
		long d = this.iValue - that.iValue;
		if (d == 0) return 0;
		return d < 0 ? -1 : 1;
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return Long.toString(this.iValue);
	}

}
