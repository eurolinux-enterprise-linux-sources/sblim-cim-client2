/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Endre Bak, ebak@de.ibm.com  
 * 
 * Change History
 * Flag       Date        Prog         Description
 * -------------------------------------------------------------------------------
 * 1565892    2006-10-06  ebak         Make SBLIM client JSR48 compliant
 * 1660756    2007-02-22  ebak         Embedded object support
 * 1737141    2007-06-18  ebak         Sync up with JSR48 evolution
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2750520    2009-04-10  blaschke-oss Code cleanup from empty statement et al
 * 2797550    2009-06-01  raman_arora  JSR48 compliance - add Java Generics
 */

package javax.cim;

import java.util.Arrays;

import org.sblim.cimclient.internal.cim.CIMElementSorter;
import org.sblim.cimclient.internal.cim.CIMQualifiedElementInterfaceImpl;
import org.sblim.cimclient.internal.util.MOF;

/**
 * Creates and instantiates a CIM method.
 * 
 * @param <E>
 *            : Type Parameter
 */
public class CIMMethod<E> extends CIMTypedElement implements CIMQualifiedElementInterface {

	private static final long serialVersionUID = -3920536802046705977L;

	private CIMQualifiedElementInterfaceImpl iQualiImpl;

	private CIMParameter<?>[] iParams;

	private boolean iPropagated;

	private String iOriginClass;

	/**
	 * Constructs a <code>CIMMethod</code> object with the specified
	 * information.
	 * 
	 * @param pName
	 *            - The name of the method.
	 * @param pType
	 *            - The data type of the method.
	 * @param pQualis
	 *            - The method qualifiers.
	 * @param pParams
	 *            - The array of parameters for this method.
	 * @param pPropagated
	 *            - Is this method propagated from the superclass.
	 * @param pOriginClass
	 *            - The class this method was defined or overridden in.
	 */
	public CIMMethod(String pName, CIMDataType pType, CIMQualifier<?>[] pQualis,
			CIMParameter<?>[] pParams, boolean pPropagated, String pOriginClass) {
		super(pName, pType);
		this.iQualiImpl = new CIMQualifiedElementInterfaceImpl(pQualis, false, true);
		this.iParams = (CIMParameter[]) CIMElementSorter.sort(pParams);
		this.iOriginClass = pOriginClass;
	}

	/**
	 * @see javax.cim.CIMTypedElement#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object pObj) {
		if (!(pObj instanceof CIMMethod)) return false;
		if (!super.equals(pObj)) return false;
		CIMMethod<?> that = (CIMMethod<?>) pObj;
		if (!this.iQualiImpl.equals(that.iQualiImpl)) return false;
		if (this.iPropagated != that.iPropagated) return false;
		return Arrays.equals(getParameters(), that.getParameters());
	}

	/**
	 * filter
	 * 
	 * @param pIncludeQualifiers
	 *            If true all qualifiers are returned; otherwise no qualifiers.
	 * @param pIncludeClassOrigin
	 *            If true the class origin is included; otherwise no class
	 *            origin is present.
	 * @return CIMMethod A filtered CIMMethod
	 */
	public CIMMethod<E> filter(boolean pIncludeQualifiers, boolean pIncludeClassOrigin) {
		return filter(pIncludeQualifiers, pIncludeClassOrigin, false);
	}

	/**
	 * Returns a CIMMethod filtered as specified.
	 * 
	 * @param pIncludeQualifiers
	 *            If true all qualifiers are returned; otherwise no qualifiers.
	 * @param pIncludeClassOrigin
	 *            If true the class origin is included; otherwise no class
	 *            origin is present
	 * @param pLocalOnly
	 * @return CIMMethod A filtered CIMMethod
	 */
	public CIMMethod<E> filter(boolean pIncludeQualifiers, boolean pIncludeClassOrigin,
			boolean pLocalOnly) {
		return new CIMMethod<E>(getName(), getDataType(), pIncludeQualifiers ? this.iQualiImpl
				.getQualifiers(pLocalOnly) : null, this.iParams, this.iPropagated,
				pIncludeClassOrigin ? this.iOriginClass : null);
	}

	/**
	 * isPropagated
	 * 
	 * @return boolean
	 */
	public boolean isPropagated() {
		return this.iPropagated;
	}

	/**
	 * Returns the class name in which this method was defined or overridden.
	 * 
	 * @return Name of class where this property was defined.
	 */
	public String getOriginClass() {
		return this.iOriginClass;
	}

	/**
	 * Get the parameter that matches the specified name.
	 * 
	 * @param pName
	 *            The name of the CIMParameter to retrieve
	 * @return CIMParameter matching the name specified; otherwise null
	 */
	public CIMParameter<?> getParameter(String pName) {
		return (CIMParameter<?>) CIMElementSorter.find(this.iParams, pName);
	}

	/**
	 * Returns an array of the parameters for this method.
	 * 
	 * @return The parameters for this method.
	 */
	public CIMParameter<?>[] getParameters() {
		return this.iParams == null ? new CIMParameter[0] : this.iParams;
	}

	/**
	 * Get a qualifier by index.
	 * 
	 * @param pIndex
	 *            - The index of the qualifier
	 * @return The Qualifier at index pIndex
	 */
	public CIMQualifier<?> getQualifier(int pIndex) {
		return this.iQualiImpl.getQualifier(pIndex);
	}

	/**
	 * Gets a qualifier by name.
	 * 
	 * @param pName
	 *            - The name of the qualifier to get.
	 * @return <code>null</code> if the qualifier does not exist, otherwise
	 *         returns the reference to the qualifier.
	 */
	public CIMQualifier<?> getQualifier(String pName) {
		return this.iQualiImpl.getQualifier(pName);
	}

	/**
	 * @see javax.cim.CIMQualifiedElementInterface#getQualifierValue(java.lang.String)
	 */
	public Object getQualifierValue(String pName) {
		return this.iQualiImpl.getQualifierValue(pName);
	}

	/**
	 * Get the number of qualifiers defined for this CIM Element.
	 * 
	 * @return The number of qualifiers.
	 */
	public int getQualifierCount() {
		return this.iQualiImpl.getQualifierCount();
	}

	/**
	 * Returns the list of qualifiers for this class.
	 * 
	 * @return Qualifiers for this class.
	 */
	public CIMQualifier<?>[] getQualifiers() {
		return this.iQualiImpl.getQualifiers();
	}

	/**
	 * Checks whether the specified qualifier is one of the qualifiers in this
	 * CIM element.
	 * 
	 * @param pName
	 *            - The name of the qualifier.
	 * @return <code>true</code> if the qualifier exists in this CIM element,
	 *         otherwise <code>false</code>.
	 */
	public boolean hasQualifier(String pName) {
		return this.iQualiImpl.hasQualifier(pName);
	}

	/**
	 * @see javax.cim.CIMQualifiedElementInterface#hasQualifierValue(java.lang.String,
	 *      java.lang.Object)
	 */
	public boolean hasQualifierValue(String pName, Object pValue) {
		return this.iQualiImpl.hasQualifierValue(pName, pValue);
	}

	/**
	 * Returns a <code>String</code> representation of the
	 * <code>CIMMethod</code>. This method is intended to be used only for
	 * debugging purposes, and the format of the returned string may vary
	 * between implementations. The returned string may be empty but may not be
	 * <code>null</code>.
	 * 
	 * @return The string representation of this method.
	 */
	@Override
	public String toString() {
		return MOF.methodDeclaration(this, MOF.EMPTY);
	}

}
