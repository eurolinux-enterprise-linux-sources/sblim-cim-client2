/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Endre Bak, ebak@de.ibm.com  
 * 
 * Flag       Date        Prog         Description
 * -------------------------------------------------------------------------------
 * 1565892    2006-10-06  ebak         Make SBLIM client JSR48 compliant
 * 1669961    2006-04-16  lupusalex    CIMTypedElement.getType() =>getDataType()
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2227442 	  2008-11-05  blaschke-oss Add missing serialVersionUID
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 */

package javax.cim;

import org.sblim.cimclient.internal.util.MOF;

/**
 * Class <code>CIMTypedElement</code> is the base class of all typed CIM
 * element.
 */
public abstract class CIMTypedElement extends CIMElement {

	/**
	 * serialVersionUID
	 */
	static final long serialVersionUID = -8839964536590822815L;

	private CIMDataType iType;

	/**
	 * Constructor.
	 * 
	 * @param pName
	 *            - name of the element
	 * @param pType
	 *            - type of the element
	 */
	public CIMTypedElement(String pName, CIMDataType pType) {
		super(pName);
		this.iType = pType;
	}

	/**
	 * Compares this object against the specified object. The result is
	 * <code>true</code> if and only if the argument is not <code>null</code>
	 * and is a <code>CIMValuedObject</code> that represents the same name, type
	 * and value as this object.
	 * 
	 * @param pObj
	 *            - The object to compare with.
	 * @return <code>true</code> if the objects are the same; <code>false</code>
	 *         otherwise.
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object pObj) {
		if (!(pObj instanceof CIMTypedElement)) return false;
		CIMTypedElement that = (CIMTypedElement) pObj;
		if (!super.equals(that)) return false;
		return this.iType.equals(that.iType);
	}

	/**
	 * Returns the <code>CIMDataType</code> for this CIM Element.
	 * 
	 * @return <code>CIMDataType</code> of this CIM element.
	 */
	public CIMDataType getDataType() {
		return this.iType;
	}

	/**
	 * Returns the <code>String</code> representation of this
	 * <code>CIMTypedElement</code> FIXME: format?
	 * 
	 * @see javax.cim.CIMElement#toString()
	 */
	@Override
	public String toString() {
		return MOF.typedElement(this, MOF.EMPTY);
	}
}
