/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Endre Bak, ebak@de.ibm.com  
 * 
 * Change History
 * Flag       Date        Prog         Description
 *-------------------------------------------------------------------------------------------------
 *            2006-04-25  ebak         Initial commit
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 */

package javax.cim;

/**
 * This interface was present on the 1st JSR48 JavaDoc but it doesn't present in
 * the 2nd JSR48 JavaDoc. I leave it here for a while, maybe JSR48 creators will
 * introduce it on one of the next "specification".
 */
public interface CIMNamedElementInterface {

	/**
	 * Retrieve the ObjectPath that represents the name for this element.
	 * 
	 * @return The Object Path that represents the element.
	 */
	CIMObjectPath getObjectPath();

}
