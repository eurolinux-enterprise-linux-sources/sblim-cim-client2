/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Endre Bak, ebak@de.ibm.com  
 * 
 * Flag       Date        Prog         Description
 * -------------------------------------------------------------------------------
 * 1565892    2006-11-08  lupusalex    Make SBLIM client JSR48 compliant
 * 1715482    2007-05-10  lupusalex    CIM_ERR_FAILED thrown when access denied
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2750520    2009-04-10  blaschke-oss Code cleanup from empty statement et al
 * 2912104    2009-12-10  blaschke-oss Sync up javax.wbem.* with JSR48 1.0.0
 */

package javax.wbem;

import javax.cim.CIMInstance;

/**
 * <code>WBEMException</code> is what all WBEM Operations return when there is
 * an error. <code>WBEMException</code> includes the following:<br>
 * <ul>
 * <li><code>ID</code> - The <code>ID</code> of the <code>Exception</code></li>
 * <li><code>Description</code> - Brief description of the exception</li>
 * <li><code>CIMInstance[]</code> - Optional array of <code>CIM_Error</code>
 * instances</li>
 * </ul>
 */
public class WBEMException extends Exception {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1224653110826327234L;

	/**
	 * General Exception. If no other error IDs match the error, this one should
	 * be returned.
	 */
	public static final int CIM_ERR_FAILED = 1;

	/**
	 * Access Denied Exception. Thrown when the principal is not authenticated
	 * or authorized.
	 */
	public static final int CIM_ERR_ACCESS_DENIED = 2;

	/**
	 * Invalid namespace <code>Exception</code> Thrown when the specified
	 * namespace does not exist.
	 */
	public static final int CIM_ERR_INVALID_NAMESPACE = 3;

	/**
	 * Invalid parameter is passed to a method. This error message uses one
	 * parameter, the parameter which caused the exception.
	 */
	public static final int CIM_ERR_INVALID_PARAMETER = 4;

	/**
	 * Invalid class specified. For e.g. when one tries to add an instance for a
	 * class that does not exist. This error message uses one parameter, the
	 * invalid class name.
	 */
	public static final int CIM_ERR_INVALID_CLASS = 5;

	/**
	 * Element cannot be found. This error message uses one parameter, the
	 * element that cannot be found.
	 */
	public static final int CIM_ERR_NOT_FOUND = 6;

	/**
	 * The action is not supported. This can be thrown by a provider or the WBEM
	 * Server itself when it does not support a particular method.
	 */
	public static final int CIM_ERR_NOT_SUPPORTED = 7;

	/**
	 * Class has subclasses. The exception is thrown by the WBEM Server to
	 * disallow invalidation of the subclasses by the super class deletion.
	 * Clients must explicitly delete the subclasses first. The check for
	 * subclasses is made before the check for class instances.
	 */
	public static final int CIM_ERR_CLASS_HAS_CHILDREN = 8;

	/**
	 * Class has instances. The exception is thrown by to disallow invalidation
	 * of the instances by the class deletion. Clients must explicitly delete
	 * the instances first. The check for subclasses is made before the check
	 * for class instances i.e. <code>CIM_ERR_CLASS_HAS_CHILDREN</code> is
	 * thrown before <code>CIM_ERR_CLASS_HAS_INSTANCES</code>
	 */
	public static final int CIM_ERR_CLASS_HAS_INSTANCES = 9;

	/**
	 * The super class does not exist.
	 */
	public static final int CIM_ERR_INVALID_SUPERCLASS = 10;

	/**
	 * Element already exists.
	 */
	public static final int CIM_ERR_ALREADY_EXISTS = 11;

	/**
	 * The property does not exist in the class/instance being manipulated. This
	 * error message uses has one parameter, the name of the property that does
	 * not exist.
	 */
	public static final int CIM_ERR_NO_SUCH_PROPERTY = 12;

	/**
	 * The value supplied is not compatible with the type.
	 */
	public static final int CIM_ERR_TYPE_MISMATCH = 13;

	/**
	 * The requested query language is not recognized. This error message has
	 * one parameter, the invalid query language string.
	 */
	public static final int CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED = 14;

	/**
	 * Invalid query. This error message uses has two parameters, the invalid
	 * snippet of the query, and additional info with the actual error in the
	 * query.
	 */
	public static final int CIM_ERR_INVALID_QUERY = 15;

	/**
	 * The method is not available.
	 */
	public static final int CIM_ERR_METHOD_NOT_AVAILABLE = 16;

	/**
	 * The method is not found.
	 */
	public static final int CIM_ERR_METHOD_NOT_FOUND = 17;

	/**
	 * The destination is invalid.
	 */
	public static final int CIM_ERR_INVALID_RESPONSE_DESTINATION = 19;

	/**
	 * The namespace is not empty.
	 */
	public static final int CIM_ERR_NAMESPACE_NOT_EMPTY = 20;

	/**
	 * The enumeration identified by the specified context cannot be found, is
	 * in a closed state, does not exist, or is otherwise invalid.
	 */
	public static final int CIM_ERR_INVALID_ENUMERATION_CONTEXT = 21;

	/**
	 * The specified operation timeout is not supported by the WBEM Server.
	 */
	public static final int CIM_ERR_INVALID_OPERATION_TIMEOUT = 22;

	/**
	 * The Pull operation has been abandoned due to execution of a concurrent
	 * CloseEnumeration operation on the same enumeration.
	 */
	public static final int CIM_ERR_PULL_HAS_BEEN_ABANDONED = 23;

	/**
	 * The attempt to abandon a concurrent Pull operation on the same
	 * enumeration failed, the concurrent Pull operation proceeds normally.
	 */
	public static final int CIM_ERR_PULL_CANNOT_BE_ABANDONED = 24;

	/**
	 * Using a filter in the enumeration is not supported by the WBEM Server.
	 */
	public static final int CIM_ERR_FILTERED_ENUMERATION_NOT_SUPPORTED = 25;

	/**
	 * The WBEM Server does not support continuation on error.
	 */
	public static final int CIM_ERR_CONTINUATION_ON_ERROR_NOT_SUPPORTED = 26;

	/**
	 * The WBEM Server has failed the operation based upon exceeding server
	 * limits.
	 */
	public static final int CIM_ERR_SERVER_LIMITS_EXCEEDED = 27;

	/**
	 * The WBEM Server is in the process of shutting down and cannot process the
	 * operation at this time.
	 */
	public static final int CIM_ERR_SERVER_IS_SHUTTING_DOWN = 28;

	private static final String[] MESSAGES = new String[] { "SUCCESS", "CIM_ERR_FAILED",
			"CIM_ERR_ACCESS_DENIED", "CIM_ERR_INVALID_NAMESPACE", "CIM_ERR_INVALID_PARAMETER",
			"CIM_ERR_INVALID_CLASS", "CIM_ERR_NOT_FOUND", "CIM_ERR_NOT_SUPPORTED",
			"CIM_ERR_CLASS_HAS_CHILDREN", "CIM_ERR_CLASS_HAS_INSTANCES",
			"CIM_ERR_INVALID_SUPERCLASS", "CIM_ERR_ALREADY_EXISTS", "CIM_ERR_NO_SUCH_PROPERTY",
			"CIM_ERR_TYPE_MISMATCH", "CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED",
			"CIM_ERR_INVALID_QUERY", "CIM_ERR_METHOD_NOT_AVAILABLE", "CIM_ERR_METHOD_NOT_FOUND",
			"18", "CIM_ERR_INVALID_RESPONSE_DESTINATION", "CIM_ERR_NAMESPACE_NOT_EMPTY",
			"CIM_ERR_INVALID_ENUMERATION_CONTEXT", "CIM_ERR_INVALID_OPERATION_TIMEOUT",
			"CIM_ERR_PULL_HAS_BEEN_ABANDONED", "CIM_ERR_PULL_CANNOT_BE_ABANDONED",
			"CIM_ERR_FILTERED_ENUMERATION_NOT_SUPPORTED",
			"CIM_ERR_CONTINUATION_ON_ERROR_NOT_SUPPORTED", "CIM_ERR_SERVER_LIMITS_EXCEEDED",
			"CIM_ERR_SERVER_IS_SHUTTING_DOWN" };

	private int iErrorID;

	private CIMInstance[] iCimErrors;

	/**
	 * Constructs a new exception using the specified ID. The detailed message
	 * will be <code>null</code>.
	 * 
	 * @param pID
	 *            - The Error ID to use.
	 */
	public WBEMException(int pID) {
		this(pID, null, null, null);
	}

	/**
	 * Constructs a new exception using the specified ID and detailed message.
	 * 
	 * @param pID
	 *            - The error ID.
	 * @param pMessage
	 *            - The detailed message.
	 */
	public WBEMException(int pID, String pMessage) {
		this(pID, pMessage, null, null);
	}

	/**
	 * Constructs a new exception using the specified ID, detailed message and
	 * CIM_Error instances.
	 * 
	 * @param pID
	 *            - The error ID
	 * @param pMessage
	 *            - The detailed message.
	 * @param pErrors
	 *            - Array of CIM_Error instances.
	 */
	public WBEMException(int pID, String pMessage, CIMInstance[] pErrors) {
		this(pID, pMessage, pErrors, null);
	}

	/**
	 * Constructs a new exception using the specified ID, detailed message,
	 * CIM_Error instances and cause.
	 * 
	 * @param pID
	 *            - The error ID.
	 * @param pMessage
	 *            - The detailed message.
	 * @param pErrors
	 *            - Array of CIM_Error instances.
	 * @param pCause
	 *            - <code>Throwable</code> cause.
	 */
	public WBEMException(int pID, String pMessage, CIMInstance[] pErrors, Throwable pCause) {
		super(pMessage, pCause);
		this.iErrorID = pID;
		this.iCimErrors = pErrors;
	}

	/**
	 * Constructs a new exception using the specified detailed message. The
	 * <code>ID</code> will be <code>CIM_ERR_FAILED</code>.
	 * 
	 * @param pMessage
	 *            - The detailed message.
	 */
	public WBEMException(String pMessage) {
		this(CIM_ERR_FAILED, pMessage, null, null);
	}

	/**
	 * Get the CIM Error Instances.
	 * 
	 * @return Any CIM Error instances associated with this exception;
	 *         <code>null</code> if none.
	 */
	public CIMInstance[] getCIMErrors() {
		return this.iCimErrors;
	}

	/**
	 * Returns the ID of the error
	 * 
	 * @return The ID of the error
	 */
	public int getID() {
		return this.iErrorID;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Throwable#getMessage()
	 */
	@Override
	public String getMessage() {
		return super.getMessage() != null ? super.getMessage() : getCIMMessage();
	}

	/**
	 * Prints out the ID and the optional detailed message.
	 * 
	 * @return A <code>String</code> representation of the exception.
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "WBEMException: " + getCIMMessage()
				+ (getMessage() != null ? " (" + getMessage() + ")" : "");
	}

	private String getCIMMessage() {
		return (this.iErrorID >= 0 && this.iErrorID < MESSAGES.length) ? MESSAGES[this.iErrorID]
				: String.valueOf(this.iErrorID);
	}
}
