/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Alexander Wolf-Reber, a.wolf-reber@de.ibm.com
 * 
 * Flag       Date        Prog         Description
 * -------------------------------------------------------------------------------
 * 1565892    2006-11-08  lupusalex    Make SBLIM client JSR48 compliant
 * 1737141    2007-06-18  ebak         Sync up with JSR48 evolution
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2204488 	  2008-10-28  raman_arora  Fix code to remove compiler warnings
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2882448    2009-10-21  blaschke-oss Add WBEMClientConstants from JSR48
 */

package javax.wbem.client;

import org.sblim.cimclient.internal.wbem.WBEMClientCIMXML;

/**
 * The WBEMClientFactory class is a factory that will supply a WBEMClient
 * implementation for a specific protocol. An example of how to use the factory
 * is included below.
 * 
 * <pre>
 *   ...
 *   CIMClient cc = null;
 *   try {
 *   	 cc = WBEMClientFactory.getClient(WBEMClientConstants.PROTOCOL_CIMXML);
 *   } catch (Exception e) {
 *     System.out.println(&quot;Received error when trying to retrieve client handle&quot;);
 *     System.exit(-1);
 *   }
 *   cc.initialize(cns, s, null);
 * </pre>
 */

public class WBEMClientFactory extends Object {

	private static String[] cProtocols;

	static {
		cProtocols = new String[1];
		cProtocols[0] = WBEMClientConstants.PROTOCOL_CIMXML;
	}

	/**
	 * Not used currently. This class doesn't have to be instantiated.
	 */
	public WBEMClientFactory() {
		throw new UnsupportedOperationException("WBEMClientFactory cannot be instantiated.");
	}

	/**
	 * Get a WBEMClient for a protocol.
	 * 
	 * @param pProtocol
	 *            The protocol name (e.g. "CIM-XML")
	 * @return the WBEMClient implementation for the protocol specified.
	 * @throws IllegalArgumentException
	 *             - <dl style="margin-left: 40px;"> <dt>If the protocol is null
	 *             or empty</dt> <dt>If the protocol is not supported</dt> <dt>
	 *             If the protocol implementation could not be loaded</dt> </dl>
	 */
	public static WBEMClient getClient(String pProtocol) {

		if (WBEMClientConstants.PROTOCOL_CIMXML.equalsIgnoreCase(pProtocol)) { return new WBEMClientCIMXML(); }

		throw new IllegalArgumentException("\"" + pProtocol + "\" is not a supported protocol");
	}

	/**
	 * Get the names of the supported protocols.
	 * 
	 * @return a string array of the supported protocols
	 */
	public static String[] getSupportedProtocols() {
		return cProtocols;
	}

}
