/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Endre Bak, ebak@de.ibm.com  
 * 
 * Change History
 * Flag       Date         Prog         Description
 *-------------------------------------------------------------------------------------------------
              2006-04-25   ebak         Initial commit
 * 1737141    2007-06-18   ebak         Sync up with JSR48 evolution
 * 2003590    2008-06-30   blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2899859    2009-11-18  blaschke-oss javax.wbem.client missing JSR48 credential/principal APIs
 */

package javax.wbem.client;

/**
 * <code>RoleCredential</code> implements a password based credential for a
 * role. <code>RoleCredential</code> includes the credential (e.g. password) and
 * optionally the host information for which the password is used to
 * authenticate the <code>RolePrincipal</code>. <code>RoleCredential</code>
 * should be used in conjunction with the <code>RolePrincipal</code> instance.
 * This should only be used when a client is assuming a role on a WBEM Server
 * that requires a password.
 */
public class RoleCredential extends Object {

	private String mCredential;

	private String mHostname;

	/**
	 * Creates a role credential using the supplied credential
	 * 
	 * @param credential
	 *            - The role credential in clear text.
	 * @throws IllegalArgumentException
	 *             - If the credential is <code>null</code>.
	 */
	public RoleCredential(char[] credential) throws IllegalArgumentException {
		if (credential == null) throw new IllegalArgumentException("credential cannot be null!");
		this.mCredential = credential.toString();
	}

	/**
	 * Creates a role credential using the supplied credential
	 * 
	 * @param credential
	 *            - The role credential in clear text.
	 * @throws IllegalArgumentException
	 *             - If the credential is <code>null</code>.
	 */
	public RoleCredential(String credential) throws IllegalArgumentException {
		if (credential == null) throw new IllegalArgumentException("credential cannot be null!");
		this.mCredential = credential;
	}

	/**
	 * Creates a role credential using the supplied credential and hostname
	 * 
	 * @param credential
	 *            - The role credential in clear text.
	 * @param hostname
	 *            - The hostname information for which the password is used to
	 *            authenticate
	 * @throws IllegalArgumentException
	 *             - If the credential is <code>null</code>.
	 */
	public RoleCredential(String credential, String hostname) throws IllegalArgumentException {
		if (credential == null) throw new IllegalArgumentException("credential cannot be null!");
		this.mCredential = credential;
		this.mHostname = hostname;
	}

	/**
	 * Return the role credential in clear text.
	 * 
	 * @return The role credential.
	 */
	public char[] getCredential() {
		return this.mCredential.toCharArray();
	}

	/**
	 * Get the host name for which the password is used to authenticate.
	 * 
	 * @return The host name
	 */
	public String getHostName() {
		return this.mHostname;
	}

}
