/**
 * (C) Copyright IBM Corp. 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Dave Blaschke, blaschke@us.ibm.com
 * 
 * Change History
 * Flag       Date        Prog         Description
 * -------------------------------------------------------------------------------
 * 2882448    2009-10-21  blaschke-oss Add WBEMClientConstants from JSR48
 * 2884718    2008-10-23  blaschke-oss Merge JSR48 and SBLIM client properties
 */
package javax.wbem.client;

/**
 * This class defines the constants used for WBEMClient configuration.
 */
public class WBEMClientConstants {

	/**
	 * Set this property "1" to enable logging to the console. Set to "0" to
	 * disable. The default is 0.
	 */
	public static final String PROP_ENABLE_CONSOLE_LOGGING = "javax.wbem.client.log.console.enabled";

	/**
	 * Set this property to "1" to enable logging to a file. Set to "0" to
	 * disable. The default is 0.
	 */
	public static final String PROP_ENABLE_FILE_LOGGING = "javax.wbem.client.log.file.enabled";

	/**
	 * The maximum size in bytes for each log file. The default is 5MB. Note
	 * that when the last entry is written, it may go past the limit.
	 */
	public static final String PROP_LOG_BYTE_LIMIT = "javax.wbem.client.log.maxfilesize";

	/**
	 * Set this property to the directory where the log files are created. The
	 * default is the directory in which the WBEM client program is run.
	 */
	public static final String PROP_LOG_DIR = "javax.wbem.client.log.dir";

	/**
	 * The name client log file. For a WBEM client using the CIM-XML or
	 * WS-Management protocol the default is cimclient_log_N.txt where N is the
	 * logfile number. The first client log file number is 0.
	 */
	public static final String PROP_LOG_FILENAME = "javax.wbem.client.log.filename";

	/**
	 * The number of log files that will be used. They will be used in
	 * round-robin fashion. The default is 3.
	 */
	public static final String PROP_LOG_NUM_FILES = "javax.wbem.client.log.numfiles";

	/**
	 * The timeout for the client to wait for connections. This value is in
	 * milliseconds. The default is 0 - unlimited. This value must be a valid
	 * Integer.
	 */
	public static final String PROP_TIMEOUT = "javax.wbem.client.timeout";

	/**
	 * The CIM-XML Protocol as defined by the DMTF in the following
	 * specifications:
	 * 
	 * <pre>
	 * DSP0200 - CIM Operations over HTTP 
	 * DSP0201 - Representation of CIM Using XML 
	 * DSP0203 - CIM DTD
	 * </pre>
	 */
	public static final String PROTOCOL_CIMXML = "CIM-XML";

	/**
	 * The WS-Management Protocol as defined by the DMTF in the following
	 * specifications:
	 * 
	 * <pre>
	 * DSP0226 - WS-Management 
	 * DSP0227 - WS-Management CIM Binding Specification 
	 * DSP0230 - WS-CIM Mapping Specification
	 * </pre>
	 */
	public static final String PROTOCOL_WSMANAGEMENT = "WS-Management";
}
