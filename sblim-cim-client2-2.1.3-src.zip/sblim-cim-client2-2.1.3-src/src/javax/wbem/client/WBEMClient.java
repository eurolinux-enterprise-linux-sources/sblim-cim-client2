/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Alexander Wolf-Reber, a.wolf-reber@de.ibm.com
 * 
 * Flag       Date        Prog         Description
 * -------------------------------------------------------------------------------
 * 1565892    2006-11-08  lupusalex    Make SBLIM client JSR48 compliant
 * 1686000    2007-04-19  ebak         modifyInstance() missing from WBEMClient
 * 1737141    2007-06-18  ebak         Sync up with JSR48 evolution
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2763216    2009-04-14  blaschke-oss Code cleanup: visible spelling/grammar errors
 * 2797550    2009-06-01  raman_arora  JSR48 compliance - add Java Generics
 * 2845211    2009-08-27  raman_arora  Pull Enumeration Feature (SAX Parser)
 * 2858933    2009-10-12  raman_arora  JSR48 new APIs: associatorClasses & associatorInstances
 * 2886829    2009-11-18  raman_arora  JSR48 new APIs: referenceClasses & referenceInstances
 */

package javax.wbem.client;

import java.util.Locale;

import javax.cim.CIMArgument;
import javax.cim.CIMClass;
import javax.cim.CIMInstance;
import javax.cim.CIMObjectPath;
import javax.cim.CIMQualifierType;
import javax.cim.UnsignedInteger32;
import javax.cim.UnsignedInteger64;
import javax.security.auth.Subject;
import javax.wbem.CloseableIterator;
import javax.wbem.WBEMException;

/**
 * The WBEMClient interface is use to invoke WBEM operations against a WBEM
 * Server. A WBEMClient implementation can be retrieved from the
 * WBEMClientFactory specifying the protocol to be used.
 * 
 * @see WBEMClientFactory
 */
public interface WBEMClient {

	/**
	 * Enumerates CIM classes that are associated to a specified source CIM
	 * Object.
	 * 
	 * @param pObjectName
	 *            <p style="margin-left: 20px;"> CIMObjectPath defining the
	 *            source CIM Class whose associated classes are to be returned.
	 *            The objectName shall include the host, namespace and object
	 *            name. The keys shall not be populated. </p>
	 * @param pAssociationClass
	 *            <p style="margin-left: 20px;"> This string shall contain a
	 *            valid CIM Association class name or be null. It filters the
	 *            classes returned to contain only classes associated to the
	 *            source Object via this CIM Association class or one of its
	 *            subclasses. </p>
	 * @param pResultClass
	 *            <p style="margin-left: 20px;">This string shall either contain
	 *            a valid CIM Class name or be null. It filters the classes
	 *            returned to contain only the classes of this class name or one
	 *            of its subclasses.</p>
	 * @param pRole
	 *            <p style="margin-left: 20px;"> This string shall either
	 *            contain a valid property name or be null. It filters the
	 *            classes returned to contain only classes associated to the
	 *            source class via an Association class in which the source
	 *            class plays the specified role. (i.e. the Property name in the
	 *            Association class that refers to the source class matches this
	 *            value) For example, if "Antecedent" is specified, then only
	 *            Associations in which the source class is the "Antecedent"
	 *            reference are examined. </p>
	 * @param pResultRole
	 *            <p style="margin-left: 20px;"> This string shall either
	 *            contain a valid property name or be null. It filters the
	 *            classes returned to contain only classes associated to the
	 *            source class via an Association class in which the class
	 *            returned plays the specified role. (i.e. the Property name in
	 *            the Association class that refers to the class returned
	 *            matches this value) </p>
	 * @param pIncludeQualifiers
	 *            <p style="margin-left: 20px;">If true, all Qualifiers for each
	 *            class (including Qualifiers on the Object and on any returned
	 *            Properties) MUST be included in the classes returned. If
	 *            false, no Qualifiers are present in each classes returned.
	 *            </p>
	 * @param pIncludeClassOrigin
	 *            <p style="margin-left: 20px;"> The class origin attribute is
	 *            the name of the class that first defined the property or
	 *            method. If true, the class origin attribute will be present
	 *            for each property and method on all classes returned. If
	 *            false, the class origin will not be present. </p>
	 * @param pPropertyList
	 *            <p style="margin-left: 20px;"> An array of property names used
	 *            to filter what is contained in the classes returned. Each
	 *            CIMClass returned shall only contain elements for the
	 *            properties of the names specified. Duplicate and invalid
	 *            property names are ignored and the request is otherwise
	 *            processed normally. An empty array indicates that no
	 *            properties should be included in the classes returned. A null
	 *            value indicates that all properties should be contained in the
	 *            classes returned. </p>
	 * @return If successful, a CloseableIterator containing zero or more
	 *         CIMClass meeting the specified criteria are returned.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is: <p
	 *             style="margin-left: 20px;"> <code>
	 *   	CIM_ERR_ACCESS_DENIED<br>
	 *   	CIM_ERR_NOT_SUPPORTED<br>
	 *   	CIM_ERR_INVALID_NAMESPACE<br>
	 *   	CIM_ERR_INVALID_PARAMETER (including missing, duplicate,
	 *   	unrecognized or otherwise incorrect parameters<br>
	 *   	CIM_ERR_FAILED (some other unspecified error occurred)
	 *   	</code> </p>
	 */
	public CloseableIterator<CIMClass> associatorClasses(CIMObjectPath pObjectName,
			String pAssociationClass, String pResultClass, String pRole, String pResultRole,
			boolean pIncludeQualifiers, boolean pIncludeClassOrigin, String[] pPropertyList)
			throws WBEMException;

	/**
	 * Enumerates CIMInstances that are associated to a specified source CIM
	 * Object.
	 * 
	 * @param pObjectName
	 *            <p style="margin-left: 20px;"> CIMObjectPath defining the
	 *            source CIM Instance whose associated instances are to be
	 *            returned. The objectName must contain the host, namespace,
	 *            object name and keys for the instance.</p>
	 * @param pAssociationClass
	 *            <p style="margin-left: 20px;"> This string shall either
	 *            contain a valid CIM Association class name or be null. It
	 *            filters the instances returned to contain only instances
	 *            associated to the source instance via this CIM Association
	 *            class or one of its subclasses. </p>
	 * @param pResultClass
	 *            <p style="margin-left: 20px;"> This string shall either
	 *            contain a valid CIM Class name or be null. It filters the
	 *            instances returned to contain only the instances of this Class
	 *            name or one of its subclasses.</p>
	 * @param pRole
	 *            <p style="margin-left: 20px;"> This string shall either
	 *            contain a valid Property name or be null. It filters the
	 *            Objects returned to contain only Objects associated to the
	 *            source Object via an Association class in which the source
	 *            Object plays the specified role. (i.e. the Property name in
	 *            the Association class that refers to the source Object matches
	 *            this value) If "Antecedent" is specified, then only
	 *            Associations in which the source Object is the "Antecedent"
	 *            reference are examined. </p>
	 * @param pResultRole
	 *            <p style="margin-left: 20px;"> This string shall either
	 *            contain a valid property name or be null. It filters the
	 *            instances returned to contain only instances associated to the
	 *            source instance via an Association class in which the
	 *            instances returned plays the specified role. (i.e. the
	 *            Property name in the Association class that refers to the
	 *            instance returned matches this value) For example, if
	 *            "Dependent" is specified, then only Associations in which the
	 *            instance returned is the "Dependent" reference are examined.
	 *            </p>
	 * @param pIncludeClassOrigin
	 *            <p style="margin-left: 20px;"> The class origin attribute is
	 *            the name of the class that first defined the property. If
	 *            true, the class origin attribute will be present for each
	 *            property on all instances returned. If false, the class origin
	 *            will not be present.</p>
	 * @param pPropertyList
	 *            <p style="margin-left: 20px;"> An array of property names used
	 *            to filter what is contained in the Objects returned. Each
	 *            CIMInstance returned only contains elements for the properties
	 *            of the names specified. Duplicate and invalid property names
	 *            are ignored and the request is otherwise processed normally.
	 *            An empty array indicates that no properties should be included
	 *            in the instances returned. A null value indicates that all
	 *            properties should be contained in the instances returned.</p>
	 * @return If successful, a CloseableIterator containing zero or more
	 *         CIMInstances meeting the specified criteria is returned.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is: <p
	 *             style="margin-left: 20px;"> <code>
	 *   	CIM_ERR_ACCESS_DENIED<br>
	 *   	CIM_ERR_NOT_SUPPORTED<br>
	 *   	CIM_ERR_INVALID_NAMESPACE<br>
	 *   	CIM_ERR_INVALID_PARAMETER (including missing, duplicate,
	 *   	unrecognized or otherwise incorrect parameters<br>
	 *   	CIM_ERR_FAILED (some other unspecified error occurred)
	 *   	</code> </p>
	 */
	public CloseableIterator<CIMInstance> associatorInstances(CIMObjectPath pObjectName,
			String pAssociationClass, String pResultClass, String pRole, String pResultRole,
			boolean pIncludeClassOrigin, String[] pPropertyList) throws WBEMException;

	/**
	 * Enumerates the <code>CIMObjectPaths</code> of CIM Objects that are
	 * associated to a particular source CIM Object. If the source Object is a
	 * CIM Class, then an <code>Enumeration</code> of
	 * <code>CIMObjectPaths</code> of the classes associated to the source
	 * Object is returned. If the source Object is a CIM Instance, then an
	 * <code>Enumeration</code> of <code>CIMObjectPaths</code> of the
	 * <code>CIMInstance</code> objects associated to the source Object is
	 * returned.
	 * 
	 * @param pObjectName
	 *            <p style="margin-left: 20px;"> <code>CIMObjectPath</code>
	 *            defining the source CIM Object whose associated Objects are to
	 *            be returned. This argument may contain either a Class name or
	 *            the modelpath of an Instance. (i.e. Keys populated.) </p>
	 * @param pAssociationClass
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid CIM Association class name or be <b>null</b>.
	 *            It filters the Objects returned to contain only Objects
	 *            associated to the source Object via this CIM Association class
	 *            or one of its subclasses. </p>
	 * @param pResultClass
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid CIM Class name or be <b>null</b>. It filters
	 *            the Objects returned to contain only the Objects of this Class
	 *            name or one of its subclasses. </p>
	 * @param pRole
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid Property name or be <b>null</b>. It filters
	 *            the Objects returned to contain only Objects associated to the
	 *            source Object via an Association class in which the <i>source
	 *            Object</i> plays the specified role. (i.e. the Property name
	 *            in the Association class that refers to the source Object
	 *            matches this value) If "Antecedent" is specified, then only
	 *            Associations in which the <i>source Object</i> is the
	 *            "Antecedent" reference are examined. </p>
	 * @param pResultRole
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid Property name or be <b>null</b>. It filters
	 *            the <i>Objects returned</i> to contain only Objects associated
	 *            to the source Object via an Association class in which the
	 *            Object returned plays the specified role. (i.e. the Property
	 *            name in the Association class that refers to the <i>Object
	 *            returned</i> matches this value) If "Dependent" is specified,
	 *            then only Associations in which the <i>Object returned</i> is
	 *            the "Dependent" reference are examined. </p>
	 * @return If successful, a Closeable Iterator containing zero or more
	 *         <code>CIMObjectPath</code> objects of the CIM Classes or CIM
	 *         Instances meeting the specified criteria is returned.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is: <p
	 *             style="margin-left: 20px;"> <code>
	 *   	CIM_ERR_ACCESS_DENIED<br>
	 *   	CIM_ERR_NOT_SUPPORTED<br>
	 *   	CIM_ERR_INVALID_NAMESPACE<br>
	 *   	CIM_ERR_INVALID_PARAMETER (including missing, duplicate,
	 *   	unrecognized or otherwise incorrect parameters)<br>
	 *   	CIM_ERR_FAILED (some other unspecified error occurred)
	 *   	</code> </p>
	 */
	public CloseableIterator<CIMObjectPath> associatorNames(CIMObjectPath pObjectName,
			String pAssociationClass, String pResultClass, String pRole, String pResultRole)
			throws WBEMException;

	/**
	 * associatorPaths will start an enumeration session for traversing
	 * associations starting from the instance defined in the instancePath
	 * parameter using any specified filtering criteria and return zero or more
	 * CIMObjectPath objects.
	 * 
	 * @param instancePath
	 *            <p style="margin-left: 20px;"> The CIMObjectPath for the
	 *            instance for which the enumeration is to be performed. </p>
	 * @param associationClass
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid CIM Association class name or be <b>null</b>.
	 *            It filters the Objects returned to contain only Objects
	 *            associated to the source Object via this CIM Association class
	 *            or one of its subclasses. </p>
	 * @param resultClass
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid CIM Class name or be <b>null</b>. It filters
	 *            the Objects returned to contain only the Objects of this Class
	 *            name or one of its subclasses. </p>
	 * @param role
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid Property name or be <b>null</b>. It filters
	 *            the Objects returned to contain only Objects associated to the
	 *            source Object via an Association class in which the <i>source
	 *            Object</i> plays the specified role. (i.e. the Property name
	 *            in the Association class that refers to the source Object
	 *            matches this value) If "Antecedent" is specified, then only
	 *            Associations in which the <i>source Object</i> is the
	 *            "Antecedent" reference are examined. </p>
	 * @param resultRole
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid Property name or be <b>null</b>. It filters
	 *            the <i>Objects returned</i> to contain only Objects associated
	 *            to the source Object via an Association class in which the
	 *            Object returned plays the specified role. (i.e. the Property
	 *            name in the Association class that refers to the <i>Object
	 *            returned</i> matches this value) If "Dependent" is specified,
	 *            then only Associations in which the <i>Object returned</i> is
	 *            the "Dependent" reference are examined. </p>
	 * @param filterQueryLanguage
	 *            <p style="margin-left: 20px;"> The filterQueryLanguage
	 *            represents the query language for the filterQuery argument.
	 *            This must be left null if a filterQuery is not supplied.
	 * 
	 *            If the implementation does not support the query language
	 *            specified, the CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED error will
	 *            be returned.
	 * 
	 *            If the implementation does not support filtered enumerations,
	 *            the CIM_ERR_FILTERED_ENUMERATION_NOT_SUPPORTED error will be
	 *            returned. </p>
	 * @param filterQuery
	 *            <p style="margin-left: 20px;"> The filterQuery specifies a
	 *            query in the form of the query language specified by the
	 *            filterQueryLanguage parameter. If this value is not null, the
	 *            filterQueryLanguage parameter must be non-null. This value
	 *            will act as an additional filter on the result set.
	 * 
	 *            If the implementation does not support the query language
	 *            specified, the CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED error will
	 *            be returned.
	 * 
	 *            If the implementation does not support filtered enumerations,
	 *            the CIM_ERR_FILTERED_ENUMERATION_NOT_SUPPORTED error will be
	 *            returned. </p>
	 * @param timeout
	 *            <p style="margin-left: 20px;"> This input parameter determines
	 *            the minimum time the CIM server shall maintain the open
	 *            enumeration session after the last Open or Pull operation
	 *            (unless the enumeration session is closed). If the operation
	 *            timeout is exceeded, the implementation may close the
	 *            enumeration session at any time, releasing any resources
	 *            allocated to the enumeration session. An OperationTimeout of 0
	 *            means that there is no operation timeout. That is, the
	 *            enumeration session is never closed based on time. If
	 *            OperationTimeout is NULL, the implementation shall choose an
	 *            operation timeout. All other values for OperationTimeout
	 *            specify the operation timeout in seconds. A implementation may
	 *            restrict the set of allowable values for OperationTimeout.
	 *            Specifically, the implementation may not allow 0 (no timeout).
	 *            If the specified value is not an allowable value, the
	 *            implementation shall return failure with the status code
	 *            CIM_ERR_INVALID_OPERATION_TIMEOUT. </p>
	 * @param continueOnError
	 *            <p style="margin-left: 20px;"> If true, requests that the
	 *            operation resume when an error is received. If a
	 *            implementation does not support continuation on error and
	 *            ContinueOnError is true, it shall throw a WBEMException with
	 *            the status code CIM_ERR_CONTINUATION_ON_ERROR_NOT_SUPPORTED.
	 *            If a implementation supports continuation on error and
	 *            ContinueOnError is true, the enumeration session shall remain
	 *            open when a Pull operation fails, and any subsequent
	 *            successful Pull operations shall return the set of elements
	 *            that would have been returned if the failing Pull operations
	 *            were successful. This behavior is subject to the consistency
	 *            rules defined for pulled enumerations. If ContinueOnError is
	 *            false, the enumeration session will be closed when either the
	 *            operation completes successfully or when a WBEMExcetpion is
	 *            thrown. </p>
	 * @param maxObjects
	 *            <p style="margin-left: 20px;"> Defines the maximum number of
	 *            elements that this Open operation can return. The
	 *            implementation may deliver any number of elements up to
	 *            MaxObjects but shall not deliver more than MaxObjects
	 *            elements. An implementation may choose to never return any
	 *            elements during an Open operation, regardless of the value of
	 *            MaxObjectCount. Note that a CIM client can use a
	 *            MaxObjectCount value of 0 to specify that it does not want to
	 *            retrieve any instances in the Open operation. </p>
	 * @return The return value of a successful Open operation is an array of
	 *         enumerated elements with a number of entries from 0 up to a
	 *         maximum defined by MaxObjects. These entries meet the criteria
	 *         defined in the Open operation. Note that returning no entries in
	 *         the array does not imply that the enumeration session is
	 *         exhausted. Client must evaluate the EnumerateResponse.isEnd() to
	 *         determine if there are more elements.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is: <br>
	 *             <p style="margin-left: 20px;"> <code>
	 *             CIM_ERR_ACCESS_DENIED <br>CIM_ERR_SERVER_IS_SHUTTING_DOWN<br>
	 *             CIM_ERR_NOT_SUPPORTED <br>CIM_ERR_INVALID_NAMESPACE<br>
	 *             CIM_ERR_INVALID_OPERATION_TIMEOUT<br>
	 *             CIM_ERR_CONTINUATION_ON_ERROR_NOT_SUPPORTED<br>
	 *             CIM_ERR_INVALID_PARAMETER<br> CIM_ERR_NOT_FOUND (The source
	 *             instance was not found)<br>
	 *             CIM_ERR_FILTERED_ENUMERATION_NOT_SUPPORTED<br>
	 *             CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED <br>CIM_ERR_INVALID_QUERY<br>
	 *             CIM_ERR_FAILED (Some other unspecified error occurred)<br> </p>
	 */
	public EnumerateResponse<CIMObjectPath> associatorPaths(CIMObjectPath instancePath,
			String associationClass, String resultClass, String role, String resultRole,
			String filterQueryLanguage, String filterQuery, UnsignedInteger32 timeout,
			boolean continueOnError, UnsignedInteger32 maxObjects) throws WBEMException;

	/**
	 * This function will be deprecated soon. Use associatorClasses to enumerate
	 * CIM Classes and associatorInstances to enumerate CIM Instances.
	 * 
	 * Enumerates CIM Objects that are associated to a specified source CIM
	 * Object. If the source Object is a CIM Class, then an
	 * <code>Enumeration</code> of <code>CIMClass</code> objects is returned
	 * containing the classes associated to the source Object. If the source
	 * Object is a CIM Instance, then an <code>Enumeration</code> of
	 * <code>CIMInstance</code> objects is returned containing the instances
	 * associated to the source Object.
	 * 
	 * @param pObjectName
	 *            <p style="margin-left: 20px;"> <code>CIMObjectPath</code>
	 *            defining the source CIM Object whose associated Objects are to
	 *            be returned. This argument may contain either a Class name or
	 *            the modelpath of an Instance. (i.e. Keys populated) </p>
	 * @param pAssociationClass
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid CIM Association class name or be <b>null</b>.
	 *            It filters the Objects returned to contain only Objects
	 *            associated to the source Object via this CIM Association class
	 *            or one of its subclasses. </p>
	 * @param pResultClass
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid CIM Class name or be <b>null</b>. It filters
	 *            the Objects returned to contain only the Objects of this Class
	 *            name or one of its subclasses. </p>
	 * @param pRole
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid Property name or be <b>null</b>. It filters
	 *            the Objects returned to contain only Objects associated to the
	 *            <i>source Object</i> via an Association class in which the
	 *            <i>source Object</i> plays the specified role. (i.e. the
	 *            Property name in the Association class that refers to the
	 *            <i>source Object</i> matches this value) If "Antecedent" is
	 *            specified, then only Associations in which the source Object
	 *            is the "Antecedent" reference are examined. </p>
	 * @param pResultRole
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid Property name or be <b>null</b>. It filters
	 *            the Objects returned to contain only Objects associated to the
	 *            source Object via an Association class in which the <i>Object
	 *            returned</i> plays the specified role. (i.e. the Property name
	 *            in the Association class that refers to the <i>Object
	 *            returned</i> matches this value) If "Dependent" is specified,
	 *            then only Associations in which the <i>Object returned</i> is
	 *            the "Dependent" reference are examined. </p>
	 * @param pIncludeQualifiers
	 *            <p style="margin-left: 20px;"> If <code>true</code>, all
	 *            Qualifiers for each Object (including Qualifiers on the Object
	 *            and on any returned Properties) MUST be included in the
	 *            Objects returned. If <code>false</code>, no Qualifiers are
	 *            present in each Object returned. </p>
	 * @param pIncludeClassOrigin
	 *            <p style="margin-left: 20px;"> If <code>true</code>, the
	 *            <code>CLASSORIGIN</code> attribute will be present on all
	 *            appropriate elements in the Objects returned. If
	 *            <code>false</code>, no <code>CLASSORIGIN</code> attributes are
	 *            present in the Objects returned. <code>CLASSORIGIN</code> is
	 *            attached to an element (properties, methods, references) to
	 *            indicate the class in which it was first defined. </p>
	 * @param pPropertyList
	 *            <p style="margin-left: 20px;"> An array of property names used
	 *            to filter what is contained in the Objects returned. Each
	 *            <code>CIMClass</code> or <code>CIMInstance
	 * 		</code> returned <b>only</b>
	 *            contains elements for the properties of the names specified.
	 *            Duplicate and invalid property names are ignored and the
	 *            request is otherwise processed normally.<br>
	 *            An <b>empty array</b> indicates that no properties should be
	 *            included in the Objects returned.<br>
	 *            A <b>null</b> value indicates that all properties should be
	 *            contained in the Objects returned.<br>
	 *            <b>NOTE:</b> Properties should not be specified in this
	 *            parameter unless a <b>non-null</b> value is specified in the
	 *            <code> resultClass</code> parameter. </p>
	 * @return If successful, a <code>CloseableIterator</code> containing zero
	 *         or more <code>CIMClass</code> or <code>CIMInstance</code> Objects
	 *         meeting the specified criteria is returned.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is: <p
	 *             style="margin-left: 20px;"> <code>
	 *   	CIM_ERR_ACCESS_DENIED<br>
	 *   	CIM_ERR_NOT_SUPPORTED<br>
	 *   	CIM_ERR_INVALID_NAMESPACE<br>
	 *   	CIM_ERR_INVALID_PARAMETER (including missing, duplicate,
	 *   	unrecognized or otherwise incorrect parameters<br>
	 *   	CIM_ERR_FAILED (some other unspecified error occurred)
	 *   	</code> </p>
	 */
	public CloseableIterator associators(CIMObjectPath pObjectName, String pAssociationClass,
			String pResultClass, String pRole, String pResultRole, boolean pIncludeQualifiers,
			boolean pIncludeClassOrigin, String[] pPropertyList) throws WBEMException;

	/**
	 * associators will start an enumeration session for traversing associations
	 * starting from the instance defined in the instancePath parameter using
	 * any specified filtering criteria and return zero or more CIMInstance
	 * objects.
	 * 
	 * @param instancePath
	 *            <p style="margin-left: 20px;"> The CIMObjectPath for the
	 *            instance for which the enumeration is to be performed. </p>
	 * @param associationClass
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid CIM Association class name or be <b>null</b>.
	 *            It filters the Objects returned to contain only Objects
	 *            associated to the source Object via this CIM Association class
	 *            or one of its subclasses. </p>
	 * @param resultClass
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid CIM Class name or be <b>null</b>. It filters
	 *            the Objects returned to contain only the Objects of this Class
	 *            name or one of its subclasses. </p>
	 * @param role
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid Property name or be <b>null</b>. It filters
	 *            the Objects returned to contain only Objects associated to the
	 *            <i>source Object</i> via an Association class in which the
	 *            <i>source Object</i> plays the specified role. (i.e. the
	 *            Property name in the Association class that refers to the
	 *            <i>source Object</i> matches this value) If "Antecedent" is
	 *            specified, then only Associations in which the source Object
	 *            is the "Antecedent" reference are examined. </p>
	 * @param resultRole
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid Property name or be <b>null</b>. It filters
	 *            the Objects returned to contain only Objects associated to the
	 *            source Object via an Association class in which the <i>Object
	 *            returned</i> plays the specified role. (i.e. the Property name
	 *            in the Association class that refers to the <i>Object
	 *            returned</i> matches this value) If "Dependent" is specified,
	 *            then only Associations in which the <i>Object returned</i> is
	 *            the "Dependent" reference are examined. </p>
	 * @param includeClassOrigin
	 *            <p style="margin-left: 20px;"> If <code>true</code>, the
	 *            <code>CLASSORIGIN</code> attribute will be present on all
	 *            appropriate elements in the Objects returned. If
	 *            <code>false</code>, no <code>CLASSORIGIN</code> attributes are
	 *            present in the Objects returned. <code>CLASSORIGIN</code> is
	 *            attached to an element (properties, methods, references) to
	 *            indicate the class in which it was first defined. </p>
	 * @param propertyList
	 *            <p style="margin-left: 20px;"> An array of property names used
	 *            to filter what is contained in the Objects returned. Each
	 *            <code>CIMClass</code> or <code>CIMInstance</code> returned
	 *            <b>only</b> contains elements for the properties of the names
	 *            specified. Duplicate and invalid property names are ignored
	 *            and the request is otherwise processed normally.<br>
	 *            An <b>empty array</b> indicates that no properties should be
	 *            included in the Objects returned.<br>
	 *            A <b>null</b> value indicates that all properties should be
	 *            contained in the Objects returned.<br>
	 *            <b>NOTE:</b> Properties should not be specified in this
	 *            parameter unless a <b>non-null</b> value is specified in the
	 *            <code> resultClass</code> parameter. </p>
	 * @param filterQueryLanguage
	 *            <p style="margin-left: 20px;"> The filterQueryLanguage
	 *            represents the query language for the filterQuery argument.
	 *            This must be left null if a filterQuery is not supplied. <br>
	 * 
	 *            If the implementation does not support the query language
	 *            specified, the CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED error will
	 *            be returned.<br>
	 * 
	 *            If the implementation does not support filtered enumerations,
	 *            the CIM_ERR_FILTERED_ENUMERATION_NOT_SUPPORTED error will be
	 *            returned. </p>
	 * @param filterQuery
	 *            <p style="margin-left: 20px;"> The filterQuery specifies a
	 *            query in the form of the query language specified by the
	 *            filterQueryLanguage parameter. If this value is not null, the
	 *            filterQueryLanguage parameter must be non-null. This value
	 *            will act as an additional filter on the result set.<br>
	 * 
	 *            If the implementation does not support the query language
	 *            specified, the CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED error will
	 *            be returned.<br>
	 * 
	 *            If the implementation does not support filtered enumerations,
	 *            the CIM_ERR_FILTERED_ENUMERATION_NOT_SUPPORTED error will be
	 *            returned. </p>
	 * @param timeout
	 *            <p style="margin-left: 20px;"> This input parameter determines
	 *            the minimum time the CIM server shall maintain the open
	 *            enumeration session after the last Open or Pull operation
	 *            (unless the enumeration session is closed). If the operation
	 *            timeout is exceeded, the implementation may close the
	 *            enumeration session at any time, releasing any resources
	 *            allocated to the enumeration session. An OperationTimeout of 0
	 *            means that there is no operation timeout. That is, the
	 *            enumeration session is never closed based on time. If
	 *            OperationTimeout is NULL, the implementation shall choose an
	 *            operation timeout. All other values for OperationTimeout
	 *            specify the operation timeout in seconds. A implementation may
	 *            restrict the set of allowable values for OperationTimeout.
	 *            Specifically, the implementation may not allow 0 (no timeout).
	 *            If the specified value is not an allowable value, the
	 *            implementation shall return failure with the status code
	 *            CIM_ERR_INVALID_OPERATION_TIMEOUT. </p>
	 * @param continueOnError
	 *            <p style="margin-left: 20px;"> If true, requests that the
	 *            operation resume when an error is received. If a
	 *            implementation does not support continuation on error and
	 *            ContinueOnError is true, it shall throw a WBEMException with
	 *            the status code CIM_ERR_CONTINUATION_ON_ERROR_NOT_SUPPORTED.
	 *            If a implementation supports continuation on error and
	 *            ContinueOnError is true, the enumeration session shall remain
	 *            open when a Pull operation fails, and any subsequent
	 *            successful Pull operations shall return the set of elements
	 *            that would have been returned if the failing Pull operations
	 *            were successful. This behavior is subject to the consistency
	 *            rules defined for pulled enumerations. If ContinueOnError is
	 *            false, the enumeration session will be closed when either the
	 *            operation completes successfully or when a WBEMExcetpion is
	 *            thrown. </p>
	 * @param maxObjects
	 *            <p style="margin-left: 20px;"> Defines the maximum number of
	 *            elements that this Open operation can return. The
	 *            implementation may deliver any number of elements up to
	 *            MaxObjects but shall not deliver more than MaxObjects
	 *            elements. An implementation may choose to never return any
	 *            elements during an Open operation, regardless of the value of
	 *            MaxObjectCount. Note that a CIM client can use a
	 *            MaxObjectCount value of 0 to specify that it does not want to
	 *            retrieve any instances in the Open operation. </p>
	 * @return The return value of a successful Open operation is an array of
	 *         enumerated elements with a number of entries from 0 up to a
	 *         maximum defined by MaxObjects. These entries meet the criteria
	 *         defined in the Open operation. Note that returning no entries in
	 *         the array does not imply that the enumeration session is
	 *         exhausted. Client must evaluate the EnumerateResponse.isEnd() to
	 *         determine if there are more elements.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is:<br>
	 *             <p style="margin-left: 20px;"> <code>
	 *             CIM_ERR_ACCESS_DENIED<br> CIM_ERR_SERVER_IS_SHUTTING_DOWN<br>
	 *             CIM_ERR_NOT_SUPPORTED<br> CIM_ERR_INVALID_NAMESPACE<br>
	 *             CIM_ERR_INVALID_OPERATION_TIMEOUT<br>
	 *             CIM_ERR_CONTINUATION_ON_ERROR_NOT_SUPPORTED<br>
	 *             CIM_ERR_INVALID_PARAMETER CIM_ERR_NOT_FOUND (The source
	 *             instance was not found)<br>
	 *             CIM_ERR_FILTERED_ENUMERATION_NOT_SUPPORTED<br>
	 *             CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED<br> CIM_ERR_INVALID_QUERY<br>
	 *             CIM_ERR_FAILED (Some other unspecified error occurred)</code>
	 *             </p>
	 */
	public EnumerateResponse<CIMInstance> associators(CIMObjectPath instancePath,
			String associationClass, String resultClass, String role, String resultRole,
			boolean includeClassOrigin, String[] propertyList, String filterQueryLanguage,
			String filterQuery, UnsignedInteger32 timeout, boolean continueOnError,
			UnsignedInteger32 maxObjects) throws WBEMException;

	/**
	 * Closes the connection.
	 */
	public void close();

	/**
	 * closeEnumeration will close an enumeration session that has been
	 * previously started but not yet completed. Clients should always use this
	 * method when an enumeration session has been started and the client does
	 * not retrieve all the results. If a client has started an enumeration
	 * session and retrieves all the results until the EnumerationResponse.isEnd
	 * is true, this method shall not be called.
	 * 
	 * @param path
	 *            The CIMObjectPath representing the namespace to be used.
	 * @param context
	 *            The EnumerationContext to close.
	 * @throws WBEMException
	 */
	public void closeEnumeration(CIMObjectPath path, String context) throws WBEMException;

	/**
	 * Create a CIM class The namespace from the CIMClass.getObjectPath() will
	 * be used.
	 * 
	 * @param pClass
	 *            The CIMClass to be created.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is:<br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 		CIM_ERR_ACCESS_DENIED<br>
	 * 		CIM_ERR_NOT_SUPPORTED<br>
	 * 		CIM_ERR_INVALID_NAMESPACE<br>
	 * 		CIM_ERR_INVALID_PARAMETER (including missing, duplicate, unrecognized
	 * 			or otherwise incorrect parameters)<br>
	 *  	CIM_ERR_ALREADY_EXISTS (the CIM Class already exists)<br>
	 *  	CIM_ERR_INVALID_SUPERCLASS (the putative CIM Class declares a
	 *   		non-existent superclass)<br>
	 *   	CIM_ERR_FAILED (some other unspecified error occurred)<br>
	 *   	</code> </p>
	 */
	public void createClass(CIMClass pClass) throws WBEMException;

	/**
	 * Create a CIM Instance. The namespace from the <code>
	 * CIMInstance.getObjectPath()</code>
	 * will be used. The keys of the <code>
	 * CIMInstance</code> may be modified by the
	 * implementation and the client must use the returned object path to
	 * determine the name of the instance. It is possible for a client to leave
	 * keys of instances empty/null and the provider can fill them in. This is
	 * implementation specific unless specified by a the CIM Schema or in a DMTF
	 * Profile.
	 * 
	 * @param pInstance
	 *            The <code>CIMInstance</code> to be created.
	 * @return <code>CIMObjectPath</code> of the instance created.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is:<br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 		CIM_ERR_ACCESS_DENIED<br>
	 * 		CIM_ERR_NOT_SUPPORTED (provider does not support this method)<br>
	 * 		CIM_ERR_INVALID_NAMESPACE<br>
	 * 		CIM_ERR_INVALID_PARAMETER (for this method)<br>
	 * 		CIM_ERR_INVALID_CLASS (in this namespace)<br>
	 * 		CIM_ERR_ALREADY_EXISTS<br>
	 * 		CIM_ERR_FAILED (some other unspecified error occurred)
	 * 		</code> </p>
	 */
	public CIMObjectPath createInstance(CIMInstance pInstance) throws WBEMException;

	/**
	 * Deletes the CIM class for the object specified by the CIM object path.
	 * 
	 * @param pPath
	 *            The <code>CIMObjectPath</code> identifying the namespace and
	 *            class name to delete.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is:<br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 		CIM_ERR_ACCESS_DENIED<br>CIM_ERR_NOT_SUPPORTED<br>
	 * 		CIM_ERR_INVALID_NAMESPACE<br>
	 *   	CIM_ERR_INVALID_PARAMETER (including missing, duplicate, unrecognized 
	 *   		or otherwise incorrect parameters)<br>
	 *  	CIM_ERR_NOT_FOUND (the CIM Class to be deleted does not exisT)<br>
	 * 		CIM_ERR_CLASS_HAS_CHILDREN (the CIM Class has one or more subclasses
	 *   		which cannot be deleted)<br>
	 * 		CIM_ERR_CLASS_HAS_INSTANCES (the CIM Class has one or more instances
	 *   		which cannot be deleted)<br>
	 *  	CIM_ERR_FAILED (some other unspecified error occurred)
	 *  	</code> </p>
	 */
	public void deleteClass(CIMObjectPath pPath) throws WBEMException;

	/**
	 * Delete the CIM instance specified by the CIM object path.
	 * 
	 * @param pPath
	 *            The object path of the instance to be deleted. It must include
	 *            all of the keys.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is:<br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 		CIM_ERR_ACCESS_DENIED<br>
	 *   	CIM_ERR_NOT_SUPPORTED (provider does not support this method)<br>
	 *   	CIM_ERR_INVALID_NAMESPACE<br>
	 *   	CIM_ERR_INVALID_PARAMETER (for this method)<br>
	 *   	CIM_ERR_INVALID_CLASS (in this namespace)<br>
	 *   	CIM_ERR_NOT_FOUND (if the instance does not exist)<br>
	 *   	CIM_ERR_FAILED (some other unspecified error occurred)<br>
	 * 		</code> </p>
	 */
	public void deleteInstance(CIMObjectPath pPath) throws WBEMException;

	/**
	 * Delete a CIM Qualifier Type
	 * 
	 * @param pPath
	 *            The <code>CIMObjectPath</code> identifying the name and
	 *            namespace of the CIM qualifier type to delete.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is:<br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 		CIM_ERR_ACCESS_DENIED<br>CIM_ERR_NOT_SUPPORTED<br>
	 * 		CIM_ERR_INVALID_NAMESPACE<br>
	 * 		CIM_ERR_INVALID_PARAMETER (for this method)<br>
	 *  	CIM_ERR_NOT_FOUND (the Qualifier did not exist)<br>
	 * 		CIM_ERR_FAILED (some other unspecified error occurred)
	 * 		</code> </p>
	 */
	public void deleteQualifierType(CIMObjectPath pPath) throws WBEMException;

	/**
	 * Enumerate CIM Classes.
	 * 
	 * @param pPath
	 *            <p style="margin-left: 20px;"> The object path of the class to
	 *            be enumerated. Only the name space and class name components
	 *            are used. All other information (e.g. Keys) is ignored. </p>
	 * @param pDeep
	 *            <p style="margin-left: 20px;"> If <code>true</code>, the
	 *            enumeration returned contains the specified class and all
	 *            subclasses. If <code>false</code>, the enumeration returned
	 *            contains only the contents of the first level children of the
	 *            specified class. </p>
	 * @param pPropagated
	 *            <p style="margin-left: 20px;"> If <code>true</code>, only
	 *            elements (properties, methods and qualifiers) defined in, or
	 *            overridden in the class are included in the response. If
	 *            <code>false</code>, all elements of the class definition are
	 *            returned. </p>
	 * @param pIncludeQualifiers
	 *            <p style="margin-left: 20px;"> If <code>true</code>, all
	 *            Qualifiers for each Class and its elements ( properties,
	 *            methods, references). If <code>false</code>, no Qualifiers are
	 *            present in the classes returned. </p>
	 * @param pIncludeClassOrigin
	 *            <p style="margin-left: 20px;"> If <code>true</code>, the
	 *            CLASSORIGIN attribute MUST be present on all appropriate
	 *            elements in each classes returned. If <code>false</code>, no
	 *            CLASSORIGIN attributes are present in each class returned.
	 *            CLASSORIGIN is attached to an element to indicate the class in
	 *            which it was first defined. </p>
	 * @return a <code>CloseableIterator</code> of <code>CIMClass</code>es.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is:<br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 		CIM_ERR_ACCESS_DENIED<br>CIM_ERR_NOT_SUPPORTED<br>
	 * 		CIM_ERR_INVALID_NAMESPACE<br>
	 * 		CIM_ERR_INVALID_PARAMETER (including missing, duplicate, unrecognized 
	 * 			or otherwise incorrect parameters)<br>
	 * 		CIM_ERR_INVALID_CLASS (the CIM Class that is the basis for this
	 * 			enumeration does not exist)<br>
	 * 		CIM_ERR_FAILED (some other unspecified error occurred)
	 * 		</code> </p>
	 */
	public CloseableIterator<CIMClass> enumerateClasses(CIMObjectPath pPath, boolean pDeep,
			boolean pPropagated, boolean pIncludeQualifiers, boolean pIncludeClassOrigin)
			throws WBEMException;

	/**
	 * Enumerate the names of CIM Classes.
	 * 
	 * @param pPath
	 *            <p style="margin-left: 20px;"> The <code>CIMObjectPath</code>
	 *            identifying the class to be enumerated. If the class name in
	 *            the object path specified is <b>null</b>, all base classes in
	 *            the target namespace are returned. </p>
	 * @param pDeep
	 *            <p style="margin-left: 20px;"> If <code>true</code>, the
	 *            enumeration returned will contain the names of all classes
	 *            derived from the class being enumerated. If <code>false
	 * 		</code>, the
	 *            enumeration returned contains only the names of the first
	 *            level children of the class. </p>
	 * @return a <code>CloseableIterator</code> of <code>CIMObjectPath</code>s
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is:<br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 		CIM_ERR_ACCESS_DENIED<br>CIM_ERR_NOT_SUPPORTED<br>
	 * 		CIM_ERR_INVALID_NAMESPACE<br>
	 * 		CIM_ERR_INVALID_PARAMETER (including missing, duplicate, unrecognized 
	 * 			or otherwise incorrect parameters)<br>
	 * 		CIM_ERR_INVALID_CLASS (the CIM Class that is the basis for this
	 * 			enumeration does not exist)<br>
	 * 		CIM_ERR_FAILED (some other unspecified error occurred)
	 * 		</code> </p>
	 */
	public CloseableIterator<CIMObjectPath> enumerateClassNames(CIMObjectPath pPath, boolean pDeep)
			throws WBEMException;

	/**
	 * Enumerate the names of the instances for a specified class. The names of
	 * all subclass instances are returned.
	 * 
	 * @param pPath
	 *            <p style="margin-left: 20px;"> The <code>CIMObjectPath</code>
	 *            identifying the class whose instances are to be enumerated.
	 *            Only the name space and class name components are used. All
	 *            other information (e.g. Keys) is ignored. </p>
	 * @return <code>CloseabelIterator</code> of <code>CIMObjectPath</code>s.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is:<br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 		CIM_ERR_ACCESS_DENIED<br>
	 * 		CIM_ERR_NOT_SUPPORTED (provider does not support this method)<br>
	 * 		CIM_ERR_INVALID_NAMESPACE<br>
	 * 		CIM_ERR_INVALID_PARAMETER (for this method)<br>
	 * 		CIM_ERR_INVALID_CLASS (in this namespace)<br>
	 * 		CIM_ERR_FAILED (some other unspecified error occurred)
	 * 		</code> </p>
	 */
	public CloseableIterator<CIMObjectPath> enumerateInstanceNames(CIMObjectPath pPath)
			throws WBEMException;

	/**
	 * enumerateInstancePaths will enumerate the instances of the specified
	 * class in classPath and return zero or more CIMObjectPath
	 * 
	 * @param classPath
	 *            <p style="margin-left: 20px;"> The CIMObjectPath for the class
	 *            for which the enumeration is to be performed. </p>
	 * @param filterQueryLanguage
	 *            <p style="margin-left: 20px;"> The filterQueryLanguage
	 *            represents the query language for the filterQuery argument.
	 *            This must be left null if a filterQuery is not supplied.
	 * 
	 *            If the implementation does not support the query language
	 *            specified, the CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED error will
	 *            be returned.
	 * 
	 *            If the implementation does not support filtered enumerations,
	 *            the CIM_ERR_FILTERED_ENUMERATION_NOT_SUPPORTED error will be
	 *            returned. </p>
	 * 
	 * @param filterQuery
	 *            <p style="margin-left: 20px;"> The filterQuery specifies a
	 *            query in the form of the query language specified by the
	 *            filterQueryLanguage parameter. If this value is not null, the
	 *            filterQueryLanguage parameter must be non-null. This value
	 *            will act as an additional filter on the result set.
	 * 
	 *            If the implementation does not support the query language
	 *            specified, the CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED error will
	 *            be returned.
	 * 
	 *            If the implementation does not support filtered enumerations,
	 *            the CIM_ERR_FILTERED_ENUMERATION_NOT_SUPPORTED error will be
	 *            returned. </p>
	 * 
	 * @param timeout
	 *            <p style="margin-left: 20px;"> This input parameter determines
	 *            the minimum time the CIM server shall maintain the open
	 *            enumeration session after the last Open or Pull operation
	 *            (unless the enumeration session is closed). If the operation
	 *            timeout is exceeded, the implementation may close the
	 *            enumeration session at any time, releasing any resources
	 *            allocated to the enumeration session. An OperationTimeout of 0
	 *            means that there is no operation timeout. That is, the
	 *            enumeration session is never closed based on time. If
	 *            OperationTimeout is NULL, the implementation shall choose an
	 *            operation timeout. All other values for OperationTimeout
	 *            specify the operation timeout in seconds. A implementation may
	 *            restrict the set of allowable values for OperationTimeout.
	 *            Specifically, the implementation may not allow 0 (no timeout).
	 *            If the specified value is not an allowable value, the
	 *            implementation shall return failure with the status code
	 *            CIM_ERR_INVALID_OPERATION_TIMEOUT. </p>
	 * 
	 * @param continueOnError
	 *            <p style="margin-left: 20px;"> If true, requests that the
	 *            operation resume when an error is received. If a
	 *            implementation does not support continuation on error and
	 *            ContinueOnError is true, it shall throw a WBEMException with
	 *            the status code CIM_ERR_CONTINUATION_ON_ERROR_NOT_SUPPORTED.
	 *            If a implementation supports continuation on error and
	 *            ContinueOnError is true, the enumeration session shall remain
	 *            open when a Pull operation fails, and any subsequent
	 *            successful Pull operations shall return the set of elements
	 *            that would have been returned if the failing Pull operations
	 *            were successful. This behavior is subject to the consistency
	 *            rules defined for pulled enumerations. If ContinueOnError is
	 *            false, the enumeration session will be closed when either the
	 *            operation completes successfully or when a WBEMExcetpion is
	 *            thrown. </p>
	 * 
	 * @param maxObjects
	 *            <p style="margin-left: 20px;"> Defines the maximum number of
	 *            elements that this Open operation can return. The
	 *            implementation may deliver any number of elements up to
	 *            MaxObjects but shall not deliver more than MaxObjects
	 *            elements. An implementation may choose to never return any
	 *            elements during an Open operation, regardless of the value of
	 *            MaxObjectCount. Note that a CIM client can use a
	 *            MaxObjectCount value of 0 to specify that it does not want to
	 *            retrieve any instances in the Open operation. </p>
	 * 
	 * @return The return value of a successful Open operation is an array of
	 *         enumerated elements with a number of entries from 0 up to a
	 *         maximum defined by MaxObjects. These entries meet the criteria
	 *         defined in the Open operation. Note that returning no entries in
	 *         the array does not imply that the enumeration session is
	 *         exhausted. Client must evaluate the EnumerateResponse.isEnd() to
	 *         determine if there are more elements.
	 * 
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is: <br>
	 *             <p style="margin-left: 20px;"> <code>
	 *             CIM_ERR_ACCESS_DENIED<br> CIM_ERR_SERVER_IS_SHUTTING_DOWN<br>
	 *             CIM_ERR_NOT_SUPPORTED<br> CIM_ERR_INVALID_NAMESPACE<br>
	 *             CIM_ERR_INVALID_OPERATION_TIMEOUT<br>
	 *             CIM_ERR_CONTINUATION_ON_ERROR_NOT_SUPPORTED<br>
	 *             CIM_ERR_INVALID_PARAMETER CIM_ERR_INVALID_CLASS (The source
	 *             class does not exist)<br>
	 *             CIM_ERR_FILTERED_ENUMERATION_NOT_SUPPORTED<br>
	 *             CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED <br>CIM_ERR_INVALID_QUERY<br>
	 *             CIM_ERR_FAILED (Some other unspecified error occurred)</code>
	 *             </p>
	 */
	public EnumerateResponse<CIMObjectPath> enumerateInstancePaths(CIMObjectPath classPath,
			String filterQueryLanguage, String filterQuery, UnsignedInteger32 timeout,
			boolean continueOnError, UnsignedInteger32 maxObjects) throws WBEMException;

	/**
	 * Enumerate the instances of a class. The instances of all subclasses are
	 * also returned.
	 * 
	 * @param pPath
	 *            <p style="margin-left: 20px;"> The object path of the class to
	 *            be enumerated. Only the name space and class name components
	 *            are used. Any other information (e.g. Keys) is ignored. </p>
	 * @param pDeep
	 *            <p style="margin-left: 20px;"> If <code>true</code>, the
	 *            enumeration returned contains all instances of the specified
	 *            class and all classes derived from it. If <code>false
	 * 		</code>, only
	 *            names of instances of the specified class are returned. </p>
	 * @param pPropagated
	 *            <p style="margin-left: 20px;"> If <code>true</code>, only
	 *            elements (properties, methods, references) overridden or
	 *            defined in the class are included in the instances returned.
	 *            </p>
	 * @param pIncludeClassOrigin
	 *            <p style="margin-left: 20px;"> If <code>true</code>, the
	 *            CLASSORIGIN attribute will be present on all appropriate
	 *            elements in the instances returned. If <code>false</code>, no
	 *            CLASSORIGIN attributes are present in the instances returned.
	 *            CLASSORIGIN is attached to an element (properties, methods,
	 *            references) to indicate the class in which it was first
	 *            defined. </p>
	 * @param pPropertyList
	 *            <p style="margin-left: 20px;"> An array of property names used
	 *            to filter what is contained in the instances returned. Each
	 *            instance returned <b>only</b> contains elements for the
	 *            properties of the names specified. Duplicate and invalid
	 *            property names are ignored and the request is otherwise
	 *            processed normally. An empty array indicates that no
	 *            properties should be returned. A <b>null</b> value indicates
	 *            that all properties should be returned. </p>
	 * @return a <code>CloseableIterator</code> of <code>CIMInstance</code>s
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is:<br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 		CIM_ERR_ACCESS_DENIED<br>CIM_ERR_NOT_SUPPORTED<br>
	 * 		CIM_ERR_INVALID_NAMESPACE<br>
	 * 		CIM_ERR_INVALID_PARAMETER (for this method)<br>
	 * 		CIM_ERR_INVALID_CLASS (in this namespace)<br>
	 * 		CIM_ERR_FAILED (some other unspecified error occurred)
	 *		</code> </p>
	 */
	public CloseableIterator<CIMInstance> enumerateInstances(CIMObjectPath pPath, boolean pDeep,
			boolean pPropagated, boolean pIncludeClassOrigin, String[] pPropertyList)
			throws WBEMException;

	/**
	 * enumerateInstances will enumerate the instances of the specified class in
	 * classPath and return zero or more CIMInstances.
	 * 
	 * @param classPath
	 *            <p style="margin-left: 20px;"> The CIMObjectPath for the class
	 *            for which the enumeration is to be performed. </p>
	 * @param deepInheritance
	 *            <p style="margin-left: 20px;"> If <code>true</code>, the
	 *            enumeration returned contains all instances of the specified
	 *            class and all classes derived from it. If <code>false
	 * 		</code>, only
	 *            names of instances of the specified class are returned. </p>
	 * 
	 * @param includeClassOrigin
	 *            <p style="margin-left: 20px;"> If <code>true</code>, the
	 *            CLASSORIGIN attribute will be present on all appropriate
	 *            elements in the instances returned. If <code>false</code>, no
	 *            CLASSORIGIN attributes are present in the instances returned.
	 *            CLASSORIGIN is attached to an element (properties, methods,
	 *            references) to indicate the class in which it was first
	 *            defined. </p>
	 * @param propertyList
	 *            <p style="margin-left: 20px;"> An array of property names used
	 *            to filter what is contained in the instances returned. Each
	 *            instance returned <b>only</b> contains elements for the
	 *            properties of the names specified. Duplicate and invalid
	 *            property names are ignored and the request is otherwise
	 *            processed normally. An empty array indicates that no
	 *            properties should be returned. A <b>null</b> value indicates
	 *            that all properties should be returned. </p>
	 * @param filterQueryLanguage
	 *            <p style="margin-left: 20px;"> The filterQueryLanguage
	 *            represents the query language for the filterQuery argument.
	 *            This must be left null if a filterQuery is not supplied.
	 * 
	 *            If the implementation does not support the query language
	 *            specified, the CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED error will
	 *            be returned.
	 * 
	 *            If the implementation does not support filtered enumerations,
	 *            the CIM_ERR_FILTERED_ENUMERATION_NOT_SUPPORTED error will be
	 *            returned.</p>
	 * @param filterQuery
	 *            <p style="margin-left: 20px;"> The filterQuery specifies a
	 *            query in the form of the query language specified by the
	 *            filterQueryLanguage parameter. If this value is not null, the
	 *            filterQueryLanguage parameter must be non-null. This value
	 *            will act as an additional filter on the result set.
	 * 
	 *            If the implementation does not support the query language
	 *            specified, the CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED error will
	 *            be returned.
	 * 
	 *            If the implementation does not support filtered enumerations,
	 *            the CIM_ERR_FILTERED_ENUMERATION_NOT_SUPPORTED error will be
	 *            returned.</p>
	 * @param timeout
	 *            <p style="margin-left: 20px;"> This input parameter determines
	 *            the minimum time the CIM server shall maintain the open
	 *            enumeration session after the last Open or Pull operation
	 *            (unless the enumeration session is closed). If the operation
	 *            timeout is exceeded, the implementation may close the
	 *            enumeration session at any time, releasing any resources
	 *            allocated to the enumeration session. An OperationTimeout of 0
	 *            means that there is no operation timeout. That is, the
	 *            enumeration session is never closed based on time. If
	 *            OperationTimeout is NULL, the implementation shall choose an
	 *            operation timeout. All other values for OperationTimeout
	 *            specify the operation timeout in seconds. A implementation may
	 *            restrict the set of allowable values for OperationTimeout.
	 *            Specifically, the implementation may not allow 0 (no timeout).
	 *            If the specified value is not an allowable value, the
	 *            implementation shall return failure with the status code
	 *            CIM_ERR_INVALID_OPERATION_TIMEOUT.</p>
	 * @param continueOnError
	 *            <p style="margin-left: 20px;"> If true, requests that the
	 *            operation resume when an error is received. If a
	 *            implementation does not support continuation on error and
	 *            ContinueOnError is true, it shall throw a WBEMException with
	 *            the status code CIM_ERR_CONTINUATION_ON_ERROR_NOT_SUPPORTED.
	 *            If a implementation supports continuation on error and
	 *            ContinueOnError is true, the enumeration session shall remain
	 *            open when a Pull operation fails, and any subsequent
	 *            successful Pull operations shall return the set of elements
	 *            that would have been returned if the failing Pull operations
	 *            were successful. This behavior is subject to the consistency
	 *            rules defined for pulled enumerations. If ContinueOnError is
	 *            false, the enumeration session will be closed when either the
	 *            operation completes successfully or when a WBEMExcetpion is
	 *            thrown. </p>
	 * @param maxObjects
	 *            <p style="margin-left: 20px;"> Defines the maximum number of
	 *            elements that this Open operation can return. The
	 *            implementation may deliver any number of elements up to
	 *            MaxObjects but shall not deliver more than MaxObjects
	 *            elements. An implementation may choose to never return any
	 *            elements during an Open operation, regardless of the value of
	 *            MaxObjectCount. Note that a CIM client can use a
	 *            MaxObjectCount value of 0 to specify that it does not want to
	 *            retrieve any instances in the Open operation. </p>
	 * @return The return value of a successful Open operation is an array of
	 *         enumerated elements with a number of entries from 0 up to a
	 *         maximum defined by MaxObjects. These entries meet the criteria
	 *         defined in the Open operation. Note that returning no entries in
	 *         the array does not imply that the enumeration session is
	 *         exhausted. Client must evaluate the EnumerateResponse.isEnd() to
	 *         determine if there are more elements.
	 * 
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is: <br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 
	 *             CIM_ERR_ACCESS_DENIED<br> CIM_ERR_SERVER_IS_SHUTTING_DOWN<br>
	 *             CIM_ERR_NOT_SUPPORTED <br>CIM_ERR_INVALID_NAMESPACE<br>
	 *             CIM_ERR_INVALID_OPERATION_TIMEOUT<br>
	 *             CIM_ERR_CONTINUATION_ON_ERROR_NOT_SUPPORTED<br>
	 *             CIM_ERR_INVALID_PARAMETER<br> CIM_ERR_INVALID_CLASS (The source
	 *             class does not exist)<br>
	 *             CIM_ERR_FILTERED_ENUMERATION_NOT_SUPPORTED<br>
	 *             CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED<br> CIM_ERR_INVALID_QUERY<br>
	 *             CIM_ERR_FAILED (Some other unspecified error occurred)</code>
	 *             </p>
	 */
	public EnumerateResponse<CIMInstance> enumerateInstances(CIMObjectPath classPath,
			boolean deepInheritance, boolean includeClassOrigin, String[] propertyList,
			String filterQueryLanguage, String filterQuery, UnsignedInteger32 timeout,
			boolean continueOnError, UnsignedInteger32 maxObjects) throws WBEMException;

	/**
	 * Enumerates the CIM Qualifier Types for a specific namespace
	 * 
	 * @param pPath
	 *            <p style="margin-left: 20px;"> The <code>CIMObjectPath</code>
	 *            identifying the namespace whose qualifier types are to be
	 *            enumerated. </p>
	 * @return a <code>CloseableIterator</code> of <code>CIMQualifierType</code>
	 *         s
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is:<br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 		CIM_ERR_ACCESS_DENIED<br>CIM_ERR_NOT_SUPPORTED<br>
	 * 		CIM_ERR_INVALID_NAMESPACE<br>
	 * 		CIM_ERR_INVALID_PARAMETER (including missing, duplicate, unrecognized 
	 * 		or otherwise incorrect parameters)<br>
	 * 		CIM_ERR_FAILED (some other unspecified error occurred)
	 *		</code> </p>
	 */
	public CloseableIterator<CIMQualifierType<?>> enumerateQualifierTypes(CIMObjectPath pPath)
			throws WBEMException;

	/**
	 * enumerationCount provides an estimated count of the total number of
	 * objects in an open enumeration session represented by an
	 * EnumerationContext.
	 * 
	 * @param path
	 *            The namespace for the enumeration context
	 * @param enumerationContext
	 *            The enumerationContext to count
	 * @return The estimated number of objects
	 * @throws UnsupportedOperationException
	 * 
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is: <br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 
	 *             CIM_ERR_ACCESS_DENIED </br>CIM_ERR_SERVER_IS_SHUTTING_DOWN</br>
	 *             CIM_ERR_NOT_SUPPORTED</br> CIM_ERR_INVALID_NAMESPACE</br>
	 *             CIM_ERR_INVALID_PARAMETER </br>CIM_ERR_INVALID_ENUMERATION_CONTEXT</br>
	 *             CIM_ERR_SERVER_LIMITS_EXCEEDED</br> CIM_ERR_FAILED</br> </code>
	 * 
	 */
	public UnsignedInteger64 enumerationCount(CIMObjectPath path, String enumerationContext)
			throws WBEMException;

	/**
	 * ExecQuery will execute a query to retrieve objects.
	 * 
	 * @param pPath
	 *            <p style="margin-left: 20px;"> <code>CIMObjectPath</code>
	 *            identifying the class to query. Only the namespace and class
	 *            name components are used. All other information (e.g. Keys) is
	 *            ignored. </p>
	 * @param pQuery
	 *            <p style="margin-left: 20px;"> A string containing the text of
	 *            the query. </p>
	 * @param pQueryLanguage
	 *            <p style="margin-left: 20px;"> A string that identifies the
	 *            query language to use to parse the query string specified.
	 *            </p>
	 * @return A <code>CloseableIterator</code> of <code>CIMInstance</code>s.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is:<br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 		CIM_ERR_ACCESS_DENIED<br>
	 * 		CIM_ERR_NOT_SUPPORTED (provider does not support this method)<br>
	 * 		CIM_ERR_INVALID_NAMESPACE<br>
	 * 		CIM_ERR_INVALID_PARAMETER (including missing, duplicate, 
	 * 		unrecognized or otherwise incorrect parameters)<br>
	 * 		CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED (the requested query language
	 * 		is not recognized)<br>
	 * 		CIM_ERR_INVALID_QUERY (the query is not a valid query in the specified
	 * 		query language)<br>
	 * 		CIM_ERR_FAILED (some other unspecified error occurred)
	 *		</code> </p>
	 */
	public CloseableIterator<CIMInstance> execQuery(CIMObjectPath pPath, String pQuery,
			String pQueryLanguage) throws WBEMException;

	/**
	 * execQueryInstances will execute a query to retrieve instances.
	 * 
	 * @param pObjectName
	 *            <p style="margin-left: 20px;"> <code>CIMObjectPath</code>
	 *            identifying the class to query. Only the namespace and class
	 *            name components are used. All other information (e.g. Keys) is
	 *            ignored. </p>
	 * @param filterQueryLanguage
	 *            <p style="margin-left: 20px;"> The filterQueryLanguage
	 *            represents the query language for the filterQuery argument.
	 *            This must be left null if a filterQuery is not supplied.
	 * 
	 *            If the implementation does not support the query language
	 *            specified, the CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED error will
	 *            be returned.
	 * 
	 *            If the implementation does not support filtered enumerations,
	 *            the CIM_ERR_FILTERED_ENUMERATION_NOT_SUPPORTED error will be
	 *            returned.</p>
	 * @param filterQuery
	 *            <p style="margin-left: 20px;"> The filterQuery specifies a
	 *            query in the form of the query language specified by the
	 *            filterQueryLanguage parameter. If this value is not null, the
	 *            filterQueryLanguage parameter must be non-null. This value
	 *            will act as an additional filter on the result set.
	 * 
	 *            If the implementation does not support the query language
	 *            specified, the CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED error will
	 *            be returned.
	 * 
	 *            If the implementation does not support filtered enumerations,
	 *            the CIM_ERR_FILTERED_ENUMERATION_NOT_SUPPORTED error will be
	 *            returned.</p>
	 * @param returnQueryResultClass
	 *            <p style="margin-left: 20px;"> The returnQueryResultClass
	 *            controls whether a class definition is returned in
	 *            QueryResultClass. If it is set to false, QueryResultClass
	 *            shall be set to NULL on output. If it is set to true, the
	 *            value of the QueryResultClass on output shall be a class
	 *            definition that defines the properties (columns) of each row
	 *            of the query result.</p>
	 * @param timeout
	 *            <p style="margin-left: 20px;"> This input parameter determines
	 *            the minimum time the CIM server shall maintain the open
	 *            enumeration session after the last Open or Pull operation
	 *            (unless the enumeration session is closed). If the operation
	 *            timeout is exceeded, the implementation may close the
	 *            enumeration session at any time, releasing any resources
	 *            allocated to the enumeration session. An OperationTimeout of 0
	 *            means that there is no operation timeout. That is, the
	 *            enumeration session is never closed based on time. If
	 *            OperationTimeout is NULL, the implementation shall choose an
	 *            operation timeout. All other values for OperationTimeout
	 *            specify the operation timeout in seconds. A implementation may
	 *            restrict the set of allowable values for OperationTimeout.
	 *            Specifically, the implementation may not allow 0 (no timeout).
	 *            If the specified value is not an allowable value, the
	 *            implementation shall return failure with the status code
	 *            CIM_ERR_INVALID_OPERATION_TIMEOUT.</p>
	 * @param continueOnError
	 *            <p style="margin-left: 20px;"> If true, requests that the
	 *            operation resume when an error is received. If a
	 *            implementation does not support continuation on error and
	 *            ContinueOnError is true, it shall throw a WBEMException with
	 *            the status code CIM_ERR_CONTINUATION_ON_ERROR_NOT_SUPPORTED.
	 *            If a implementation supports continuation on error and
	 *            ContinueOnError is true, the enumeration session shall remain
	 *            open when a Pull operation fails, and any subsequent
	 *            successful Pull operations shall return the set of elements
	 *            that would have been returned if the failing Pull operations
	 *            were successful. This behavior is subject to the consistency
	 *            rules defined for pulled enumerations. If ContinueOnError is
	 *            false, the enumeration session will be closed when either the
	 *            operation completes successfully or when a WBEMExcetpion is
	 *            thrown.</p>
	 * 
	 * @param maxObjectCount
	 *            <p style="margin-left: 20px;"> Defines the maximum number of
	 *            elements that this Open operation can return. The
	 *            implementation may deliver any number of elements up to
	 *            MaxObjects but shall not deliver more than MaxObjects
	 *            elements. An implementation may choose to never return any
	 *            elements during an Open operation, regardless of the value of
	 *            MaxObjectCount. Note that a CIM client can use a
	 *            MaxObjectCount value of 0 to specify that it does not want to
	 *            retrieve any instances in the Open operation.</p>
	 * @param queryResultClass
	 *            <p style="margin-left: 20px;">The queryResultClass output
	 *            parameter shall be set to NULL if the returnQueryResultClass
	 *            input parameter is set to false. Otherwise, it shall return a
	 *            class definition where each property of the class corresponds
	 *            to one entry of the query select list. The class definition
	 *            corresponds to one row of the query result. The class name of
	 *            this returned class shall be "CIM_QueryResult". This class
	 *            definition is valid only in the context of this enumeration.
	 *            </p>
	 * @return The return value of a successful Open operation is an array of
	 *         enumerated elements with a number of entries from 0 up to a
	 *         maximum defined by MaxObjects. These entries meet the criteria
	 *         defined in the Open operation. Note that returning no entries in
	 *         the array does not imply that the enumeration session is
	 *         exhausted. Client must evaluate the EnumerateResponse.isEnd() to
	 *         determine if there are more elements.
	 * 
	 * @throws UnsupportedOperationException
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is: <br>
	 *             <p style="margin-left: 20px;"> <code>
	 *              CIM_ERR_ACCESS_DENIED <br>CIM_ERR_SERVER_IS_SHUTTING_DOWN<br>
	 *             CIM_ERR_NOT_SUPPORTED <br>CIM_ERR_INVALID_NAMESPACE<br>
	 *             CIM_ERR_INVALID_OPERATION_TIMEOUT<br>
	 *             CIM_ERR_CONTINUATION_ON_ERROR_NOT_SUPPORTED<br>
	 *             CIM_ERR_INVALID_PARAMETER (including missing, duplicate,
	 *             unrecognized, or otherwise incorrect parameters)<br>
	 *             CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED (The requested filter
	 *             query language is not recognized)<br> CIM_ERR_INVALID_QUERY (The
	 *             filter query is not a valid query in the specified filter
	 *             query language.) <br>CIM_ERR_QUERY_FEATURE_NOT_SUPPORTED (The
	 *             query requires support for features that are not supported)<br>
	 *             CIM_ERR_FAILED (Some other unspecified error occurred) </p></code>
	 */
	public EnumerateResponse<CIMInstance> execQueryInstances(CIMObjectPath pObjectName,
			String filterQuery, String filterQueryLanguage, Boolean returnQueryResultClass,
			UnsignedInteger32 timeout, Boolean continueOnError, UnsignedInteger32 maxObjectCount,
			CIMClass queryResultClass) throws WBEMException;

	/**
	 * Returns the <code>CIMClass</code> for the specified <code>CIMObjectPath
	 * </code>.
	 * 
	 * @param pName
	 *            <p style="margin-left: 20px;"> The object path of the class to
	 *            be returned. Only the name space and class name components are
	 *            used. All other information (e.g. keys) is ignored. </p>
	 * @param pPropagated
	 *            <p style="margin-left: 20px;"> If <code>true</code>, only
	 *            elements (properties, methods, references) overridden or
	 *            defined in the class are included in the <code>CIMClass
	 * 		</code>returned. If
	 *            <code>false</code>, all elements of the class definition are
	 *            returned. </p>
	 * @param pIncludeQualifiers
	 *            <p style="margin-left: 20px;"> If <code>true</code>, all
	 *            Qualifiers for the class and its elements are included in the
	 *            <code>CIMClass</code> returned. If <code>false
	 * 		</code>, no Qualifier
	 *            information is contained in the <code>CIMClass
	 * 		</code> returned. </p>
	 * @param pIncludeClassOrigin
	 *            <p style="margin-left: 20px;"> The class origin attribute is
	 *            the name of the class that either originally defined or
	 *            overrode the definition of the property or method. If
	 *            <code>true</code>, the class Origin attribute will be present
	 *            on all <code>CIMClasses</code>. If <code>false</code>, the
	 *            class origin will not be present.
	 * @param pPropertyList
	 *            <p style="margin-left: 20px;"> An array of property names used
	 *            to filter what is contained in the <code>CIMClass</code>
	 *            returned. The <code>CIMClass</code> returned <b> only</b>
	 *            contains elements for the properties of the names specified.
	 *            Duplicate and invalid property names are ignored and the
	 *            request is otherwise processed normally. An empty array
	 *            indicates that no properties should be returned. A <b>null</b>
	 *            value indicates that all properties should be returned.
	 * @return <code>CIMClass</code> meeting the criteria specified.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is:<br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 		CIM_ERR_ACCESS_DENIED<br>CIM_ERR_INVALID_NAMESPACE<br>
	 * 		CIM_ERR_INVALID_PARAMETER (including missing, duplicate, unrecognized 
	 * 		or otherwise incorrect parameters)<br>
	 * 		CIM_ERR_NOT_FOUND (the request CIM Class does not exist in the
	 * 		specified namespace)<br>
	 * 		CIM_ERR_FAILED (some other unspecified error occurred)
	 * 		</code> </p>
	 */
	public CIMClass getClass(CIMObjectPath pName, boolean pPropagated, boolean pIncludeQualifiers,
			boolean pIncludeClassOrigin, String[] pPropertyList) throws WBEMException;

	/**
	 * Get a <code>CIMInstance</code>.
	 * 
	 * @param pName
	 *            <p style="margin-left: 20px;"> The object path of the instance
	 *            to be returned. The Keys in this <code>CIMObjectPath</code>
	 *            must be populated. </p>
	 * @param pPropagated
	 *            <p style="margin-left: 20px;"> If <code>true</code>, only
	 *            elements (properties, methods, references) overridden or
	 *            defined in the class are included in the <code>CIMInstance
	 * 		returned. If <code>false</code>, all elements of the class definition
	 *            are returned.</p>
	 * @param pIncludeClassOrigin
	 *            <p style="margin-left: 20px;"> If <code>true</code>, the
	 *            CLASSORIGIN attribute will be present on all appropriate
	 *            elements in the <code>CIMInstance</code> returned. If
	 *            <code>false</code>, no CLASSORIGIN attributes are present in
	 *            the <code>
	 * 		CIMInstance</code> returned. CLASSORIGIN is attached to
	 *            an element (properties, methods, references) to indicate the
	 *            class in which it was first defined.</p>
	 * @param pPropertyList
	 *            <p style="margin-left: 20px;"> An array of property names used
	 *            to filter what is contained in the <code>CIMClass</code>
	 *            returned. The <code>CIMClass</code> returned <b> only</b>
	 *            contains elements for the properties of the names specified.
	 *            Duplicate and invalid property names are ignored and the
	 *            request is otherwise processed normally. An empty array
	 *            indicates that no properties should be returned. A <b>null</b>
	 *            value indicates that all properties should be returned.</p>
	 * @return <code>CIMInstance</code> identified by the <code>CIMObjectPath
	 * 			</code> specified.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is:<br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 		CIM_ERR_ACCESS_DENIED<br>
	 *  	CIM_ERR_NOT_SUPPORTED (provider does not support this method)<br>
	 * 		CIM_ERR_INVALID_NAMESPACE<br>
	 * 		CIM_ERR_INVALID_PARAMETER (for this method)<br>
	 * 		CIM_ERR_INVALID_CLASS (in this namespace)<br>
	 * 		CIM_ERR_NOT_FOUND (if instance does not exist)<br>
	 * 		CIM_ERR_FAILED (some other unspecified error occurred)
	 *		</code></p>
	 */
	public CIMInstance getInstance(CIMObjectPath pName, boolean pPropagated,
			boolean pIncludeClassOrigin, String[] pPropertyList) throws WBEMException;

	/**
	 * getInstancePaths will get the CIMObjectPaths using an enumeration
	 * context.
	 * 
	 * 
	 * @param path
	 *            <p style="margin-left: 20px;"> The CIMObjectPath representing
	 *            the namespace to be used. </p>
	 * @param context
	 *            <p style="margin-left: 20px;"> The enumeration context value
	 *            for the enumeration session to be used. </p>
	 * @param maxObjects
	 *            <p style="margin-left: 20px;"> Defines the maximum number of
	 *            elements that this Open operation can return. The
	 *            implementation may deliver any number of elements up to
	 *            MaxObjects but shall not deliver more than MaxObjects
	 *            elements. An implementation may choose to never return any
	 *            elements during an Open operation, regardless of the value of
	 *            MaxObjectCount. </p>
	 * @return EnumerateResponse that includes zero or more CIMObjectPath
	 *         objects.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is: <br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 
	 *             CIM_ERR_ACCESS_DENIED <br>CIM_ERR_SERVER_IS_SHUTTING_DOWN<br>
	 *             CIM_ERR_NOT_SUPPORTED<br> CIM_ERR_INVALID_NAMESPACE<br>
	 *             CIM_ERR_INVALID_PARAMETER<br> CIM_ERR_INVALID_ENUMERATION_CONTEXT<br>
	 *             CIM_ERR_SERVER_LIMITS_EXCEEDED<br>
	 *             CIM_ERR_PULL_HAS_BEEN_ABANDONED<br> CIM_ERR_FAILED (Some other
	 *             unspecified error occurred)<br> </code> </p>
	 */
	public EnumerateResponse<CIMObjectPath> getInstancePaths(CIMObjectPath path, String context,
			UnsignedInteger32 maxObjects) throws WBEMException;

	/**
	 * getInstances will get the instances from an enumeration session started
	 * by execQueryInstances().
	 * 
	 * @param path
	 *            <p style="margin-left: 20px;"> The CIMObjectPath representing
	 *            the namespace to be used. </p>
	 * @param context
	 *            <p style="margin-left: 20px;"> The enumeration context value
	 *            for the enumeration session to be used. </p>
	 * @param maxObjects
	 *            <p style="margin-left: 20px;"> Defines the maximum number of
	 *            elements that this Open operation can return. The
	 *            implementation may deliver any number of elements up to
	 *            MaxObjects but shall not deliver more than MaxObjects
	 *            elements. An implementation may choose to never return any
	 *            elements during an Open operation, regardless of the value of
	 *            MaxObjectCount. Note that a CIM client can use a
	 *            MaxObjectCount value of 0 to specify that it does not want to
	 *            retrieve any instances in the Open operation. </p>
	 * @return EnumerateResponse that includes zero or more CIMObjectPath
	 *         objects.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is: <br>
	 *             <p style="margin-left: 20px;"><code>
	 * 
	 *             CIM_ERR_ACCESS_DENIED<br> CIM_ERR_SERVER_IS_SHUTTING_DOWN<br>
	 *             CIM_ERR_NOT_SUPPORTED <br>CIM_ERR_INVALID_NAMESPACE<br>
	 *             CIM_ERR_INVALID_PARAMETER <br>CIM_ERR_INVALID_ENUMERATION_CONTEXT<br>
	 *             CIM_ERR_SERVER_LIMITS_EXCEEDED<br>
	 *             CIM_ERR_PULL_HAS_BEEN_ABANDONED <br> CIM_ERR_FAILED <br></code>
	 *             </p>
	 */
	public EnumerateResponse<CIMInstance> getInstances(CIMObjectPath path, String context,
			UnsignedInteger32 maxObjects) throws WBEMException;

	/**
	 * getInstancesWithPath will use the enumeration context provided to get the
	 * next set of instances for the enumeration session.
	 * 
	 * @param path
	 *            <p style="margin-left: 20px;"> The CIMObjectPath representing
	 *            the namespace to be used. </p>
	 * @param context
	 *            <p style="margin-left: 20px;"> The enumeration context value
	 *            for the enumeration session to be used. </p>
	 * @param maxObjects
	 *            <p style="margin-left: 20px;"> Defines the maximum number of
	 *            elements that this Open operation can return. The
	 *            implementation may deliver any number of elements up to
	 *            MaxObjects but shall not deliver more than MaxObjects
	 *            elements. An implementation may choose to never return any
	 *            elements during an Open operation, regardless of the value of
	 *            MaxObjectCount. Note that a CIM client can use a
	 *            MaxObjectCount value of 0 to specify that it does not want to
	 *            retrieve any instances in the Open operation. </p>
	 * @return EnumerateResponse that includes zero or more CIMObjectPath
	 *         objects.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is: <br>
	 *             <p style="margin-left: 20px;"><code>
	 * 
	 *             CIM_ERR_ACCESS_DENIED <br>CIM_ERR_SERVER_IS_SHUTTING_DOWN<br>
	 *             CIM_ERR_NOT_SUPPORTED<br> CIM_ERR_INVALID_NAMESPACE<br>
	 *             CIM_ERR_INVALID_PARAMETER <br>CIM_ERR_INVALID_ENUMERATION_CONTEXT<br>
	 *             CIM_ERR_SERVER_LIMITS_EXCEEDED<br>
	 *             CIM_ERR_PULL_HAS_BEEN_ABANDONED <br>CIM_ERR_FAILED (Some other
	 *             unspecified error occurred) <br></code></p>
	 */
	public EnumerateResponse<CIMInstance> getInstancesWithPath(CIMObjectPath path, String context,
			UnsignedInteger32 maxObjects) throws WBEMException;

	/**
	 * Get protocol specific property values. Please refer to the documentation
	 * for the specific protocol for a list of properties supported.
	 * 
	 * @param pKey
	 *            The name of the property
	 * @return The value of the property.
	 */
	public String getProperty(String pKey);

	/**
	 * Get a <code>CIMQualifierType</code>.
	 * 
	 * @param pName
	 *            <p style="margin-left: 20px;"> <code>CIMObjectPath</code> that
	 *            identifies the <code>CIMQualifierType
	 * 		</code> to return. </p>
	 * @return The <code>CIMQualifierType</code> object
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is:<br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 		CIM_ERR_ACCESS_DENIED<br>CIM_ERR_NOT_SUPPORTED<br>
	 * 		CIM_ERR_INVALID_NAMESPACE<br>
	 * 		CIM_ERR_INVALID_PARAMETER (including missing, duplicate, unrecognized 
	 * 		or otherwise incorrect parameters)<br>
	 * 		CIM_ERR_NOT_FOUND (the requested Qualifier declaration did not exist)
	 * 		<br>
	 * 		CIM_ERR_FAILED (some other unspecified error occurred)
	 * 		</code> </p>
	 */
	public CIMQualifierType<?> getQualifierType(CIMObjectPath pName) throws WBEMException;

	/**
	 * Initialize the client connection. This must be called before any
	 * operations.
	 * 
	 * @param pName
	 *            <p style="margin-left: 20px;"> The protocol and host to use
	 *            (e.g. http://192.168.1.128/). Any other fields will be
	 *            ignored. </p>
	 * @param pSubject
	 *            <p style="margin-left: 20px;"> The principal/credential pairs
	 *            for this connection. </p>
	 * @param pLocales
	 *            <p style="margin-left: 20px;"> An array of locales in order of
	 *            priority of preference. </p>
	 * @throws IllegalArgumentException
	 *             <p style="margin-left: 20px;"> If the host or scheme portion
	 *             of the object path is null. If the protocol is not supported.
	 *             </p>
	 * @throws WBEMException
	 *             If the protocol adapter or security can not be initialized.
	 */
	public void initialize(CIMObjectPath pName, Subject pSubject, Locale[] pLocales)
			throws IllegalArgumentException, WBEMException;

	/**
	 * Executes the specified method on the specified object.
	 * 
	 * @param pName
	 *            <p style="margin-left: 20px;"> CIM object path of the object
	 *            whose method must be invoked. It must include all of the keys.
	 *            </p>
	 * @param pMethodName
	 *            <p style="margin-left: 20px;"> the name of the method to be
	 *            invoked. </p>
	 * @param pInputArguments
	 *            <p style="margin-left: 20px;"> the <code>CIMArgument</code>
	 *            array of method input parameters. </p>
	 * @param pOutputArguments
	 *            <p style="margin-left: 20px;"> the <code>CIMArgument</code>
	 *            array of method output parameters. The array should be
	 *            allocated large enough to hold all returned parameters, but
	 *            should not initialize any elements. </p>
	 * @return The return value of the specified method.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is:<br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 		CIM_ERR_ACCESS_DENIED<br>
	 * 		CIM_ERR_NOT_SUPPORTED (CIM Server <b>DOES NOT</b> support <b>ANY</b>
	 * 		Extrinsic Method Invocation)<br>
	 * 		CIM_ERR_INVALID_NAMESPACE<br>
	 * 		CIM_ERR_INVALID_PARAMETER (for this method)<br>
	 * 		CIM_ERR_NOT_FOUND (if instance does not exist)<br>
	 * 		CIM_ERR_METHOD_NOT_FOUND<br>CIM_ERR_METHOD_NOT_AVAILABLE<br>
	 * 		CIM_ERR_FAILED (some other unspecified error occurred)
	 * 		</code> </p>
	 */
	public Object invokeMethod(CIMObjectPath pName, String pMethodName,
			CIMArgument<?>[] pInputArguments, CIMArgument<?>[] pOutputArguments)
			throws WBEMException;

	/**
	 * Modify the <code>CIMClass</code>.
	 * 
	 * @param pClass
	 *            <code>CIMClass</code> to be modified
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is:<br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 		CIM_ERR_ACCESS_DENIED<br>CIM_ERR_NOT_SUPPORTED<br>
	 * 		CIM_ERR_INVALID_NAMESPACE<br>
	 * 		CIM_ERR_INVALID_PARAMETER (including missing, duplicate, unrecognized 
	 * 		or otherwise incorrect parameters)<br>
	 * 		CIM_ERR_INVALID_SUPERCLASS (the putative CIM Class declares a
	 * 		non-existent superclass)<br>
	 * 		CIM_ERR_CLASS_HAS_CHILDREN (the modification could not be performed
	 * 		because it was not possible to update the subclasses of the Class
	 * 		in a consistent fashion)<br>
	 * 		CIM_ERR_CLASS_HAS_INSTANCES (the modification could not be performed
	 * 		because it was not possible to update the instances of the Class in
	 * 		a consistent fashion)<br>  
	 * 		CIM_ERR_FAILED (some other unspecified error occurred)
	 * 		</code> </p>
	 */
	public void modifyClass(CIMClass pClass) throws WBEMException;

	/**
	 * Modify some or all of the properties of the specified
	 * <code>CIMInstance</code>.
	 * 
	 * @param ci
	 *            <p style="margin-left: 20px;"><code>CIMInstance</code> to be
	 *            modified. All Keys must be populated.</p>
	 * @param propertyList
	 *            <p style="margin-left: 20px;"> An array of property names used
	 *            to specify which values from the <code>CIMInstance</code>
	 *            specified to set. Properties not specified in this list but
	 *            set in the <code>CIMInstance</code> specified are not
	 *            modified. Duplicate and invalid property names are ignored and
	 *            the request is otherwise processed normally. An <b>empty
	 *            array</b> indicates that no properties should be modified. A
	 *            <b>null</b> value indicates that all properties should be
	 *            modified. </p>
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is:<br>
	 *             <p style="margin-left: 20px;"> <code>
	 * CIM_ERR_ACCESS_DENIED<br>
	 * CIM_ERR_NOT_SUPPORTED (provider does not support this method)<br>
	 * CIM_ERR_INVALID_NAMESPACE<br>
	 * CIM_ERR_INVALID_PARAMETER (for this method)<br>
	 * CIM_ERR_INVALID_CLASS (in this namespace)<br>
	 * CIM_ERR_NOT_FOUND (if instance does not exist)<br>
	 * CIM_ERR_NO_SUCH_PROPERTY (in this instance)<br>
	 * CIM_ERR_FAILED (some other unspecified error occurred)<br>
	 * </code>
	 */
	public void modifyInstance(CIMInstance ci, String[] propertyList) throws WBEMException;

	/**
	 * Enumerates the Association classes that refer to a specified source CIM
	 * Class.
	 * 
	 * @param pObjectName
	 *            <p style="margin-left: 20px;"> CIMObjectPath defining the
	 *            source CIM class whose referring classes are to be returned.
	 *            objectNames shall contain the scheme, host, namespace and
	 *            object name (class name).</p>
	 * @param pResultClass
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid CIM Class name or be <b>null</b>. It filters
	 *            the Objects returned to contain only the Objects of this Class
	 *            name or one of its subclasses. </p>
	 * @param pRole
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid Property name or be <b>null</b>. It filters
	 *            the Objects returned to contain only Objects referring to the
	 *            source Object via a Property with the specified name. If
	 *            "Antecedent" is specified, then only Associations in which the
	 *            source Object is the "Antecedent" reference are returned. </p>
	 * @param pIncludeQualifiers
	 *            <p style="margin-left: 20px;"> If true, all Qualifiers for
	 *            each Object (including Qualifiers on the Object and on any
	 *            returned Properties) shall be included in the classes
	 *            returned. If false, no Qualifiers shall be present in each
	 *            class returned. </p>
	 * @param pIncludeClassOrigin
	 *            <p style="margin-left: 20px;"> The class origin attribute is
	 *            the name of the class that first defined the property or
	 *            method. If true, the class Origin attribute will be present
	 *            for each property and method on all classes returned. If
	 *            false, the class origin will not be present. </p>
	 * @param pPropertyList
	 *            <p style="margin-left: 20px;"> An array of property names used
	 *            to filter what is contained in the Objects returned. Each
	 *            CIMClass returned shall only contains elements for the
	 *            properties of the names specified. Duplicate and invalid
	 *            property names are ignored and the request is otherwise
	 *            processed normally. An empty array indicates that no
	 *            properties should be included in the classes returned. A null
	 *            value indicates that all properties should be contained in the
	 *            classes returned.</p>
	 * @return If successful, a CloseableIterator referencing zero or more
	 *         CIMClasses meeting the specified criteria.
	 * 
	 * @throws UnsupportedOperationException
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes shall be
	 *             returned along with zero or more CIM_Error instances. The
	 *             ORDERED list is: <br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 		CIM_ERR_ACCESS_DENIED<br>CIM_ERR_NOT_SUPPORTED<br>
	 * 		CIM_ERR_INVALID_NAMESPACE<br>
	 * 		CIM_ERR_INVALID_PARAMETER (including missing, duplicate, unrecognized 
	 * 		or otherwise incorrect parameters)<br>
	 * 		CIM_ERR_FAILED (some other unspecified error occurred)
	 * 		</code> </p>
	 */

	CloseableIterator<CIMClass> referenceClasses(CIMObjectPath pObjectName, String pResultClass,
			String pRole, boolean pIncludeQualifiers, boolean pIncludeClassOrigin,
			String[] pPropertyList) throws WBEMException;

	/**
	 * Enumerates the Association instances that refer to a specified source CIM
	 * Instance.
	 * 
	 * @param pObjectName
	 *            <p style="margin-left: 20px;"> CIMObjectPath defining the
	 *            source CIM Instance whose referring instances are to be
	 *            returned. The objectName shall include the host, object name
	 *            and keys.
	 * @param pResultClass
	 *            <p style="margin-left: 20px;"> This string shall either
	 *            contain a valid CIM Class name or be null. It filters the
	 *            instances returned to contain only the instances of this Class
	 *            name or one of its subclasses. </p>
	 * @param pRole
	 *            <p style="margin-left: 20px;"> This string shall either
	 *            contain a valid Property name or be null. The role filters the
	 *            instances returned to contain only instances referring to the
	 *            source instance via a property with the specified name. For
	 *            example, If "Antecedent" is specified, then only Associations
	 *            in which the source instance is the "Antecedent" reference are
	 *            returned.</p>
	 * @param pIncludeClassOrigin
	 *            <p style="margin-left: 20px;"> The class origin attribute is
	 *            the name of the class that first defined the property. If
	 *            true, the class Origin attribute will be present for each
	 *            property and on all instances returned. If false, the class
	 *            origin will not be present.</p>
	 * @param pPropertyList
	 *            <p style="margin-left: 20px;"> An array of property names used
	 *            to filter what is contained in the instances returned. Each
	 *            CIMInstance returned shall only contain elements for the
	 *            properties of the names specified. Duplicate and invalid
	 *            property names are ignored and the request is otherwise
	 *            processed normally. An empty array indicates that no
	 *            properties should be included in the instances returned. A
	 *            null value indicates that all properties supported shall be
	 *            contained in the instance returned. </p>
	 * @return If successful, a CloseableIterator referencing zero or more
	 *         CIMInstances meeting the specified criteria.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes shall be
	 *             returned along with zero or more CIM_Error instances. The
	 *             ORDERED list is: <br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 		CIM_ERR_ACCESS_DENIED<br>CIM_ERR_NOT_SUPPORTED<br>
	 * 		CIM_ERR_INVALID_NAMESPACE<br>
	 * 		CIM_ERR_INVALID_PARAMETER (including missing, duplicate, unrecognized 
	 * 		or otherwise incorrect parameters)<br>
	 * 		CIM_ERR_FAILED (some other unspecified error occurred)
	 * 		</code> </p>
	 */
	CloseableIterator<CIMInstance> referenceInstances(CIMObjectPath pObjectName,
			String pResultClass, String pRole, boolean pIncludeClassOrigin, String[] pPropertyList)
			throws WBEMException;

	/**
	 * Enumerates the <code>CIMObjectPath</code>s of Association Objects that
	 * are refer to a particular source CIM Object. If the source Object is a
	 * CIM Class, then an <code>Enumeration</code> of <code>CIMObjectPath</code>
	 * s of the Association classes that refer to the source Object is returned.
	 * If the source Object is a CIM Instance, then an <code>Enumeration</code>
	 * of <code>
	 * CIMObjectPath</code>s of the <code>CIMInstance</code> objects that
	 * refer to the source Object is returned.
	 * 
	 * @param pObjectName
	 *            <p style="margin-left: 20px;"> <code>CIMObjectPath</code>
	 *            defining the source CIM Object whose referring Objects are to
	 *            be returned. This argument may contain either a Class name or
	 *            the modelpath of an Instance. (i.e. Keys populated) </p>
	 * @param pResultClass
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid CIM Class name or be <b>null</b>. It filters
	 *            the Objects returned to contain only the Objects of this Class
	 *            name or one of its subclasses. </p>
	 * @param pRole
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid Property name or be <b>null</b>. It filters
	 *            the Objects returned to contain only Objects referring to the
	 *            source Object via a Property with the specified name. If
	 *            "Antecedent" is specified, then only Associations in which the
	 *            source Object is the "Antecedent" reference are returned. </p>
	 * @return If successful, a <code>CloseableIterator</code> referencing zero
	 *         or more <code>CIMObjectPath</code>s of <code>CIMClass</code>es or
	 *         <code>CIMInstance</code>s meeting the specified criteria.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is:<br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 		CIM_ERR_ACCESS_DENIED<br>CIM_ERR_NOT_SUPPORTED<br>
	 * 		CIM_ERR_INVALID_NAMESPACE<br>
	 * 		CIM_ERR_INVALID_PARAMETER (including missing, duplicate, unrecognized 
	 * 		or otherwise incorrect parameters)<br>
	 * 		CIM_ERR_FAILED (some other unspecified error occurred)
	 * 		</code> </p>
	 */
	public CloseableIterator<CIMObjectPath> referenceNames(CIMObjectPath pObjectName,
			String pResultClass, String pRole) throws WBEMException;

	/**
	 * referencePaths will start an enumeration session for association
	 * instances that have references that refer to the instance defined in the
	 * instancePath parameter and return zero or more CIMObjectPath objects.
	 * 
	 * @param instancePath
	 *            <p style="margin-left: 20px;">The CIMObjectPath for the
	 *            instance for which the enumeration is to be performed</p>
	 * @param filterQueryLanguage
	 *            <p style="margin-left: 20px;"> The filterQueryLanguage
	 *            represents the query language for the filterQuery argument.
	 *            This must be left null if a filterQuery is not supplied.
	 * 
	 *            If the implementation does not support the query language
	 *            specified, the CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED error will
	 *            be returned.
	 * 
	 *            If the implementation does not support filtered enumerations,
	 *            the CIM_ERR_FILTERED_ENUMERATION_NOT_SUPPORTED error will be
	 *            returned. </p>
	 * @param resultClass
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid CIM Class name or be <b>null</b>. It filters
	 *            the Objects returned to contain only the Objects of this Class
	 *            name or one of its subclasses. </p>
	 * @param role
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid Property name or be <b>null</b>. It filters
	 *            the Objects returned to contain only Objects referring to the
	 *            source Object via a Property with the specified name. If
	 *            "Antecedent" is specified, then only Associations in which the
	 *            source Object is the "Antecedent" reference are returned. </p>
	 * @param filterQuery
	 *            <p style="margin-left: 20px;">The filterQuery specifies a
	 *            query in the form of the query language specified by the
	 *            filterQueryLanguage parameter. If this value is not null, the
	 *            filterQueryLanguage parameter must be non-null. This value
	 *            will act as an additional filter on the result set.
	 * 
	 *            If the implementation does not support the query language
	 *            specified, the CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED error will
	 *            be returned.
	 * 
	 *            If the implementation does not support filtered enumerations,
	 *            the CIM_ERR_FILTERED_ENUMERATION_NOT_SUPPORTED error will be
	 *            returned. </p>
	 * @param timeout
	 *            <p style="margin-left: 20px;"> This input parameter determines
	 *            the minimum time the CIM server shall maintain the open
	 *            enumeration session after the last Open or Pull operation
	 *            (unless the enumeration session is closed). If the operation
	 *            timeout is exceeded, the implementation may close the
	 *            enumeration session at any time, releasing any resources
	 *            allocated to the enumeration session. An OperationTimeout of 0
	 *            means that there is no operation timeout. That is, the
	 *            enumeration session is never closed based on time. If
	 *            OperationTimeout is NULL, the implementation shall choose an
	 *            operation timeout. All other values for OperationTimeout
	 *            specify the operation timeout in seconds. A implementation may
	 *            restrict the set of allowable values for OperationTimeout.
	 *            Specifically, the implementation may not allow 0 (no timeout).
	 *            If the specified value is not an allowable value, the
	 *            implementation shall return failure with the status code
	 *            CIM_ERR_INVALID_OPERATION_TIMEOUT. </p>
	 * @param continueOnError
	 *            <p style="margin-left: 20px;"> If true, requests that the
	 *            operation resume when an error is received. If a
	 *            implementation does not support continuation on error and
	 *            ContinueOnError is true, it shall throw a WBEMException with
	 *            the status code CIM_ERR_CONTINUATION_ON_ERROR_NOT_SUPPORTED.
	 *            If a implementation supports continuation on error and
	 *            ContinueOnError is true, the enumeration session shall remain
	 *            open when a Pull operation fails, and any subsequent
	 *            successful Pull operations shall return the set of elements
	 *            that would have been returned if the failing Pull operations
	 *            were successful. This behavior is subject to the consistency
	 *            rules defined for pulled enumerations. If ContinueOnError is
	 *            false, the enumeration session will be closed when either the
	 *            operation completes successfully or when a WBEMExcetpion is
	 *            thrown. </p>
	 * @param maxObjects
	 *            <p style="margin-left: 20px;">Defines the maximum number of
	 *            elements that this Open operation can return. The
	 *            implementation may deliver any number of elements up to
	 *            MaxObjects but shall not deliver more than MaxObjects
	 *            elements. An implementation may choose to never return any
	 *            elements during an Open operation, regardless of the value of
	 *            MaxObjectCount. Note that a CIM client can use a
	 *            MaxObjectCount value of 0 to specify that it does not want to
	 *            retrieve any instances in the Open operation. </p>
	 * @return The return value of a successful Open operation is an array of
	 *         enumerated elements with a number of entries from 0 up to a
	 *         maximum defined by MaxObjects. These entries meet the criteria
	 *         defined in the Open operation. Note that returning no entries in
	 *         the array does not imply that the enumeration session is
	 *         exhausted. Client must evaluate the EnumerateResponse.isEnd() to
	 *         determine if there are more elements.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is: <br>
	 *             <p style="margin-left: 20px;"><code>
	 * 
	 *             CIM_ERR_ACCESS_DENIED<br> CIM_ERR_SERVER_IS_SHUTTING_DOWN<br>
	 *             CIM_ERR_NOT_SUPPORTED <br>CIM_ERR_INVALID_NAMESPACE<br>
	 *             CIM_ERR_INVALID_OPERATION_TIMEOUT<br>
	 *             CIM_ERR_CONTINUATION_ON_ERROR_NOT_SUPPORTED<br>
	 *             CIM_ERR_INVALID_PARAMETER<br> CIM_ERR_NOT_FOUND (The source
	 *             instance was not found)<br>
	 *             CIM_ERR_FILTERED_ENUMERATION_NOT_SUPPORTED<br>
	 *             CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED CIM_ERR_INVALID_QUERY<br>
	 *             CIM_ERR_FAILED (Some other unspecified error occurred)<br> </code>
	 *             </p>
	 */
	public EnumerateResponse<CIMObjectPath> referencePaths(CIMObjectPath instancePath,
			String resultClass, String role, String filterQueryLanguage, String filterQuery,
			UnsignedInteger32 timeout, boolean continueOnError, UnsignedInteger32 maxObjects)
			throws WBEMException;

	/**
	 * This function will be deprecated soon. Use refrenceClasses to enumerate
	 * CIM Classes and refrenceInstances to enumerate CIM Instances.
	 * 
	 * Enumerates the Association Objects that refer to a specified source CIM
	 * Object. If the source Object is a CIM Class, an <code>Enumeration</code>
	 * of <code>CIMClass</code> objects is returned containing the Association
	 * classes that refer to the source Object. If the source Object is a CIM
	 * Instance, an <code>Enumeration</code> of <code>CIMInstance</code> objects
	 * is returned containing the Association class instances that refer to the
	 * source Object.
	 * 
	 * @param pObjectName
	 *            <p style="margin-left: 20px;"> <code>CIMObjectPath</code>
	 *            defining the source CIM Object whose referring Objects are to
	 *            be returned. This argument may contain either a Class name or
	 *            the modelpath of an Instance. (i.e. Keys populated) </p>
	 * @param pResultClass
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid CIM Class name or be <b>null</b>. It filters
	 *            the Objects returned to contain only the Objects of this Class
	 *            name or one of its subclasses. </p>
	 * @param pRole
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid Property name or be <b>null</b>. It filters
	 *            the Objects returned to contain only Objects referring to the
	 *            source Object via a Property with the specified name. If
	 *            "Antecedent" is specified, then only Associations in which the
	 *            source Object is the "Antecedent" reference are returned. </p>
	 * @param pIncludeQualifiers
	 *            <p style="margin-left: 20px;"> If <code>true</code>, all
	 *            Qualifiers for each Object (including Qualifiers on the Object
	 *            and on any returned Properties) <b>MUST</b> be included in the
	 *            Objects returned. If <code>false</code>, no Qualifiers are
	 *            present in each Object returned. </p>
	 * @param pIncludeClassOrigin
	 *            <p style="margin-left: 20px;"> If <code>true</code>, the
	 *            CLASSORIGIN attribute will be present on all appropriate
	 *            elements in the Objects returned. If <code>false</code>, no
	 *            CLASSORIGIN attributes are present in the Objects returned.
	 *            CLASSORIGIN is attached to an element (properties, methods,
	 *            references) to indicate the class in which it was first
	 *            defined. </p>
	 * @param pPropertyList
	 *            <p style="margin-left: 20px;"> An array of property names used
	 *            to filter what is contained in the Objects returned. Each
	 *            <code>CIMClass</code> or <code>CIMInstance</code> returned
	 *            <b>only</b> contains elements for the properties of the names
	 *            specified. Duplicate and invalid property names are ignored
	 *            and the request is otherwise processed normally. An empty
	 *            array indicates that no properties should be included in the
	 *            Objects returned. A <b>null</b> value indicates that all
	 *            properties should be contained in the Objects returned.
	 *            <b>NOTE:</b> Properties should <b>not</b> be specified in this
	 *            parameter unless a <b>non-null</b> value is specified in the
	 *            <code>resultClass</code> parameter. </p>
	 * @return If successful, a <code>CloseableIterator</code> referencing zero
	 *         or more <code>CIMClass</code> or <code>CIMInstance</code>s
	 *         meeting the specified criteria.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is:<br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 		CIM_ERR_ACCESS_DENIED<br>CIM_ERR_NOT_SUPPORTED<br>
	 * 		CIM_ERR_INVALID_NAMESPACE<br>
	 * 		CIM_ERR_INVALID_PARAMETER (including missing, duplicate, unrecognized 
	 * 		or otherwise incorrect parameters)<br>
	 * 		CIM_ERR_FAILED (some other unspecified error occurred)
	 * 		</code> </p>
	 */
	public CloseableIterator references(CIMObjectPath pObjectName, String pResultClass,
			String pRole, boolean pIncludeQualifiers, boolean pIncludeClassOrigin,
			String[] pPropertyList) throws WBEMException;

	/**
	 * references will start an enumeration session for association instances
	 * that have references that refer to the instance defined in the
	 * instancePath parameter and return zero or more CIMInstance objects.
	 * 
	 * @param instancePath
	 *            <p style="margin-left: 20px;">The CIMObjectPath for the
	 *            instance for which the enumeration is to be performed. </p>
	 * @param resultClass
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid CIM Class name or be <b>null</b>. It filters
	 *            the Objects returned to contain only the Objects of this Class
	 *            name or one of its subclasses. </p>
	 * @param role
	 *            <p style="margin-left: 20px;"> This string <b>MUST</b> either
	 *            contain a valid Property name or be <b>null</b>. It filters
	 *            the Objects returned to contain only Objects referring to the
	 *            source Object via a Property with the specified name. If
	 *            "Antecedent" is specified, then only Associations in which the
	 *            source Object is the "Antecedent" reference are returned. </p>
	 * @param includeClassOrigin
	 *            <p style="margin-left: 20px;"> If <code>true</code>, the
	 *            CLASSORIGIN attribute will be present on all appropriate
	 *            elements in the Objects returned. If <code>false</code>, no
	 *            CLASSORIGIN attributes are present in the Objects returned.
	 *            CLASSORIGIN is attached to an element (properties, methods,
	 *            references) to indicate the class in which it was first
	 *            defined. </p>
	 * @param propertyList
	 *            <p style="margin-left: 20px;"> An array of property names used
	 *            to filter what is contained in the Objects returned. Each
	 *            <code>CIMClass</code> or <code>CIMInstance</code> returned
	 *            <b>only</b> contains elements for the properties of the names
	 *            specified. Duplicate and invalid property names are ignored
	 *            and the request is otherwise processed normally. An empty
	 *            array indicates that no properties should be included in the
	 *            Objects returned. A <b>null</b> value indicates that all
	 *            properties should be contained in the Objects returned.
	 *            <b>NOTE:</b> Properties should <b>not</b> be specified in this
	 *            parameter unless a <b>non-null</b> value is specified in the
	 *            <code>resultClass</code> parameter. </p>
	 * @param filterQueryLanguage
	 *            <p style="margin-left: 20px;"> The filterQueryLanguage
	 *            represents the query language for the filterQuery argument.
	 *            This must be left null if a filterQuery is not supplied.
	 * 
	 *            If the implementation does not support the query language
	 *            specified, the CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED error will
	 *            be returned.
	 * 
	 *            If the implementation does not support filtered enumerations,
	 *            the CIM_ERR_FILTERED_ENUMERATION_NOT_SUPPORTED error will be
	 *            returned. </p>
	 * @param filterQuery
	 *            <p style="margin-left: 20px;">The filterQuery specifies a
	 *            query in the form of the query language specified by the
	 *            filterQueryLanguage parameter. If this value is not null, the
	 *            filterQueryLanguage parameter must be non-null. This value
	 *            will act as an additional filter on the result set.
	 * 
	 *            If the implementation does not support the query language
	 *            specified, the CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED error will
	 *            be returned.
	 * 
	 *            If the implementation does not support filtered enumerations,
	 *            the CIM_ERR_FILTERED_ENUMERATION_NOT_SUPPORTED error will be
	 *            returned.
	 * @param timeout
	 *            <p style="margin-left: 20px;">This input parameter determines
	 *            the minimum time the CIM server shall maintain the open
	 *            enumeration session after the last Open or Pull operation
	 *            (unless the enumeration session is closed). If the operation
	 *            timeout is exceeded, the implementation may close the
	 *            enumeration session at any time, releasing any resources
	 *            allocated to the enumeration session. An OperationTimeout of 0
	 *            means that there is no operation timeout. That is, the
	 *            enumeration session is never closed based on time. If
	 *            OperationTimeout is NULL, the implementation shall choose an
	 *            operation timeout. All other values for OperationTimeout
	 *            specify the operation timeout in seconds. A implementation may
	 *            restrict the set of allowable values for OperationTimeout.
	 *            Specifically, the implementation may not allow 0 (no timeout).
	 *            If the specified value is not an allowable value, the
	 *            implementation shall return failure with the status code
	 *            CIM_ERR_INVALID_OPERATION_TIMEOUT.
	 * @param continueOnError
	 *            <p style="margin-left: 20px;"> If true, requests that the
	 *            operation resume when an error is received. If a
	 *            implementation does not support continuation on error and
	 *            ContinueOnError is true, it shall throw a WBEMException with
	 *            the status code CIM_ERR_CONTINUATION_ON_ERROR_NOT_SUPPORTED.
	 *            If a implementation supports continuation on error and
	 *            ContinueOnError is true, the enumeration session shall remain
	 *            open when a Pull operation fails, and any subsequent
	 *            successful Pull operations shall return the set of elements
	 *            that would have been returned if the failing Pull operations
	 *            were successful. This behavior is subject to the consistency
	 *            rules defined for pulled enumerations. If ContinueOnError is
	 *            false, the enumeration session will be closed when either the
	 *            operation completes successfully or when a WBEMExcetpion is
	 *            thrown. </p>
	 * @param maxObjects
	 *            <p style="margin-left: 20px;"> Defines the maximum number of
	 *            elements that this Open operation can return. The
	 *            implementation may deliver any number of elements up to
	 *            MaxObjects but shall not deliver more than MaxObjects
	 *            elements. An implementation may choose to never return any
	 *            elements during an Open operation, regardless of the value of
	 *            MaxObjectCount. Note that a CIM client can use a
	 *            MaxObjectCount value of 0 to specify that it does not want to
	 *            retrieve any instances in the Open operation. </p>
	 * @return The return value of a successful Open operation is an array of
	 *         enumerated elements with a number of entries from 0 up to a
	 *         maximum defined by MaxObjects. These entries meet the criteria
	 *         defined in the Open operation. Note that returning no entries in
	 *         the array does not imply that the enumeration session is
	 *         exhausted. Client must evaluate the EnumerateResponse.isEnd() to
	 *         determine if there are more elements.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is:<br>
	 *             <p style="margin-left: 20px;"><code>
	 *             CIM_ERR_ACCESS_DENIED <br>
	 *             CIM_ERR_SERVER_IS_SHUTTING_DOWN<br>
	 *             CIM_ERR_NOT_SUPPORTED <br>
	 *             CIM_ERR_INVALID_NAMESPACE<br>
	 *             CIM_ERR_INVALID_OPERATION_TIMEOUT<br>
	 *             CIM_ERR_CONTINUATION_ON_ERROR_NOT_SUPPORTED<br>
	 *             CIM_ERR_INVALID_PARAMETER <br>
	 *             CIM_ERR_NOT_FOUND (The source instance was not found)<br>
	 *             CIM_ERR_FILTERED_ENUMERATION_NOT_SUPPORTED<br>
	 *             CIM_ERR_QUERY_LANGUAGE_NOT_SUPPORTED <br>
	 *             CIM_ERR_INVALID_QUERY<br>
	 *             CIM_ERR_FAILED (Some other unspecified error occurred)<br> </code>
	 *             </p>
	 */
	public EnumerateResponse<CIMInstance> references(CIMObjectPath instancePath,
			String resultClass, String role, boolean includeClassOrigin, String[] propertyList,
			String filterQueryLanguage, String filterQuery, UnsignedInteger32 timeout,
			boolean continueOnError, UnsignedInteger32 maxObjects) throws WBEMException;

	/**
	 * Change the locales that were provided during initialization.
	 * 
	 * @param pLocales
	 *            An array of locales in order of priority of preference.
	 * @throws UnsupportedOperationException
	 *             If the method is not supported. Some protocols may only allow
	 *             the locales to be set during initialization. </p>
	 */
	public void setLocales(Locale[] pLocales) throws UnsupportedOperationException;

	/**
	 * Set protocol specific properties. For example, a protocol may support a
	 * timeout option for an operation. For CIM-XML, the timeout is
	 * javax.wbem.client.cim-xml.timeout Please refer to the documentation for
	 * the specific protocol for a list of properties supported.
	 * 
	 * @param pKey
	 *            The name of the property
	 * @param pValue
	 *            The value of the property
	 * @throws IllegalArgumentException
	 *             If the name is not a supported property name.
	 */
	public void setProperty(String pKey, String pValue);

	/**
	 * Add a <code>CIMQualifierType</code> to the specified namespace if it does
	 * not already exist. Otherwise, it modifies the qualifier type to the value
	 * specified.
	 * 
	 * @param pQualifierType
	 *            The CIM qualifier type to be added.
	 * @throws WBEMException
	 *             If unsuccessful, one of the following status codes
	 *             <b>must</b> be returned. The ORDERED list is:<br>
	 *             <p style="margin-left: 20px;"> <code>
	 * 		CIM_ERR_ACCESS_DENIED<br>CIM_ERR_NOT_SUPPORTED<br>
	 * 		CIM_ERR_INVALID_NAMESPACE<br>
	 * 		CIM_ERR_INVALID_PARAMETER (including missing, duplicate, unrecognized 
	 * 		or otherwise incorrect parameters)<br>
	 *		CIM_ERR_FAILED (some other unspecified error occurred)</p>
	 */
	public void setQualifierType(CIMQualifierType<?> pQualifierType) throws WBEMException;
}
