/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Endre Bak, ebak@de.ibm.com  
 * 
 * Change History
 * Flag       Date        Prog         Description
 *-------------------------------------------------------------------------------------------------
 *            2006-04-25  ebak         Initial commit
 *            2006-04-27  wolfalex     Full implementation 
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2899859    2009-11-18  blaschke-oss javax.wbem.client missing JSR48 credential/principal APIs
 */
package javax.wbem.client;

import java.security.Principal;

/**
 * This class implements a Java security Principal identity for a client user
 * identity that authenticates with a Unix username and login password. That is,
 * it represents the user's login identity on the remote server system which is
 * running the CIMOM.
 */
public class UserPrincipal extends Object implements Principal {

	private String iUserName;

	private String iHostName;

	/**
	 * This constructor accepts the user name.
	 * 
	 * @param userName
	 *            - The user login name.
	 * @throws IllegalArgumentException
	 *             - If the <code>userName</code> is <code>null</code>.
	 */
	public UserPrincipal(String userName) throws IllegalArgumentException {
		if (userName == null) throw new IllegalArgumentException("userName is null!");
		this.iUserName = userName;
	}

	/**
	 * This constructor accepts the user name and host name.
	 * 
	 * @param userName
	 *            - The user login name.
	 * @param hostName
	 *            - The host name.
	 * @throws IllegalArgumentException
	 *             - If the <code>userName</code> is <code>null</code>.
	 */
	public UserPrincipal(String userName, String hostName) throws IllegalArgumentException {
		if (userName == null) throw new IllegalArgumentException("userName is null!");
		this.iUserName = userName;
		this.iHostName = hostName;
	}

	/**
	 * The equals method checks if the specified object is the same principal as
	 * this object. The principals are equal if the specified object is an
	 * instance of <code>UserPrincipal</code> and the user name and
	 * authentication host name are the same.
	 * 
	 * @param otherPrincipal
	 *            - <code>Principal</code> instance to compare for equality.
	 * @return <code>true</code> if the object are equal; <code>false</code>
	 *         otherwise.
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object otherPrincipal) {
		if (!(otherPrincipal instanceof UserPrincipal)) return false;
		UserPrincipal that = (UserPrincipal) otherPrincipal;
		return (this.iUserName == null ? that.iUserName == null : this.iUserName
				.equalsIgnoreCase(that.iUserName))
				&& (this.iHostName == null ? that.iHostName == null : this.iHostName
						.equalsIgnoreCase(that.iHostName));
	}

	/**
	 * Return the host name associated with this principal.
	 * 
	 * @return The hostname.
	 */
	public String getHostName() {
		return this.iHostName;
	}

	/**
	 * Return the name of this principal identity; that is, return the login
	 * name.
	 * 
	 * @return The name of this principal identity.
	 * @see java.security.Principal#getName()
	 */
	public String getName() {
		return this.iUserName;
	}

	/**
	 * Return the principal's login user name.
	 * 
	 * @return The user login name.
	 */
	public String getUserName() {
		return this.iUserName;
	}

	/**
	 * The hashCode method returns an integer hash code to represent this
	 * principal. It can be used to test for non-equality, or as an index key in
	 * a hash table.
	 * 
	 * @return An integer hash code representing the principal.
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		return this.iUserName != null ? this.iUserName.hashCode() : 0;
	}

	/**
	 * The toString method returns a string representation of the principal
	 * suitable for displaying in messages. It should not be used for making
	 * authorization checks, however.
	 * 
	 * @return A printable string form of the principal identity.
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return this.iUserName;
	}

}
