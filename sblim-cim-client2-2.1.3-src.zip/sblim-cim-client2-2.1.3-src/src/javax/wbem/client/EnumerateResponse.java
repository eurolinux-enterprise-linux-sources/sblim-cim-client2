/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Ramandeep S Arora, IBM, arorar@us.ibm.com
 * 
 * Flag       Date        Prog         Description
 * -------------------------------------------------------------------------------
 * 2845211    2009-08-27  raman_arora  Pull Enumeration Feature (SAX Parser)
 */
package javax.wbem.client;

import javax.wbem.CloseableIterator;

/**
 * This class is a container that stores the information from a Pull request.
 * 
 * @param <E>
 *            Type Parameter
 */
public class EnumerateResponse<E> {

	private String pContext;

	private CloseableIterator<E> pResponses;

	private boolean pEnd;

	/**
	 * Ctor.
	 * 
	 * @param context
	 *            The enumeration context returned. This will be used for any
	 *            future calls for this particular enumeration.
	 * @param responses
	 *            The results of the operation.
	 * @param end
	 *            True if this is the last of the results; false otherwise.
	 */
	public EnumerateResponse(String context, CloseableIterator<E> responses, boolean end) {
		this.pContext = context;
		this.pResponses = responses;
		this.pEnd = end;
	}

	/**
	 * Get the context that can be used for a subsequent pull request
	 * 
	 * @return The Enumeration Context returned from the server.
	 */
	public String getContext() {
		return this.pContext;
	}

	/**
	 * Get the CloseableIterator for the returned CIM Elements.
	 * 
	 * @return CloseableIterator for the elements returned.
	 */
	public CloseableIterator<E> getResponses() {
		return this.pResponses;
	}

	/**
	 * If true, there are no more elements to be returned.
	 * 
	 * @return true: if this is the last of the results; false: otherwise.
	 */
	public boolean isEnd() {
		return this.pEnd;
	}

	// /**
	// * Note : This will iterate over response. So CloseableIterator.hasNext()
	// * will not retrun anything after this
	// */
	// public void debug() {
	// CloseableIterator<E> iterator = this.getResponses();
	// while (iterator.hasNext())
	// System.out.println(iterator.next());
	//
	// System.out.println("Enum Context =" + this.getContext());
	// System.out.println("Is End = " + this.isEnd());
	// System.out.println("Done...\n");
	// }
}
