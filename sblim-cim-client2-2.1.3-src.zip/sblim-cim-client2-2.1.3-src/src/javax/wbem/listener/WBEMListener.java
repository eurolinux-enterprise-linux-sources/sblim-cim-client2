/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Alexander Wolf-Reber, IBM, a.wolf-reber@de.ibm.com
 * 
 * Change History
 * Flag       Date        Prog         Description
 *------------------------------------------------------------------------------- 
 * 1565892    2006-12-14  lupusalex    Make SBLIM client JSR48 compliant
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 */

package javax.wbem.listener;

import java.io.IOException;

/**
 * The <code>WBEMListener</code> interface is used to add/remove WBEM Indication
 * Listeners. The implementation of a <code>WBEMListener</code> can be retrieved
 * from the <code>WBEMListenerFactor</code> by specifying the protocol to used
 * to listen for indications.
 */
public interface WBEMListener {

	/**
	 * Add a new listener using the specified port.
	 * 
	 * @param pListener
	 *            - The Indication Listener that will be called when an
	 *            indication is received.
	 * @param pPort
	 *            - The port to listen on. Use 0 to specify any available port.
	 * @param pTransport
	 *            - The transport to use (e.g. http or https).
	 * @return The port that was used.
	 * @throws IOException
	 *             - This exception is thrown when binding to pPort fails.
	 */
	public int addListener(IndicationListener pListener, int pPort, String pTransport)
			throws IOException;

	/**
	 * Add a new listener using the specified port.
	 * 
	 * @param pListener
	 *            - The Indication Listener that will be called when an
	 *            indication is received.
	 * @param pPort
	 *            - The port to listen on. Use 0 to specify any available port.
	 * @param pTransport
	 *            - The transport to use (e.g. http or https).
	 * @param localAddr
	 *            - The local IP address to bind to. This is only needed in
	 *            multi homed systems.
	 * @return The port that was used.
	 * @throws IOException
	 *             - This exception is thrown when binding to pPort fails.
	 */
	public int addListener(IndicationListener pListener, int pPort, String pTransport,
			String localAddr) throws IOException;

	/**
	 * Remove the listener associated with the specified port.
	 * 
	 * @param port
	 *            - The port.
	 */
	public void removeListener(int port);

}
