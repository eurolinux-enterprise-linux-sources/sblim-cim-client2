/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Endre Bak, IBM, ebak@de.ibm.com
 * 
 * Change History
 * Flag       Date        Prog         Description
 *------------------------------------------------------------------------------- 
 * 1565892    2007-01-08  ebak         Make SBLIM client JSR48 compliant
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2204488 	  2008-10-28  raman_arora  Fix code to remove compiler warnings
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2531371    2009-02-10  raman_arora  Upgrade client to JDK 1.5 (Phase 2)
 * 2763216    2009-04-14  blaschke-oss Code cleanup: visible spelling/grammar errors
 */

package org.sblim.cimclient;

import java.io.IOException;
import java.net.BindException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.wbem.listener.IndicationListener;
import javax.wbem.listener.WBEMListener;

import org.sblim.cimclient.internal.http.HttpConnectionHandler;
import org.sblim.cimclient.internal.http.HttpServerConnection;
import org.sblim.cimclient.internal.util.WBEMConfiguration;
import org.sblim.cimclient.internal.util.WBEMConstants;
import org.sblim.cimclient.internal.wbem.indications.CIMEventDispatcher;
import org.sblim.cimclient.internal.wbem.indications.CIMIndicationHandler;

/**
 * Class WBEMListenerSBLIM is the SBLIM implementation of the WBEMListener
 * interface.
 * 
 */
public class WBEMListenerSBLIM implements WBEMListener {

	/**
	 * The real implementation of a listener that starts a HTTP server and
	 * processes incoming indications
	 * 
	 */
	public static class WBEMListenerImpl {

		private IndicationListener iIndicationListener;

		private HttpServerConnection iConnection;

		/**
		 * Ctor.
		 * 
		 * @param pLocalAddress
		 *            The local address to bind the port to. If null the port is
		 *            bound to all local addresses. For use on multi-homed
		 *            systems
		 * 
		 * @param pPort
		 *            The port to listen on. If zero any free port will be
		 *            chosen.
		 * @param pSSL
		 *            SSL secured connection ?
		 * @param pIndicationListener
		 *            The indication listener to forward the incoming
		 *            indications to
		 * @param pProperties
		 *            The configuration
		 * @throws IOException
		 */
		public WBEMListenerImpl(String pLocalAddress, int pPort, boolean pSSL,
				IndicationListener pIndicationListener, Properties pProperties) throws IOException {
			iIndicationListener = pIndicationListener;
			CIMEventDispatcher eventDispatcher = new CIMEventDispatcher(iIndicationListener);
			CIMIndicationHandler indicationHandler = new CIMIndicationHandler(eventDispatcher);
			iConnection = new HttpServerConnection(new HttpConnectionHandler(indicationHandler),
					pLocalAddress, pPort, pSSL, pProperties != null ? new WBEMConfiguration(
							pProperties) : WBEMConfiguration.getGlobalConfiguration());
		}

		@Override
		protected void finalize() {
			stop();
		}

		/**
		 * start
		 */
		public void start() {
			this.iConnection.start();
		}

		/**
		 * stop
		 */
		public void stop() {
			this.iConnection.close();
		}

		/**
		 * Returns the listener we forward the indications to
		 * 
		 * @return The listener
		 */
		public IndicationListener getIndicationListener() {
			return this.iIndicationListener;
		}

		/**
		 * Returns the listener port
		 * 
		 * @return The listener port
		 */
		public int getListenerPort() {
			return this.iConnection.getPort();
		}

	}

	private final static WBEMListenerSBLIM INSTANCE = new WBEMListenerSBLIM();

	/**
	 * Returns the singleton instance
	 * 
	 * @return The instance
	 */
	public static WBEMListenerSBLIM getInstance() {
		return INSTANCE;
	}

	private Map<Integer, WBEMListenerImpl> iPortMap = new HashMap<Integer, WBEMListenerImpl>();

	/**
	 * Ctor.
	 */
	private WBEMListenerSBLIM() {
	// empty
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.wbem.listener.WBEMListener#addListener(javax.wbem.listener.
	 * IndicationListener, int, java.lang.String)
	 */
	public int addListener(IndicationListener pListener, int pPort, String pTransport)
			throws IOException {
		return addListener(pListener, pPort, pTransport, null, null);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.wbem.listener.WBEMListener#addListener(javax.wbem.listener.
	 * IndicationListener, int, java.lang.String, java.lang.String)
	 */
	public int addListener(IndicationListener pListener, int pPort, String pTransport,
			String pLocalAddr) throws IOException {
		return addListener(pListener, pPort, pTransport, pLocalAddr, null);
	}

	/**
	 * Add a new listener using the specified port.
	 * 
	 * @param pListener
	 *            - The Indication Listener that will be called when an
	 *            indication is received.
	 * @param pPort
	 *            - The port to listen on. Use 0 to specify any available port.
	 * @param pTransport
	 *            - The transport to use (e.g. http or https).
	 * @param pLocalAddr
	 *            - The local IP address to bind to. This is only needed in
	 *            multi-homed systems. A value of <code>null</code> will bind to
	 *            all IP addresses.
	 * @param pConfigurationProperties
	 *            - The individual configuration properties for this listener
	 * @return The port that was used.
	 * @throws IOException
	 *             - This exception is thrown when binding to pPort fails.
	 */
	public synchronized int addListener(IndicationListener pListener, int pPort, String pTransport,
			String pLocalAddr, Properties pConfigurationProperties) throws IOException {

		if (pPort > 0 && this.iPortMap.containsKey(new Integer(pPort))) { throw new BindException(
				"Port already in use."); }
		boolean ssl;
		if (pTransport.equalsIgnoreCase(WBEMConstants.HTTP)) ssl = false;
		else if (pTransport.equalsIgnoreCase(WBEMConstants.HTTPS)) ssl = true;
		else throw new IllegalArgumentException("Unknown transport: " + pTransport
				+ "! Valid values are http and https.");

		WBEMListenerImpl listener = new WBEMListenerImpl(pLocalAddr, pPort, ssl, pListener,
				pConfigurationProperties);
		listener.start();

		this.iPortMap.put(new Integer(listener.getListenerPort()), listener);

		return listener.getListenerPort();
	}

	public synchronized void removeListener(int pPort) {
		WBEMListenerImpl listener = this.iPortMap.remove(new Integer(pPort));
		if (listener != null) {
			listener.stop();
		}
	}
}
