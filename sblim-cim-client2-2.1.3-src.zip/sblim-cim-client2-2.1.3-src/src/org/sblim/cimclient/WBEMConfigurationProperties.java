/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Alexander Wolf-Reber, a.wolf-reber@de.ibm.com
 * 
 * Flag       Date        Prog         Description
 * -------------------------------------------------------------------------------
 * 1565892    2006-11-08  lupusalex    Make SBLIM client JSR48 compliant
 * 1688273    2007-04-19  lupusalex    Full support of HTTP trailers
 * 1815707    2007-10-30  ebak         TLS support
 * 1827728    2007-11-12  ebak         embeddedInstances: attribute EmbeddedObject not set
 * 1848607    2007-12-11  ebak         Strict EmbeddedObject types
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2372030    2008-12-01  blaschke-oss Add property to control synchronized SSL handshaking
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2763216    2009-04-14  blaschke-oss Code cleanup: visible spelling/grammar errors
 * 2846231    2009-09-23  rgummada     connection failure on CIMOM w/o user/pw
 */
package org.sblim.cimclient;

/**
 * The interface WBEMConfigurationProperties contains the names of all
 * configuration properties that are recognized by the CIM Client.
 * 
 */
public interface WBEMConfigurationProperties {

	/**
	 * A URL string giving the location of the CIM client config file. <br />
	 * <br />
	 * By default the SBLIM CIM Client looks for
	 * <ul>
	 * <li>file:sblim-cim-client2.properties</li>
	 * <li>file:%USER_HOME%/sblim-cim-client2.properties</li>
	 * <li>file:/etc/java/sblim-cim-client2.properties</li>
	 * </ul>
	 * The first file found will be used. The default search list is not applied
	 * if this property is set, even if the given URL does not exist.<br />
	 */
	public static final String CONFIG_URL = "sblim.wbem.configURL";

	/**
	 * Sets the minimum level for messages to be written to the log file.<br />
	 * <br />
	 * Type: <code>Discrete</code><br />
	 * Recognition: <code>Startup</code><br />
	 * Range: <code>OFF, SEVERE, WARNING, INFO, CONFIG, ALL</code><br />
	 * Default: <code>OFF</code>, which disables file logging completely.
	 */
	public static final String LOG_FILE_LEVEL = "sblim.wbem.logFileLevel";

	/**
	 * A string specifying the location of the log file. The string may include
	 * the following special components that will be replaced at runtime:<br />
	 * <ul>
	 * <table border="1">
	 * <tr>
	 * <td>/</td>
	 * <td>the local pathname separator</td>
	 * </tr>
	 * <tr>
	 * <td>%t</td>
	 * <td>the system temporary directory</td>
	 * </tr>
	 * <tr>
	 * <td>%h</td>
	 * <td>the value of the "user.home" system property</td>
	 * </tr>
	 * <tr>
	 * <td>%g</td>
	 * <td>the generation number to distinguish rotated logs</td>
	 * </tr>
	 * <tr>
	 * <td>%u</td>
	 * <td>a unique number to resolve conflicts</td>
	 * </tr>
	 * <tr>
	 * <td>%%</td>
	 * <td>translates to a single percent sign "%"</td>
	 * </tr>
	 * </table>
	 * </ul>
	 * Thus for example a pattern of <code>%t/java%g.log</code> with a count of
	 * 2 would typically cause log files to be written on Unix to
	 * /var/tmp/java2.log<br />
	 * <br />
	 * Type: <code>String</code><br />
	 * Recognition: <code>Startup</code><br />
	 * Default: <code>%t/cimclient_log_%g.txt</code>.
	 */
	public static final String LOG_FILE_LOCATION = "sblim.wbem.logFileLocation";

	/**
	 * Sets the maximum size in bytes of a single log file. When the limit is
	 * reached a new file is created. A limit of zero will create a new log file
	 * for every log record !<br />
	 * <br />
	 * Type: <code>Integer</code><br />
	 * Recognition: <code>Startup</code><br />
	 * Range: <code>0 .. Integer.MAX_VALUE</code><br />
	 * Default: <code>100.000</code><br />
	 */
	public static final String LOG_FILE_SIZE_LIMIT = "sblim.wbem.logFileSizeLimit";

	/**
	 * Sets the number of log files to cycle through. When the number is
	 * exceeded the oldest file is dropped.<br />
	 * <br />
	 * Type: <code>Integer</code><br />
	 * Recognition: <code>Startup</code><br />
	 * Range: <code>1 .. Integer.MAX_VALUE</code><br />
	 * Default: <code>5</code><br />
	 */
	public static final String LOG_FILE_COUNT = "sblim.wbem.logFileCount";

	/**
	 * Sets the minimum level for messages to be written to the console logger
	 * file.<br />
	 * <br />
	 * Type: <code>Discrete</code><br />
	 * Recognition: <code>Startup</code><br />
	 * Range: <code>OFF, SEVERE, WARNING, INFO, CONFIG, ALL</code><br />
	 * Default: <code>OFF</code>, which disables console logging completely.
	 */
	public static final String LOG_CONSOLE_LEVEL = "sblim.wbem.logConsoleLevel";

	/**
	 * Sets the type of the console logger. Maybe either message log or trace
	 * log.<br />
	 * <br />
	 * Type: <code>Discrete</code><br />
	 * Recognition: <code>Startup</code><br />
	 * Range: <code>MESSAGE, TRACE</code><br />
	 * Default: <code>MESSAGE</code>.
	 */
	public static final String LOG_CONSOLE_TYPE = "sblim.wbem.logConsoleType";

	/**
	 * Sets the minimum level for messages to be written to the trace file.<br />
	 * <br />
	 * Type: <code>Discrete</code><br />
	 * Recognition: <code>Startup</code><br />
	 * Range:
	 * <code>OFF, SEVERE, WARNING, INFO, CONFIG, FINE, FINER, FINEST, ALL</code><br />
	 * Default: <code>OFF</code>, which disables file tracing completely<br />
	 */
	public static final String TRACE_FILE_LEVEL = "sblim.wbem.traceFileLevel";

	/**
	 * A string specifying the location of the trace file. The string may
	 * include the following special components that will be replaced at
	 * runtime:<br />
	 * <ul>
	 * <table border="1">
	 * <tr>
	 * <td>/</td>
	 * <td>the local pathname separator</td>
	 * </tr>
	 * <tr>
	 * <td>%t</td>
	 * <td>the system temporary directory</td>
	 * </tr>
	 * <tr>
	 * <td>%h</td>
	 * <td>the value of the "user.home" system property</td>
	 * </tr>
	 * <tr>
	 * <td>%g</td>
	 * <td>the generation number to distinguish rotated logs</td>
	 * </tr>
	 * <tr>
	 * <td>%u</td>
	 * <td>a unique number to resolve conflicts</td>
	 * </tr>
	 * <tr>
	 * <td>%%</td>
	 * <td>translates to a single percent sign "%"</td>
	 * </tr>
	 * </table>
	 * </ul>
	 * Thus for example a pattern of <code>%t/java%g.log</code> with a count of
	 * 2 would typically cause log files to be written on Unix to
	 * /var/tmp/java2.log<br />
	 * <br />
	 * Type: <code>String</code><br />
	 * Recognition: <code>Startup</code><br />
	 * Default: <code>%t/cimclient_trace_%g.txt</code><br />
	 */
	public static final String TRACE_FILE_LOCATION = "sblim.wbem.traceFileLocation";

	/**
	 * Sets the maximum size in bytes of a single log file. When the limit is
	 * reached a new file is created. A limit of zero creates a new file for
	 * each trace record !<br />
	 * <br />
	 * Type: <code>Integer</code><br />
	 * Recognition: <code>Startup</code><br />
	 * Range: <code>0 .. Integer.MAX_VALUE</code><br />
	 * Default: <code>1.000.000</code><br />
	 */
	public static final String TRACE_FILE_SIZE_LIMIT = "sblim.wbem.traceFileSizeLimit";

	/**
	 * Sets the number of log files to cycle through. When the number is
	 * exceeded the oldest file is dropped.<br />
	 * <br />
	 * Type: <code>Integer</code><br />
	 * Recognition: <code>Startup</code><br />
	 * Range: <code>1 .. Integer.MAX_VALUE</code><br />
	 * Default: <code>5</code><br />
	 */
	public static final String TRACE_FILE_COUNT = "sblim.wbem.traceFileCount";

	/**
	 * The timeout for http requests. A timeout of zero is interpreted as
	 * infinite timeout.<br />
	 * <br />
	 * Type: <code>Integer</code><br />
	 * Unit: <code>Milliseconds</code><br />
	 * Recognition: <code>Anytime</code><br />
	 * Range: <code>0 .. Integer.MAX_VALUE</code><br />
	 * Default: <code>0</code><br />
	 */
	public static final String HTTP_TIMEOUT = "sblim.wbem.httpTimeout";

	/**
	 * The size of the internal http connection pools. Each
	 * <code>WBEMClient</code> instance has it's own http connection pool. A
	 * positive value defines the number of connections, zero that no connection
	 * will be reused, and -1 all connections will be reused (when it's
	 * possible).<br />
	 * <br />
	 * Type: <code>Integer</code><br />
	 * Recognition: <code>Anytime</code><br />
	 * Range: <code>-1, 0, 1 .. Integer.MAX_VALUE</code><br />
	 * Default: <code>16</code><br />
	 */
	public static final String HTTP_POOL_SIZE = "sblim.wbem.httpPoolSize";

	/**
	 * The Java class name of the authentication module to use for http
	 * authentication. <br />
	 * <br />
	 * Type: <code>String</code><br />
	 * Recognition: <code>On next authentication</code><br />
	 * Range:
	 * 
	 * <code>org.sblim.cimclient.internal.http.WwwAuthInfo, org.sblim.cimclient.internal.http.PegasusLocalAuthInfo or any self-written subclass of org.sblim.cimclient.internal.http.AuthorizationInfo</code>
	 * <br />
	 * Default: <code>org.sblim.cimclient.internal.http.WwwAuthInfo</code><br />
	 */
	public static final String HTTP_AUTHENTICATION_MODULE = "sblim.wbem.httpAuthModule";

	/**
	 * Specifies if MPOST is used for transmitting http messages. If false, POST
	 * is used.<br />
	 * <br />
	 * Type: <code>Boolean</code><br />
	 * Recognition: <code>Anytime</code><br />
	 * Range: <code>true, false</code><br />
	 * Default: <code>true</code><br />
	 */
	public static final String HTTP_USE_MPOST = "sblim.wbem.httpMPOST";

	/**
	 * Specifies if chunking is used for transmitting http messages.<br />
	 * <br />
	 * Type: <code>Boolean</code><br />
	 * Recognition: <code>Anytime</code><br />
	 * Range: <code>true, false</code><br />
	 * Default: <code>true</code><br />
	 */
	public static final String HTTP_USE_CHUNKING = "sblim.wbem.httpChunking";

	/**
	 * Specifies the http protocol version to use. This option is useful if the
	 * protocol negotiation fails.<br />
	 * <br />
	 * Type: <code>String</code><br />
	 * Recognition: <code>Anytime</code><br />
	 * Range: <code>1.0, 1.1</code><br />
	 * Default: <code>1.1</code><br />
	 */
	public static final String HTTP_VERSION = "sblim.wbem.httpVersion";

	/**
	 * Specifies how often the client will retry to connect to a CIMOM which
	 * refused the connection in the first place.<br />
	 * <br />
	 * Type: <code>Integer</code><br />
	 * Recognition: <code>Anytime</code><br />
	 * Range: <code>0 .. Integer.MAX_VALUE</code><br />
	 * Default: <code>0</code><br />
	 */
	public static final String HTTP_CONNECTION_RETRIES = "sblim.wbem.httpConnectionRetries";

	/**
	 * Specifies if the client will discard and request again http documents
	 * with less than a given number of bytes.<br />
	 * <br />
	 * Type: <code>Boolean</code><br />
	 * Recognition: <code>Anytime</code><br />
	 * Range: <code>true, false</code><br />
	 * Default: <code>false</code><br />
	 */
	public static final String HTTP_ENABLE_CONTENT_LENGTH_RETRY = "sblim.wbem.httpEnableContentLengthRetry";

	/**
	 * Specifies the threshold above which a http document is regarded as valid
	 * by the content length retry algorithm.<br />
	 * <br />
	 * Type: <code>Integer</code><br />
	 * Recognition: <code>Anytime</code><br />
	 * Range: <code>0 .. Integer.MAX_VALUE</code><br />
	 * Default: <code>50</code><br />
	 */
	public static final String HTTP_CONTENT_LENGTH_THRESHOLD = "sblim.wbem.httpContentLengthThreshold";

	/**
	 * The file path of the SSL keystore.<br />
	 * <br />
	 * Type: <code>String</code><br />
	 * Recognition: <code>On next SSL connection</code><br />
	 * Default: none<br />
	 */
	public static final String KEYSTORE_PATH = "javax.net.ssl.keyStore";

	/**
	 * The type of the keystore.<br />
	 * <br />
	 * Type: <code>String</code><br />
	 * Recognition: <code>On next SSL connection</code><br />
	 * Range: <code>PKCS12, JKS, ...</code><br />
	 * Default: <code>JKS</code><br />
	 */
	public static final String KEYSTORE_TYPE = "javax.net.ssl.keyStoreType";

	/**
	 * The password of the keystore.<br />
	 * <br />
	 * Type: <code>String</code><br />
	 * Recognition: <code>On next SSL connection</code><br />
	 * Default: none<br />
	 */
	public static final String KEYSTORE_PASSWORD = "javax.net.ssl.keyStorePassword";

	/**
	 * The file path of the SSL truststore.<br />
	 * <br />
	 * Type: <code>String</code><br />
	 * Recognition: <code>On next SSL connection</code><br />
	 * Default: none<br />
	 */
	public static final String TRUSTSTORE_PATH = "javax.net.ssl.trustStore";

	/**
	 * The type of the truststore.<br />
	 * <br />
	 * Type: <code>String</code><br />
	 * Recognition: <code>On next SSL connection</code><br />
	 * Range: <code>PKCS12, JKS, ...</code><br />
	 * Default: <code>JKS</code><br />
	 */
	public static final String TRUSTSTORE_TYPE = "javax.net.ssl.trustStoreType";

	/**
	 * The password of the truststore.<br />
	 * <br />
	 * Type: <code>String</code><br />
	 * Recognition: <code>On next SSL connection</code><br />
	 * Default: none<br />
	 */
	public static final String TRUSTSTORE_PASSWORD = "javax.net.ssl.trustStorePassword";

	/**
	 * The provider to use for creation of SSL client sockets.<br />
	 * <br />
	 * <em>Security property: JRE global access via <code>Security.setProperty()</code> and <code>Security.getProperty()</code> !</em>
	 * <br />
	 * <br />
	 * Type: <code>Java class name</code><br />
	 * Recognition: <code>On next SSL connection</code><br />
	 * Default: <code>Security.getProviders("SSLContext.SSL")</code><br />
	 */
	public static final String SSL_SOCKET_PROVIDER = "ssl.SocketFactory.provider";

	/**
	 * The provider to use for creation of SSL server sockets.<br />
	 * <br />
	 * <em>Security property: JRE global access via <code>Security.setProperty()</code> and <code>Security.getProperty()</code> !</em>
	 * <br />
	 * <br />
	 * Type: <code>Java class name</code><br />
	 * Recognition: <code>On next SSL connection</code><br />
	 * Default: <code>Security.getProviders("SSLContext.SSL")</code><br />
	 */
	public static final String SSL_SERVER_SOCKET_PROVIDER = "ssl.ServerSocketFactory.provider";

	/**
	 * The protocol used for SSLContext.getInstance(String protocol). For
	 * IBMJSSE2 provider it can be "SSL_TLS".<br/>
	 * <br/>
	 * Security property: JRE global access via
	 * <code>Security.setProperty()</code> and
	 * <code>Security.getProperty()</code><br/>
	 * Recognition: <code>On next SSL connection</code><br/>
	 * Default: "SSL"
	 */
	public static final String SSL_PROTOCOL = "ssl.Protocol";

	/**
	 * The key manager factory algorithm name.<br />
	 * <br />
	 * <em>Security property: JRE global access via <code>Security.setProperty()</code> and <code>Security.getProperty()</code> !</em>
	 * <br />
	 * <br />
	 * Type: <code>String</code><br />
	 * Recognition: <code>On next SSL connection</code><br />
	 * Range: <code>IbmX509, SunX509, ...</code><br />
	 * Default: <code>JRE specific</code><br />
	 */
	public static final String SSL_KEYMANAGER_ALGORITHM = "ssl.KeyManagerFactory.algorithm";

	/**
	 * The trust manager factory algorithm name.<br />
	 * <br />
	 * <em>Security property: JRE global access via <code>Security.setProperty()</code> and <code>Security.getProperty()</code> !</em>
	 * <br />
	 * <br />
	 * Type: <code>String</code><br />
	 * Recognition: <code>On next SSL connection</code><br />
	 * Range: <code>IbmX509, SunX509, ...</code><br />
	 * Default: <code>JRE specific</code><br />
	 */
	public static final String SSL_TRUSTMANAGER_ALGORITHM = "ssl.TrustManagerFactory.algorithm";

	/**
	 * Specifies the XML parser for parsing CIM-XML responses.<br />
	 * The SAX parser is the default choice since it is fast, resource saving
	 * and interoperable. The streaming algorithm of the PULL parser uses the
	 * fewest possible resources but at the prize to keep the CIMOMs response
	 * open for a long time. That works with many but not all CIMOMs. The DOM
	 * parser is slow and resource hungry but nice to debug.<br />
	 * <br />
	 * Type: <code>Discrete</code><br />
	 * Recognition: <code>Anytime</code><br />
	 * Range: <code>DOM, PULL, SAX</code><br />
	 * Default: <code>SAX</code><br />
	 */
	public static final String CIMXML_PARSER = "sblim.wbem.cimxmlParser";

	/**
	 * Enables or disables tracing of CIM-XML communication. The trace is sent
	 * to an output stream the application has to set via the LogAndTraceManager
	 * class.<br />
	 * <br />
	 * Type: <code>Boolean</code><br />
	 * Recognition: <code>Anytime</code><br />
	 * Range: <code>true, false</code><br />
	 * Default: <code>false</code><br />
	 */
	public static final String CIMXML_TRACING = "sblim.wbem.cimxmlTracing";

	/**
	 * <pre>
	 * Tells the XML builder how to sign embedded objects. This is necessary due to
	 * the non-consequent handling of embedded objects on different CIMOMs.
	 * &quot;AttribOnly&quot;       - only the EMBEDDEDOBJECT=&quot;instance/object&quot; is used
	 *                      (should be good for Pegasus)
	 * &quot;EmbObjQuali&quot;      - on qualified CIM-XML elements the EmbeddedObject qualifier is used
	 *                      for embedded classes and instances
	 * &quot;EmbObjAndEmbInstQuali&quot; -
	 *                      on qualified CIM-XML elements the EmbeddedObject qualifier is used
	 *                      for embedded classes and the EmbeddedInstance=&quot;className&quot; qualifier
	 *                      is used for embedded instances 
	 * Type: String
	 * Recognition: Anytime
	 * Range: AttribOnly, EmbObjQuali, EmbObjAndEmbInstQuali
	 * Default: AttribOnly
	 * </pre>
	 */
	public static final String CIMXML_EMBOBJBUILDER = "sblim.wbem.cimxmlEmbObjBuilder";

	/**
	 * <pre>
	 * If set the type of valueless EmbeddedObjects are mapped to CLASS_T. It should work well
	 * with OpenPegasus-2.7.0.
	 * If unset no type mapping is done for valuless EmbeddedObjects.  
	 * 
	 * Type: Boolean
	 * Default: true
	 * </pre>
	 */
	public static final String CIMXML_PARSER_STRICT_EMBOBJ_TYPES = "sblim.wbem.cimxmlParser.strictEmbObjTypes";

	/**
	 * <pre>
	 * If set to false, SSL handshakes are not synchronized.  If set to true, SSL handshakes
	 * are synchronized as a workaround for an IBMJSSE1 problem with thread-safe handshakes.
	 * 
	 * Type: Boolean
	 * Recognition: On next HTTP client
	 * Default: false
	 * </pre>
	 */
	public static final String SYNCHRONIZED_SSL_HANDSHAKE = "sblim.wbem.synchronizedSslHandshake";

	/**
	 * <pre>
	 *  If set to false user supplied credentials wil be applied. 
	 *  If set to true default credentials will be used.
	 *  This can be used if the CIMOM requires a &quot;garbage&quot; credential
	 * 
	 * Type: Boolean
	 * Recognition: On next HTTP client
	 * Default: false
	 * </pre>
	 */
	public static final String KEY_CREDENTIALS_DEFAULT_ENABLED = "sblim.wbem.default.authorization.enabled";

	/**
	 * <pre>
	 *   default Principal value is set to &quot;default&quot;
	 * 
	 * Type: String
	 * Recognition: On next HTTP client
	 * Default: &quot;default&quot;
	 * </pre>
	 */
	public static final String KEY_DEFAULT_PRINCIPAL = "sblim.wbem.default.principal";

	/**
	 * <pre>
	 *   default Credential value is set to &quot;default&quot;
	 * 
	 * Type: String
	 * Recognition: On next HTTP client
	 * Default: &quot;default&quot;
	 * </pre>
	 */
	public static final String KEY_DEFAULT_CREDENTIAL = "sblim.wbem.default.credential";

	/**
	 * The timeout for http connections of an indication listener. A timeout of
	 * zero is interpreted as infinite timeout.<br />
	 * <br />
	 * Type: <code>Integer</code><br />
	 * Unit: <code>Milliseconds</code><br />
	 * Recognition: <code>On next creation of a WBEMListener</code><br />
	 * Range: <code>0 .. Integer.MAX_VALUE</code><br />
	 * Default: <code>10000</code><br />
	 */
	public static final String LISTENER_HTTP_TIMEOUT = "sblim.wbem.listenerHttpTimeout";

	/**
	 * The size of the thread pool for the connection handlers of the indicati
	 * for http connections of an indication listener. This is the maximum
	 * number of handler threads the pool might create on heavy load.<br />
	 * A value of -1 is interpreted as infinity. <br />
	 * Type: <code>Integer</code><br />
	 * Unit: <code>Count</code><br />
	 * Recognition: <code>On next creation of a WBEMListener</code><br />
	 * Range: <code>-1 .. Integer.MAX_VALUE</code><br />
	 * Default: <code>8</code><br />
	 */
	public static final String LISTENER_MAX_POOL_SIZE = "sblim.wbem.listenerPoolMaxSize";

	/**
	 * The minimal number of connection handlers of the indication listener that
	 * will be kept open by the thread pool regardsless of the current load. <br />
	 * Type: <code>Integer</code><br />
	 * Unit: <code>Count</code><br />
	 * Recognition: <code>On next creation of a WBEMListener</code><br />
	 * Range: <code>0 .. Integer.MAX_VALUE</code><br />
	 * Default: <code>2</code><br />
	 */
	public static final String LISTENER_MIN_POOL_SIZE = "sblim.wbem.listenerPoolMinSize";

	/**
	 * The number of queued connections that is tolerated before the thread pool
	 * creates an additional handler thread. Increasing this value leads to a
	 * less &quot;nervous&quot; creation/destruction of handlers. However it
	 * makes the listener more vulnerable to frozen connections.<br />
	 * <br />
	 * Type: <code>Integer</code><br />
	 * Unit: <code>Count</code><br />
	 * Recognition: <code>On next creation of a WBEMListener</code><br />
	 * Range: <code>0 .. Integer.MAX_VALUE</code><br />
	 * Default: <code>2</code><br />
	 */
	public static final String LISTENER_BACKLOG = "sblim.wbem.listenerBacklog";

	/**
	 * The idle time of a worker that is tolerated before the worker is
	 * destroyed by the thread pool. By setting the minimal pool size >0 you can
	 * protect a given number of worker from destruction.<br />
	 * <br />
	 * Type: <code>Long</code><br />
	 * Unit: <code>Milliseconds</code><br />
	 * Recognition: <code>On next creation of a WBEMListener</code><br />
	 * Range: <code>0 .. Long.MAX_VALUE</code><br />
	 * Default: <code>30000</code><br />
	 */
	public static final String LISTENER_HANDLER_MAX_IDLE = "sblim.wbem.listenerHandlerMaxIdle";

}
