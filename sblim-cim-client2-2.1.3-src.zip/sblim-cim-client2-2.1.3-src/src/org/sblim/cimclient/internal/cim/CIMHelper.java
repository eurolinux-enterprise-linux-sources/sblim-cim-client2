/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Alexander Wolf-Reber, IBM, a.wolf-reber@de.ibm.com
 * 
 * Change History
 * Flag       Date        Prog         Description
 *------------------------------------------------------------------------------- 
 * 1565892    2006-12-06  lupusalex    Make SBLIM client JSR48 compliant
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 */

package org.sblim.cimclient.internal.cim;

import java.net.URI;
import java.net.URISyntaxException;

import javax.cim.CIMObjectPath;

import org.sblim.cimclient.internal.util.WBEMConstants;

/**
 * Class CIMHelper provides convenience methods that are missing from the
 * official JSR48 API
 * 
 */
public abstract class CIMHelper {

	private CIMHelper() {
	// no instances
	}

	/**
	 * Creates a URI of a CIMOM from a given CIM object path
	 * 
	 * @param pPath
	 *            The CIM object path
	 * @return The URI
	 * @throws URISyntaxException
	 */
	public static URI createCimomUri(CIMObjectPath pPath) throws URISyntaxException {
		String scheme = (pPath.getScheme() != null) ? pPath.getScheme() : WBEMConstants.HTTP;
		String host = pPath.getHost();
		int port = WBEMConstants.DEFAULT_WBEM_PORT;
		try {
			port = Integer.parseInt(pPath.getPort());
		} catch (NumberFormatException e) {
			// stuck with default port
		}
		return new URI(scheme, null, host, port, WBEMConstants.CIMOM_PATH, null, null);
	}
}
