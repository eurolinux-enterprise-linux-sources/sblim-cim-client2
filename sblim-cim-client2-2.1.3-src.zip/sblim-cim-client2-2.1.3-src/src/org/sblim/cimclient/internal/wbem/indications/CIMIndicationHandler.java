/**
 * (C) Copyright IBM Corp. 2005, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Roberto Pineiro, IBM, roberto.pineiro@us.ibm.com  
 * @author : Chung-hao Tan, IBM, chungtan@us.ibm.com
 * 
 * 
 * Change History
 * Flag       Date        Prog         Description
 *------------------------------------------------------------------------------- 
 * 17931      07/28/2005  thschaef     Add InetAddress to CIM Event
 * 1438152    2006-05-15  lupusalex    Wrong message ID in ExportResponseMessage
 * 1498938    2006-06-01  lupusalex    Multiple events in single cim-xml request are not handled
 * 1498130    2006-05-31  lupusalex    Selection of xml parser on a per connection basis
 * 1535756    2006-08-07  lupusalex    Make code warning free
 * 1565892    2006-11-16  lupusalex    Make SBLIM client JSR48 compliant
 * 1656285    2007-02-12  ebak         IndicationHandler does not accept non-Integer message ID
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2531371    2009-02-10  raman_arora  Upgrade client to JDK 1.5 (Phase 2)
 * 2714989    2009-03-26  blaschke-oss Code cleanup from redundant null check et al
 * 2901216    2009-12-01  blaschke-oss lost IndicationURL for IndcationListener.indicationOccured
 */

package org.sblim.cimclient.internal.wbem.indications;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.util.Iterator;
import java.util.Vector;
import java.util.Map.Entry;
import java.util.logging.Level;

import javax.cim.CIMInstance;
import javax.wbem.WBEMException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;

import org.sblim.cimclient.internal.cimxml.CIMClientXML_HelperImpl;
import org.sblim.cimclient.internal.cimxml.CIMRequest;
import org.sblim.cimclient.internal.cimxml.CIMXMLBuilderImpl;
import org.sblim.cimclient.internal.cimxml.CIMXMLParserImpl;
import org.sblim.cimclient.internal.http.HttpContentHandler;
import org.sblim.cimclient.internal.http.HttpException;
import org.sblim.cimclient.internal.http.HttpHeader;
import org.sblim.cimclient.internal.http.HttpHeaderParser;
import org.sblim.cimclient.internal.http.MessageReader;
import org.sblim.cimclient.internal.http.MessageWriter;
import org.sblim.cimclient.internal.http.HttpHeader.HeaderEntry;
import org.sblim.cimclient.internal.http.io.DebugInputStream;
import org.sblim.cimclient.internal.logging.LogAndTraceBroker;
import org.sblim.cimclient.internal.util.WBEMConfiguration;
import org.sblim.cimclient.internal.wbem.CIMError;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;

/**
 * Handles the HTTP connections, providing the necessary interfaces for
 * CIMListener server.
 */
public class CIMIndicationHandler extends HttpContentHandler {

	private CIMEventDispatcher iDispatcher = null;

	private int iMessageId = 0;

	private LogAndTraceBroker iLogger = LogAndTraceBroker.getBroker();

	private WBEMConfiguration iSessionProperties;

	/**
	 * Ctor.
	 * 
	 * @param pDispatcher
	 */
	public CIMIndicationHandler(CIMEventDispatcher pDispatcher) {
		this.iDispatcher = pDispatcher;
		this.iSessionProperties = WBEMConfiguration.getGlobalConfiguration();
	}

	/**
	 * Ctor.
	 * 
	 * @param pDispatcher
	 * @param pProperties
	 */
	public CIMIndicationHandler(CIMEventDispatcher pDispatcher, WBEMConfiguration pProperties) {
		this.iDispatcher = pDispatcher;
		this.iSessionProperties = (pProperties != null) ? pProperties : WBEMConfiguration
				.getGlobalConfiguration();
	}

	@Override
	public void close() {
		if (this.iDispatcher != null) this.iDispatcher.close();
	}

	/**
	 * getMsgID
	 * 
	 * @return int
	 */
	public synchronized int getMsgID() {
		this.iMessageId++;
		if (this.iMessageId > 1000000) this.iMessageId = 0;
		return this.iMessageId;
	}

	private static HttpHeader processHeader(HttpHeader pHeader, MessageWriter pWriter)
			throws HttpException {

		HttpHeader header = processHttpExtensions(pHeader);
		String cimExport = header.getField("CIMExport");
		String cimOperation = header.getField("CIMOperation");

		if (cimOperation != null && !"METHODCALL".equalsIgnoreCase(cimOperation)) {
			pWriter.getHeader().addField("CIMError", "unsupported-operation");
			throw new HttpException(400, "Bad Request");
		}
		if (cimExport != null && !"METHODREQUEST".equalsIgnoreCase(cimExport)
				&& !"EXPORTMETHODCALL".equalsIgnoreCase(cimExport)) {
			pWriter.getHeader().addField("CIMError", "unsupported-operation");
			throw new HttpException(400, "Bad Request");
		}
		if (cimOperation == null && cimExport == null) {
			// TODO: verify the status returned by the server for this
			// situation, is not defined on the spec
			pWriter.getHeader().addField("CIMError", "unsupported-operation");
			throw new HttpException(400, "Bad Request");
		}

		return header;
	}

	@Override
	public void handleContent(MessageReader pReader, MessageWriter pWriter, InetAddress pInetAddress)
			throws HttpException, IOException {

		CIMError error = null;

		// TODO validate CIMHeaders!
		HttpHeader inputHeader = pReader.getHeader();
		inputHeader = processHeader(inputHeader, pWriter);
		String cimMethod = inputHeader.getField("CIMMethod");
		String cimExport = inputHeader.getField("CIMExport");

		CIMRequest request = null;
		CIMClientXML_HelperImpl xmlHelper = null;

		try {
			xmlHelper = new CIMClientXML_HelperImpl();
		} catch (ParserConfigurationException e1) {
			IOException e = new IOException("ParserConfigurationException");
			e.initCause(e1);
			throw e;
		}

		InputStream inputstream = null;
		if (this.iSessionProperties.isCimXmlTracingEnabled()
				&& LogAndTraceBroker.getBroker().getXmlTraceStream() != null) {
			inputstream = new DebugInputStream(pReader.getInputStream(), LogAndTraceBroker
					.getBroker().getXmlTraceStream());
		} else {
			inputstream = pReader.getInputStream();
		}

		request = parseDocument(xmlHelper, pReader, inputstream);

		if (request == null) throw new HttpException(400, "Bad Request");

		if ((cimExport == null && !cimMethod.equalsIgnoreCase("Indication"))
				|| !request.isCIMExport()) { throw new HttpException(400, "Bad Request"); }

		error = dispatchIndications(pReader, pInetAddress, request);

		buildResponse(xmlHelper, pWriter, request, error);
	}

	private CIMRequest parseDocument(CIMClientXML_HelperImpl xmlHelper, MessageReader pReader,
			InputStream inputstream) throws HttpException {

		// TODO: integrate SAX parser and DOM parser

		Document doc = null;
		try {

			doc = xmlHelper.parse(new InputSource(new InputStreamReader(inputstream, pReader
					.getCharacterEncoding())));
			Element rootE = doc.getDocumentElement();
			return (CIMRequest) CIMXMLParserImpl.parseCIM(rootE);
		} catch (Exception e) {
			this.iLogger.trace(Level.WARNING, "exception while parsing the XML with DOM parser", e);
			throw new HttpException(400, "Bad Request");
		}
	}

	private CIMError dispatchIndications(MessageReader pReader, InetAddress pInetAddress,
			CIMRequest request) {
		try {
			Vector<Object> paramValue = request.getParamValue();
			Iterator<Object> iter = paramValue.iterator();
			while (iter.hasNext()) {
				Object cimEvent = iter.next();
				if (cimEvent instanceof CIMInstance) {
					CIMInstance indicationInst = (CIMInstance) cimEvent;
					String id = pReader.getMethod().getFile();
					if (id != null && id.startsWith("/") && id.length() > 1
							&& !id.equalsIgnoreCase("/cimom")) {
						id = id.substring(1);
					}
					this.iDispatcher.dispatchEvent(new CIMEvent(indicationInst, id, pInetAddress));
				}
			}
			return null;
		} catch (Exception e) {
			return new CIMError(new WBEMException(WBEMException.CIM_ERR_FAILED, "CIM_ERR_FAILED",
					null, e));
		}
	}

	private static void buildResponse(CIMClientXML_HelperImpl xmlHelper, MessageWriter pWriter,
			CIMRequest request, CIMError error) throws HttpException, IOException {
		Document responseDoc = null;
		try {
			DocumentBuilder docBuilder = xmlHelper.getDocumentBuilder();
			responseDoc = docBuilder.newDocument();
			CIMXMLBuilderImpl.createIndication_response(responseDoc, request.getId(), error);

		} catch (Exception e) {
			// TODO: check this error code, may not be appropriate
			throw new HttpException(400, "Bad Request");
		}
		CIMClientXML_HelperImpl.serialize(pWriter.getOutputStream(), responseDoc);
		pWriter.getHeader().addField("CIMExport", "MethodResponse");
	}

	private static HttpHeader processHttpExtensions(HttpHeader pOriginalHeader) {
		String man = pOriginalHeader.getField("Man");
		String opt = pOriginalHeader.getField("Opt");
		HttpHeader headers = new HttpHeader();
		String ns = null;

		HttpHeaderParser manOptHeader = null;
		if (man != null && man.length() > 0) manOptHeader = new HttpHeaderParser(man);
		else if (opt != null && opt.length() > 0) manOptHeader = new HttpHeaderParser(opt);
		if (manOptHeader != null) ns = manOptHeader.getValue("ns");

		if (ns != null) {

			Iterator<Entry<HeaderEntry, String>> iter = pOriginalHeader.iterator();
			String key;
			while (iter.hasNext()) {
				Entry<HeaderEntry, String> entry = iter.next();
				if (entry != null) {
					key = entry.getKey().toString();
					if (key.startsWith(ns + "-")) headers.addField(key.substring(3), entry
							.getValue().toString());
					else headers.addField(key, entry.getValue().toString());
				}
			}
		} else {
			headers = pOriginalHeader;
		}

		return headers;
	}

}
