/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Alexander Wolf-Reber, a.wolf-reber@de.ibm.com
 * 
 * Flag       Date        Prog         Description
 * -------------------------------------------------------------------------------
 * 1565892    2006-11-08  lupusalex    Make SBLIM client JSR48 compliant
 * 1688273    2007-04-16  ebak         Full support of HTTP trailers
 * 1702832    2007-04-18  lupusalex    WBEMClientCIMXL.setCustomSocketFactory() not implemented
 * 1686000    2007-04-19  ebak         modifyInstance() missing from WBEMClient
 * 1714184    2007-05-07  lupusalex    FVT: NPE on WBEMClientCIMXML.init()
 * 1715053    2007-05-08  lupusalex    FVT: No forced retry on HTTP 501/510
 * 1714853    2007-05-08  lupusalex    Inexplicit error when operation is invoked on closed client
 * 1714902    2007-05-08  lupusalex    Threading related weak spots
 * 1715482    2007-05-10  lupusalex    CIM_ERR_FAILED thrown when access denied
 * 1736318    2007-06-13  lupusalex    Wrong object path in HTTP header
 * 1737141    2007-06-18  ebak         Sync up with JSR48 evolution
 * 1741654    2007-08-22  ebak         Header mismatch error on ModifyInstance
 * 1949000    2008-04-24  blaschke-oss setLocales() is empty
 * 1963762    2008-05-14  blaschke-oss connection leak in WBEMClientCIMXML
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2002599    2008-07-05  raman_arora  M-POST not supported in java-client
 * 2034342    2008-07-31  blaschke-oss HttpClient not closed on cimclient close
 * 2087975    2008-09-03  blaschke-oss can't set the pPropagated in WBEMClient.enumerateClasses()
 * 2382763    2008-12-03  blaschke-oss HTTP header field Accept-Language does not include *
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2531371    2009-02-10  raman_arora  Upgrade client to JDK 1.5 (Phase 2)
 * 2763216    2009-04-14  blaschke-oss Code cleanup: visible spelling/grammar errors
 * 2797550    2009-06-01  raman_arora  JSR48 compliance - add Java Generics 
 * 2845211    2009-08-27  raman_arora  Pull Enumeration Feature (SAX Parser)
 * 2860081    2009-09-17  raman_arora  Pull Enumeration Feature (DOM Parser)
 * 2846231    2009-09-23  rgummada     connection failure on CIMOM w/o user/pw
 * 2865222	  2009-09-29  raman_arora  enumerateQualifierTypes shouldn't require a class name
 * 2858933    2009-10-12  raman_arora  JSR48 new APIs: associatorClasses & associatorInstances
 * 2884718    2008-10-23  blaschke-oss Merge JSR48 and SBLIM client properties
 * 2878054    2009-10-25  raman_arora  Pull Enumeration Feature (PULL Parser)
 * 2888774    2009-10-29  raman_arora  support POST retry on HTTP error 505
 * 2886829    2009-11-18  raman_arora  JSR48 new APIs: referenceClasses & referenceInstances
 */
package org.sblim.cimclient.internal.wbem;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.PasswordAuthentication;
import java.net.ProtocolException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLConnection;
import java.net.UnknownHostException;
import java.security.Principal;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Map.Entry;
import java.util.logging.Level;

import javax.cim.CIMArgument;
import javax.cim.CIMClass;
import javax.cim.CIMInstance;
import javax.cim.CIMObjectPath;
import javax.cim.CIMQualifierType;
import javax.cim.UnsignedInteger32;
import javax.cim.UnsignedInteger64;
import javax.net.SocketFactory;
import javax.security.auth.Subject;
import javax.wbem.CloseableIterator;
import javax.wbem.WBEMException;
import javax.wbem.client.EnumerateResponse;
import javax.wbem.client.PasswordCredential;
import javax.wbem.client.RoleCredential;
import javax.wbem.client.WBEMClient;
import javax.wbem.client.WBEMClientConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.sblim.cimclient.WBEMClientSBLIM;
import org.sblim.cimclient.WBEMConfigurationProperties;
import org.sblim.cimclient.internal.cim.CIMHelper;
import org.sblim.cimclient.internal.cimxml.CIMClientXML_HelperImpl;
import org.sblim.cimclient.internal.cimxml.CIMMessage;
import org.sblim.cimclient.internal.cimxml.CIMResponse;
import org.sblim.cimclient.internal.cimxml.CIMXMLParseException;
import org.sblim.cimclient.internal.cimxml.CIMXMLParserImpl;
import org.sblim.cimclient.internal.cimxml.sax.SAXHelper;
import org.sblim.cimclient.internal.http.AuthorizationHandler;
import org.sblim.cimclient.internal.http.AuthorizationInfo;
import org.sblim.cimclient.internal.http.HttpClientPool;
import org.sblim.cimclient.internal.http.HttpHeader;
import org.sblim.cimclient.internal.http.HttpHeaderParser;
import org.sblim.cimclient.internal.http.HttpUrlConnection;
import org.sblim.cimclient.internal.http.HttpHeader.HeaderEntry;
import org.sblim.cimclient.internal.http.io.DebugInputStream;
import org.sblim.cimclient.internal.http.io.TrailerException;
import org.sblim.cimclient.internal.logging.LogAndTraceBroker;
import org.sblim.cimclient.internal.logging.Messages;
import org.sblim.cimclient.internal.util.MOF;
import org.sblim.cimclient.internal.util.WBEMConfiguration;
import org.sblim.cimclient.internal.util.WBEMConfigurationDefaults;
import org.sblim.cimclient.internal.util.WBEMConstants;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * The WBEMClientCIMXML is a implementation of the
 * <code>javax.wbem.client.WBEMClient</code> interface for the CIM-XML protocol
 * including the extensions of the
 * <code>org.sblim.cimclient.WBEMClientSBLIM</code> interface.
 * 
 * @see WBEMClient
 * @see WBEMClientSBLIM
 */
public class WBEMClientCIMXML implements WBEMClientSBLIM {

	private final WBEMConfiguration iConfiguration = new WBEMConfiguration(new Properties());

	private Locale[] iLocales; // final

	private HttpClientPool iHttpClientPool; // final

	private URI iUri; // final

	private AuthorizationHandler iAuthorizationHandler; // final

	private CIMClientXML_HelperImpl iXmlHelper; // final

	private volatile String iAuthorization;

	private volatile int iNsCounter = 10;

	private volatile boolean iMPostFailed = false;

	private volatile long iMPostFailTime = 0;

	private volatile long iCurrentTime = 0;

	private volatile boolean iInitialized = false;

	private volatile boolean iClosed = false;

	/**
	 * Ctor.
	 */
	public WBEMClientCIMXML() {
		super();
	}

	public synchronized void initialize(CIMObjectPath pName, Subject pSubject, Locale[] pLocales)
			throws IllegalArgumentException, WBEMException {

		if (this.iInitialized) throw new IllegalStateException("WBEMClient is already initialized");

		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		try {
			if (pName == null || pName.getHost() == null || pName.getHost().length() == 0) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Empty host path"); }

			this.iHttpClientPool = new HttpClientPool(this.iConfiguration);
			this.iLocales = (pLocales != null && pLocales.length > 0) ? pLocales
					: WBEMConstants.DEFAULT_LOCALES;

			try {
				this.iUri = CIMHelper.createCimomUri(pName);
			} catch (URISyntaxException e) {
				throw new WBEMException(WBEMException.CIM_ERR_INVALID_PARAMETER, "Malformed URI");
			}

			AuthorizationInfo authInfo = AuthorizationInfo.createAuthorizationInfo(
					this.iConfiguration.getHttpAuthenticationModule(), Boolean.FALSE, this.iUri
							.getHost(), this.iUri.getPort(), null, null, null);

			Principal principal = (pSubject != null && pSubject.getPrincipals() != null && !pSubject
					.getPrincipals().isEmpty()) ? (Principal) pSubject.getPrincipals().iterator()
					.next() : null;
			Object credential = (pSubject != null && pSubject.getPrivateCredentials() != null
					&& !pSubject.getPrivateCredentials().isEmpty() ? pSubject
					.getPrivateCredentials().iterator().next() : null);

			boolean defaultAuthEnabled = WBEMConfiguration.getGlobalConfiguration()
					.isDefaultAuthorizationEnabled();

			String user = "";
			String password = "";
			if (credential == null
					|| principal == null
					|| principal.getName() == null
					|| (credential instanceof PasswordCredential && (((PasswordCredential) credential)
							.getUserPassword() == null || ((PasswordCredential) credential)
							.getUserPassword().length == 0))
					|| (credential instanceof RoleCredential && (((RoleCredential) credential)
							.getCredential() == null || ((RoleCredential) credential)
							.getCredential().length == 0))) {
				if (defaultAuthEnabled) {
					logger.trace(Level.FINER,
							"Empty credential or principal - Default IS enabled !");
					user = WBEMConfiguration.getGlobalConfiguration().getDefaultPrincipal();
					password = WBEMConfiguration.getGlobalConfiguration().getDefaultCredentials();
				} else {
					logger.trace(Level.FINER,
							"Empty credential or principal - Default NOT enabled !");
				}
			} else {
				user = principal.getName();
				password = (credential instanceof PasswordCredential) ? new String(
						((PasswordCredential) credential).getUserPassword()) : new String(
						((RoleCredential) credential).getCredential());
			}
			authInfo.setCredentials(new PasswordAuthentication(user, password.toCharArray()));
			this.iAuthorizationHandler = new AuthorizationHandler();
			this.iAuthorizationHandler.addAuthorizationInfo(authInfo);

			try {
				this.iXmlHelper = new CIMClientXML_HelperImpl();
			} catch (ParserConfigurationException e) {
				logger
						.trace(Level.FINE, "Exception while instantiating CIMClientXML_HelperImpl",
								e);
				logger.message(Messages.CIM_XMLHELPER_FAILED);
				throw new RuntimeException(e);
			}

			this.iInitialized = true;

		} finally {
			logger.exit();
		}
	}

	public Properties getProperties() {
		return this.iConfiguration.getDomainProperties();
	}

	public String getProperty(String pKey) {
		if (pKey.startsWith("javax.wbem.client.")) {
			// Process JSR48 properties
			String SblimKey;

			if (pKey.equals(WBEMClientConstants.PROP_ENABLE_CONSOLE_LOGGING)) {
				SblimKey = this.iConfiguration
						.getDomainProperty(WBEMConfigurationProperties.LOG_CONSOLE_LEVEL);
				if (SblimKey == null) return null;
				return SblimKey.equals("OFF") ? "0" : "1";
			} else if (pKey.equals(WBEMClientConstants.PROP_ENABLE_FILE_LOGGING)) {
				SblimKey = this.iConfiguration
						.getDomainProperty(WBEMConfigurationProperties.LOG_FILE_LEVEL);
				if (SblimKey == null) return null;
				return SblimKey.equals("OFF") ? "0" : "1";
			} else if (pKey.equals(WBEMClientConstants.PROP_LOG_BYTE_LIMIT)) {
				return this.iConfiguration
						.getDomainProperty(WBEMConfigurationProperties.LOG_FILE_SIZE_LIMIT);
			} else if (pKey.equals(WBEMClientConstants.PROP_LOG_DIR)) {
				SblimKey = this.iConfiguration
						.getDomainProperty(WBEMConfigurationProperties.LOG_FILE_LOCATION);
				if (SblimKey == null) return null;
				int i = SblimKey.lastIndexOf(File.separatorChar);
				return i != -1 ? SblimKey.substring(0, i) : null;
			} else if (pKey.equals(WBEMClientConstants.PROP_LOG_FILENAME)) {
				SblimKey = this.iConfiguration
						.getDomainProperty(WBEMConfigurationProperties.LOG_FILE_LOCATION);
				if (SblimKey == null) return null;
				int i = SblimKey.lastIndexOf(File.separatorChar);
				return i != -1 ? SblimKey.substring(i + 1) : SblimKey;
			} else if (pKey.equals(WBEMClientConstants.PROP_LOG_NUM_FILES)) {
				return this.iConfiguration
						.getDomainProperty(WBEMConfigurationProperties.LOG_FILE_COUNT);
			} else if (pKey.equals(WBEMClientConstants.PROP_TIMEOUT)) {
				return this.iConfiguration
						.getDomainProperty(WBEMConfigurationProperties.HTTP_TIMEOUT);
			} else {
				return null;
			}
		}
		return this.iConfiguration.getDomainProperty(pKey);

	}

	public void setProperties(Properties pProperties) {
		this.iConfiguration.setDomainProperties(pProperties);
	}

	public void setProperty(String pKey, String pValue) {
		if (pKey.startsWith("javax.wbem.client.")) {
			// Process JSR48 properties
			if (pKey.equals(WBEMClientConstants.PROP_ENABLE_CONSOLE_LOGGING)) {
				this.iConfiguration.setDomainProperty(
						WBEMConfigurationProperties.LOG_CONSOLE_LEVEL, pValue.equals("0") ? "OFF"
								: "ALL");
			} else if (pKey.equals(WBEMClientConstants.PROP_ENABLE_FILE_LOGGING)) {
				this.iConfiguration.setDomainProperty(WBEMConfigurationProperties.LOG_FILE_LEVEL,
						pValue.equals("0") ? "OFF" : "ALL");
			} else if (pKey.equals(WBEMClientConstants.PROP_LOG_BYTE_LIMIT)) {
				this.iConfiguration.setDomainProperty(
						WBEMConfigurationProperties.LOG_FILE_SIZE_LIMIT, pValue);
			} else if (pKey.equals(WBEMClientConstants.PROP_LOG_DIR)) {
				StringBuffer NewSblimLog = new StringBuffer(pValue != null ? pValue : "");
				if (NewSblimLog.length() > 0
						&& NewSblimLog.charAt(NewSblimLog.length() - 1) != File.separatorChar) {
					NewSblimLog.append(File.separator);
				}

				String CurSblimLog = this.iConfiguration
						.getDomainProperty(WBEMConfigurationProperties.LOG_FILE_LOCATION);
				if (CurSblimLog == null) {
					CurSblimLog = WBEMConfigurationDefaults.LOG_FILE_LOCATION;
				}

				int i = CurSblimLog.lastIndexOf(File.separatorChar);
				if (i == -1) {
					NewSblimLog.append(CurSblimLog);
				} else {
					NewSblimLog.append(CurSblimLog.substring(i + 1));
				}

				this.iConfiguration.setDomainProperty(
						WBEMConfigurationProperties.LOG_FILE_LOCATION, NewSblimLog.toString());
			} else if (pKey.equals(WBEMClientConstants.PROP_LOG_FILENAME)) {
				StringBuffer NewSblimLog = new StringBuffer(pValue != null ? pValue : "");

				String CurSblimLog = this.iConfiguration
						.getDomainProperty(WBEMConfigurationProperties.LOG_FILE_LOCATION);
				if (CurSblimLog != null) {
					int i = CurSblimLog.lastIndexOf(File.separatorChar);
					if (i != -1) {
						NewSblimLog.insert(0, CurSblimLog.substring(0, i + 1));
					}
				}

				this.iConfiguration.setDomainProperty(
						WBEMConfigurationProperties.LOG_FILE_LOCATION, NewSblimLog.toString());
			} else if (pKey.equals(WBEMClientConstants.PROP_LOG_NUM_FILES)) {
				this.iConfiguration.setDomainProperty(WBEMConfigurationProperties.LOG_FILE_COUNT,
						pValue);
			} else if (pKey.equals(WBEMClientConstants.PROP_TIMEOUT)) {
				this.iConfiguration.setDomainProperty(WBEMConfigurationProperties.HTTP_TIMEOUT,
						pValue);
			} else {
				throw new IllegalArgumentException(pKey);
			}
		} else {
			this.iConfiguration.setDomainProperty(pKey, pValue);
		}
	}

	public CloseableIterator<CIMObjectPath> associatorNames(CIMObjectPath pObjectName,
			String pAssociationClass, String pResultClass, String pRole, String pResultRole)
			throws WBEMException {

		final String operation = "AssociatorNames";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {

			if (pObjectName == null || pObjectName.getNamespace() == null
					|| pObjectName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pObjectName.getNamespace(), "UTF-8",
					"US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();

			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.associatorNames_request(doc,
					pObjectName, pAssociationClass, pResultClass, pRole, pResultRole));

			InputStreamReader is = transmitRequest("AssociatorNames", hh, doc);

			CloseableIterator<CIMObjectPath> iter = getIterator(is, pObjectName);
			return iter;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public CloseableIterator<CIMClass> associatorClasses(CIMObjectPath pObjectName,
			String pAssociationClass, String pResultClass, String pRole, String pResultRole,
			boolean pIncludeQualifiers, boolean pIncludeClassOrigin, String[] pPropertyList)
			throws WBEMException {
		final String operation = "AssociatorClasses";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {

			if (pObjectName == null || pObjectName.getNamespace() == null
					|| pObjectName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pObjectName.getNamespace(), "UTF-8",
					"US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.associatorClasses_request(doc,
					pObjectName, pAssociationClass, pResultClass, pRole, pResultRole,
					pIncludeQualifiers, pIncludeClassOrigin, pPropertyList));

			InputStreamReader is = transmitRequest("Associators", hh, doc);

			CloseableIterator<CIMClass> iter = getIterator(is, pObjectName);

			return iter;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public CloseableIterator<CIMInstance> associatorInstances(CIMObjectPath pObjectName,
			String pAssociationClass, String pResultClass, String pRole, String pResultRole,
			boolean pIncludeClassOrigin, String[] pPropertyList) throws WBEMException {
		final String operation = "AssociatorInstances";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {

			if (pObjectName == null || pObjectName.getNamespace() == null
					|| pObjectName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pObjectName.getNamespace(), "UTF-8",
					"US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.associatorInstances_request(doc,
					pObjectName, pAssociationClass, pResultClass, pRole, pResultRole,
					pIncludeClassOrigin, pPropertyList));

			InputStreamReader is = transmitRequest("Associators", hh, doc);

			CloseableIterator<CIMInstance> iter = getIterator(is, pObjectName);
			return iter;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public CloseableIterator associators(CIMObjectPath pObjectName, String pAssociationClass,
			String pResultClass, String pRole, String pResultRole, boolean pIncludeQualifiers,
			boolean pIncludeClassOrigin, String[] pPropertyList) throws WBEMException {

		final String operation = "Associators";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {

			if (pObjectName == null || pObjectName.getNamespace() == null
					|| pObjectName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pObjectName.getNamespace(), "UTF-8",
					"US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.associators_request(doc,
					pObjectName, pAssociationClass, pResultClass, pRole, pResultRole,
					pIncludeQualifiers, pIncludeClassOrigin, pPropertyList));

			InputStreamReader is = transmitRequest("Associators", hh, doc);

			return getIterator(is, pObjectName);

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public synchronized void close() {
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();
		try {
			checkState();
			if (this.iHttpClientPool != null) {
				this.iHttpClientPool.closePool();
			}
		} finally {
			this.iClosed = true;
			logger.exit();
		}
	}

	public void createClass(CIMClass pClass) throws WBEMException {

		final String operation = "CreateClass";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {

			if (pClass == null || pClass.getObjectPath() == null
					|| pClass.getObjectPath().getNamespace() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pClass.getObjectPath().getNamespace(),
					"UTF-8", "US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.createClass_request(doc, pClass
					.getObjectPath(), pClass));

			InputStreamReader is = transmitRequest("CreateClass", hh, doc);

			CloseableIterator<?> iter = getIterator(is, pClass.getObjectPath());
			try {
				iter.hasNext();
			} finally {
				iter.close();
			}

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public CIMObjectPath createInstance(CIMInstance pInstance) throws WBEMException {

		final String operation = "CreateInstance";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pInstance == null || pInstance.getObjectPath() == null
					|| pInstance.getObjectPath().getNamespace() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pInstance.getObjectPath().getNamespace(),
					"UTF-8", "US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.createInstance_request(doc,
					pInstance.getObjectPath(), pInstance));

			InputStreamReader is = transmitRequest("CreateInstance", hh, doc);

			CloseableIterator<?> iter = getIterator(is, pInstance.getObjectPath());
			try {
				if (iter.hasNext()) { return (CIMObjectPath) iter.next(); }
			} finally {
				iter.close();
			}

			return null;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public void deleteClass(CIMObjectPath pPath) throws WBEMException {

		final String operation = "DeleteClass";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pPath == null || pPath.getNamespace() == null || pPath.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pPath.getNamespace(), "UTF-8", "US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.deleteClass_request(doc, pPath));

			InputStreamReader is = transmitRequest("DeleteClass", hh, doc);

			CloseableIterator<?> iter = getIterator(is, pPath);
			try {
				iter.hasNext();
			} finally {
				iter.close();
			}

			return;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public void deleteInstance(CIMObjectPath pPath) throws WBEMException {

		final String operation = "DeleteInstance";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pPath == null || pPath.getNamespace() == null || pPath.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pPath.getNamespace(), "UTF-8", "US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();

			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper
					.deleteInstance_request(doc, pPath));

			InputStreamReader is = transmitRequest("DeleteInstance", hh, doc);

			CloseableIterator<?> iter = getIterator(is, pPath);
			try {
				iter.hasNext();
			} finally {
				iter.close();
			}

			return;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public void deleteQualifierType(CIMObjectPath pPath) throws WBEMException {

		final String operation = "DeleteQualifierType";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pPath == null || pPath.getNamespace() == null || pPath.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pPath.getNamespace(), "UTF-8", "US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.deleteQualifierType_request(doc,
					pPath));

			InputStreamReader is = transmitRequest("DeleteQualifierType", hh, doc);

			CloseableIterator<?> iter = getIterator(is, pPath);
			try {
				iter.hasNext();
			} finally {
				iter.close();
			}

			return;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public CloseableIterator<CIMObjectPath> enumerateClassNames(CIMObjectPath pPath, boolean pDeep)
			throws WBEMException {

		final String operation = "EnumerateClassNames";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pPath == null || pPath.getNamespace() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pPath.getNamespace(), "UTF-8", "US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.enumerateClassNames_request(doc,
					pPath, pDeep));

			InputStreamReader is = transmitRequest("EnumerateClassNames", hh, doc);

			CloseableIterator<CIMObjectPath> iter = getIterator(is, pPath);
			return iter;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public CloseableIterator<CIMClass> enumerateClasses(CIMObjectPath pPath, boolean pDeep,
			boolean pPropagated, boolean pIncludeQualifiers, boolean pIncludeClassOrigin)
			throws WBEMException {

		final String operation = "EnumerateClasses";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pPath == null || pPath.getNamespace() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pPath.getNamespace(), "UTF-8", "US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.enumerateClasses_request(doc,
					pPath, pDeep, pPropagated, pIncludeQualifiers, pIncludeClassOrigin));

			InputStreamReader is = transmitRequest("EnumerateClasses", hh, doc);

			CloseableIterator<CIMClass> iter = getIterator(is, pPath);
			return iter;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public CloseableIterator<CIMObjectPath> enumerateInstanceNames(CIMObjectPath pPath)
			throws WBEMException {

		final String operation = "EnumerateInstanceNames";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pPath == null || pPath.getNamespace() == null || pPath.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pPath.getNamespace(), "UTF-8", "US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.enumerateInstanceNames_request(
					doc, pPath));

			InputStreamReader is = transmitRequest("EnumerateInstanceNames", hh, doc);

			CloseableIterator<CIMObjectPath> iter = getIterator(is, pPath);
			return iter;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public CloseableIterator<CIMInstance> enumerateInstances(CIMObjectPath pPath, boolean pDeep,
			boolean pPropagated, boolean pIncludeClassOrigin, String[] pPropertyList)
			throws WBEMException {

		final String operation = "EnumerateInstances";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pPath == null || pPath.getNamespace() == null || pPath.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pPath.getNamespace(), "UTF-8", "US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.enumerateInstances_request(doc,
					pPath, pDeep, pPropagated, false, pIncludeClassOrigin, pPropertyList));

			InputStreamReader is = transmitRequest("EnumerateInstances", hh, doc);

			CloseableIterator<CIMInstance> iter = getIterator(is, pPath);
			return iter;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public CloseableIterator<CIMQualifierType<?>> enumerateQualifierTypes(CIMObjectPath pPath)
			throws WBEMException {

		final String operation = "EnumerateQualifiers";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			// enumerateQualifierTypes does not need class name, as it lists all
			// qualifiers in namespace
			if (pPath == null || pPath.getNamespace() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pPath.getNamespace(), "UTF-8", "US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.enumQualifierTypes_request(doc,
					pPath));

			InputStreamReader is = transmitRequest("EnumerateQualifiers", hh, doc);

			CloseableIterator<CIMQualifierType<?>> iter = getIterator(is, pPath);
			return iter;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public CloseableIterator<CIMInstance> execQuery(CIMObjectPath pPath, String pQuery,
			String pQueryLanguage) throws WBEMException {

		final String operation = "ExecQuery";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pPath == null || pPath.getNamespace() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pPath.getNamespace(), "UTF-8", "US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.execQuery_request(doc, pPath,
					pQuery, pQueryLanguage));

			InputStreamReader is = transmitRequest("ExecQuery", hh, doc);

			CloseableIterator<CIMInstance> iter = getIterator(is, pPath);
			return iter;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public CIMClass getClass(CIMObjectPath pName, boolean pPropagated, boolean pIncludeQualifiers,
			boolean pIncludeClassOrigin, String[] pPropertyList) throws WBEMException {

		final String operation = "GetClass";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pName == null || pName.getNamespace() == null || pName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pName.getNamespace(), "UTF-8", "US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.getClass_request(doc, pName,
					pPropagated, pIncludeQualifiers, pIncludeClassOrigin, pPropertyList));

			InputStreamReader is = transmitRequest("GetClass", hh, doc);

			CloseableIterator<?> iter = getIterator(is, pName);
			try {
				if (iter.hasNext()) { return (CIMClass) iter.next(); }
			} finally {
				iter.close();
			}

			return null;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public CIMInstance getInstance(CIMObjectPath pName, boolean pPropagated,
			boolean pIncludeClassOrigin, String[] pPropertyList) throws WBEMException {

		final String operation = "GetInstance";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pName == null || pName.getNamespace() == null || pName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pName.getNamespace(), "UTF-8", "US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.getInstance_request(doc, pName,
					pPropagated, false, pIncludeClassOrigin, pPropertyList));

			InputStreamReader is = transmitRequest("GetInstance", hh, doc);

			CloseableIterator<?> iter = getIterator(is, pName);
			try {
				if (iter.hasNext()) {
					CIMInstance result = (CIMInstance) iter.next();
					return new CIMInstance(pName, result.getProperties());
				}
			} finally {
				iter.close();
			}

			return null;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public CIMQualifierType<?> getQualifierType(CIMObjectPath pName) throws WBEMException {

		final String operation = "GetQualifier";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pName == null || pName.getNamespace() == null || pName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pName.getNamespace(), "UTF-8", "US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.getQualifier_request(doc, pName,
					pName.getObjectName()));

			InputStreamReader is = transmitRequest("GetQualifier", hh, doc);

			CloseableIterator<?> iter = getIterator(is, pName);
			try {
				if (iter.hasNext()) { return (CIMQualifierType<?>) iter.next(); }
			} finally {
				iter.close();
			}

			return null;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public Object invokeMethod(CIMObjectPath pName, String pMethodName,
			CIMArgument<?>[] pInputArguments, CIMArgument<?>[] pOutputArguments)
			throws WBEMException {

		final String operation = "InvokeMethod";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pName == null || pName.getNamespace() == null || pName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(MOF.objectHandle(pName, false, true),
					"UTF-8", "US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.invokeMethod_request(doc, pName,
					pMethodName, pInputArguments));

			InputStreamReader is = transmitRequest(pMethodName, hh, doc);

			CIMResponse response = null;
			String parser = this.iConfiguration.getCimXmlParser();
			// TODO: set the local namespace for parsers
			if (WBEMConstants.SAX.equals(parser) || WBEMConstants.PULL.equals(parser)) { return SAXHelper
					.parseInvokeMethodResponse(is, pOutputArguments, null); }
			// DOM parser
			response = getSingleResponse(is, null);
			response.checkError();
			List<Object> resultSet = response.getFirstReturnValue();

			Object rc = resultSet.size() > 0 ? resultSet.get(0) : null;

			List<Object> outParamValues = response.getParamValues();
			if (pOutputArguments != null && outParamValues != null) {
				Iterator<Object> itr = outParamValues.iterator();
				for (int i = 0; i < pOutputArguments.length; i++)
					if (itr.hasNext()) {
						pOutputArguments[i] = (CIMArgument<?>) itr.next();
					} else {
						break;
					}
			}
			return rc;
		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public void modifyClass(CIMClass pClass) throws WBEMException {

		final String operation = "ModifyClass";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pClass == null || pClass.getObjectPath() == null
					|| pClass.getObjectPath().getNamespace() == null
					|| pClass.getObjectPath().getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pClass.getObjectPath().getNamespace(),
					"UTF-8", "US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.setClass_request(doc, pClass
					.getObjectPath(), pClass));

			InputStreamReader is = transmitRequest("ModifyClass", hh, doc);

			CloseableIterator<?> iter = getIterator(is, pClass.getObjectPath());
			try {
				iter.hasNext();
			} finally {
				iter.close();
			}

			return;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public void modifyInstance(CIMInstance pInst, String[] pPropertyList) throws WBEMException {
		final String operation = "ModifyInstance";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();
		checkState();
		if (pInst == null || pInst.getObjectPath() == null
				|| pInst.getObjectPath().getNamespace() == null
				|| pInst.getObjectPath().getObjectName() == null) { throw new WBEMException(
				WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }
		final CIMObjectPath path = pInst.getObjectPath();
		try {
			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(path.getNamespace(), "UTF-8", "US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.setInstance_request(doc, path,
					pInst, true, pPropertyList));
			InputStreamReader is = transmitRequest(operation, hh, doc);

			CloseableIterator<?> iter = getIterator(is, path);
			try {
				iter.hasNext();
			} finally {
				iter.close();
			}
			return;
		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public CloseableIterator<CIMClass> referenceClasses(CIMObjectPath pObjectName,
			String pResultClass, String pRole, boolean pIncludeQualifiers,
			boolean pIncludeClassOrigin, String[] pPropertyList) throws WBEMException {

		final String operation = "ReferenceClasses";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pObjectName == null || pObjectName.getNamespace() == null
					|| pObjectName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pObjectName.getNamespace(), "UTF-8",
					"US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.referenceClasses_request(doc,
					pObjectName, pResultClass, pRole, pIncludeQualifiers, pIncludeClassOrigin,
					pPropertyList));

			InputStreamReader is = transmitRequest("References", hh, doc);

			return getIterator(is, pObjectName);

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public CloseableIterator<CIMInstance> referenceInstances(CIMObjectPath pObjectName,
			String pResultClass, String pRole, boolean pIncludeClassOrigin, String[] pPropertyList)
			throws WBEMException {

		final String operation = "ReferenceInstances";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pObjectName == null || pObjectName.getNamespace() == null
					|| pObjectName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pObjectName.getNamespace(), "UTF-8",
					"US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.referenceInstances_request(doc,
					pObjectName, pResultClass, pRole, pIncludeClassOrigin, pPropertyList));

			InputStreamReader is = transmitRequest("References", hh, doc);

			return getIterator(is, pObjectName);

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public CloseableIterator<CIMObjectPath> referenceNames(CIMObjectPath pObjectName,
			String pResultClass, String pRole) throws WBEMException {

		final String operation = "ReferenceNames";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pObjectName == null || pObjectName.getNamespace() == null
					|| pObjectName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pObjectName.getNamespace(), "UTF-8",
					"US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.referenceNames_request(doc,
					pObjectName, pResultClass, pRole));

			InputStreamReader is = transmitRequest("ReferenceNames", hh, doc);

			CloseableIterator<CIMObjectPath> iter = getIterator(is, pObjectName);
			return iter;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public CloseableIterator references(CIMObjectPath pObjectName, String pResultClass,
			String pRole, boolean pIncludeQualifiers, boolean pIncludeClassOrigin,
			String[] pPropertyList) throws WBEMException {

		final String operation = "References";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pObjectName == null || pObjectName.getNamespace() == null
					|| pObjectName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pObjectName.getNamespace(), "UTF-8",
					"US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.references_request(doc,
					pObjectName, pResultClass, pRole, pIncludeQualifiers, pIncludeClassOrigin,
					pPropertyList));

			InputStreamReader is = transmitRequest("References", hh, doc);

			return getIterator(is, pObjectName);

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public void setLocales(Locale[] pLocales) throws UnsupportedOperationException {
		this.iLocales = (pLocales != null && pLocales.length > 0) ? pLocales
				: WBEMConstants.DEFAULT_LOCALES;
	}

	public void setQualifierType(CIMQualifierType<?> pQualifierType) throws WBEMException {

		final String operation = "SetQualifierType";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pQualifierType == null || pQualifierType.getObjectPath() == null
					|| pQualifierType.getObjectPath().getNamespace() == null
					|| pQualifierType.getObjectPath().getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pQualifierType.getObjectPath()
					.getNamespace(), "UTF-8", "US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();
			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.setQualifierType_request(doc,
					pQualifierType.getObjectPath(), pQualifierType));

			InputStreamReader is = transmitRequest("SetQualifierType", hh, doc);

			CloseableIterator<?> iter = getIterator(is, pQualifierType.getObjectPath());
			try {
				iter.hasNext();
			} finally {
				iter.close();
			}

			return;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public SocketFactory getCustomSocketFactory() {
		return this.iConfiguration.getCustomSocketFactory();
	}

	public void setCustomSocketFactory(SocketFactory pFactory) throws UnsupportedOperationException {
		this.iConfiguration.setCustomSocketFactory(pFactory);
	}

	private InputStreamReader transmitRequest(String pCimMethod, HttpHeader pHeader,
			Document pDocument) throws IOException, ProtocolException, WBEMException {

		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		HttpUrlConnection connection = null;

		// retry HTTP MPOST only if failure is more than 24 hours old
		if (this.iMPostFailed) {
			this.iCurrentTime = System.currentTimeMillis();
			if ((this.iCurrentTime - this.iMPostFailTime) > 24 * 60 * 60 * 1000) this.iMPostFailed = false;
		}
		boolean useMPost = this.iMPostFailed ? false : this.iConfiguration.isHttpMPost();
		int retries = this.iConfiguration.getHttpConnectRetriesCount();
		do {
			logger.trace(Level.FINE, "Attempting to connect.. number of attempts left:" + retries);

			// Disconnect existing connection to prevent object leak
			if (connection != null) {
				connection.disconnect();
			}
			connection = newConnection(pCimMethod, pHeader, useMPost);
			try {
				logger.trace(Level.FINE, "Connecting...");
				connection.connect();
			} catch (UnknownHostException e) {
				throw new WBEMException(WBEMException.CIM_ERR_FAILED, "Unknown host", null, e);
			} catch (SocketException e) {
				throw new WBEMException(WBEMException.CIM_ERR_FAILED, "Unable to connect", null, e);
			}

			OutputStream os = connection.getOutputStream();

			if (this.iConfiguration.isCimXmlTracingEnabled()) CIMClientXML_HelperImpl.dumpDocument(
					LogAndTraceBroker.getBroker().getXmlTraceStream(), pDocument); // debug
			CIMClientXML_HelperImpl.serialize(os, pDocument);
			os.flush();
			os.close();

			int resultCode = 200;
			try {
				resultCode = connection.getResponseCode();
			} catch (SocketException e) {
				connection.disconnect();
				throw new WBEMException(WBEMException.CIM_ERR_FAILED, "Unable to connect", null, e);
			} catch (SocketTimeoutException e) {
				connection.disconnect();
				throw new WBEMException(WBEMException.CIM_ERR_FAILED, "Connection timed out", null,
						e);
			}

			HttpHeader headers = parseHeaders(connection);
			String auth = connection.getRequestProperty("Authorization");
			if (auth != null) {
				this.iAuthorization = auth;
			}

			String cimError = headers.getField("CIMError");

			switch (resultCode) {
				// 200
				case HttpURLConnection.HTTP_OK:

					if (this.iConfiguration.isHttpContentLengthRetryEnabled()) {
						String contentLengthField = headers.getField("Content-length");
						if (contentLengthField != null && contentLengthField.trim().length() > 0) {
							int contentLength = Integer.parseInt(contentLengthField);
							int lengthToCheck = this.iConfiguration.getHttpContentLengthThreshold();

							if (contentLength < lengthToCheck) {
								logger.trace(Level.FINE, "Content Length below :" + lengthToCheck
										+ " ...retrying !");
								break;
							}
						}
					}

					String charset = getCharacterSet(headers);

					InputStream is = connection.getInputStream();
					OutputStream debugStream = LogAndTraceBroker.getBroker().getXmlTraceStream();
					if (this.iConfiguration.isCimXmlTracingEnabled() && debugStream != null) {
						is = new DebugInputStream(is, debugStream);
					}

					return new InputStreamReader(is, charset);

					// 500
				case HttpURLConnection.HTTP_INTERNAL_ERROR:
					logger.trace(Level.FINER, "Received HTTP Error 500 - HTTP_INTERNAL_ERROR");
					break;

				// 501
				case HttpURLConnection.HTTP_NOT_IMPLEMENTED:
					// TODO if there is an error with the default xml
					// encoder/decoder, load the correct version
					// The problem is that the CIMOM does not return the DTD
					// version, CIM version or Protocol Version
					// that is expecting
					String cimProtocolVersion = headers.getField("CIMProtocolVersion");
					if (cimProtocolVersion == null && cimError == null && useMPost) {
						logger
								.trace(Level.FINER,
										"Received HTTP Error 501 - HTTP NOT IMPLEMENTED - falling back to HTTP POST");
						this.iMPostFailTime = System.currentTimeMillis();
						useMPost = false;
						this.iMPostFailed = true;
						++retries;
						break;
					}
					if (cimProtocolVersion == null || cimProtocolVersion.length() == 0) {
						cimProtocolVersion = "1.0";
					}

					logger.trace(Level.FINER, "Received HTTP Error 501 - HTTP NOT IMPLEMENTED"
							+ (cimError != null ? " - " + cimError : ""));
					retries = 0;
					break;
				// 400
				case HttpURLConnection.HTTP_BAD_REQUEST:
					if (cimError != null) {
						logger.trace(Level.FINER, "Received HTTP Error 400 - BAD REQUEST - "
								+ cimError);
					} else {
						logger.trace(Level.FINER, "Received HTTP Error 400 - BAD REQUEST");
					}
					retries = 0;
					break;

				// 401
				case HttpURLConnection.HTTP_UNAUTHORIZED:
					logger
							.trace(Level.FINER,
									"Received HTTP Error 401 - UNAUTHORIZED. Throwing WBEMAuthenticationException!");
					connection.disconnect();
					throw new WBEMException(WBEMException.CIM_ERR_ACCESS_DENIED,
							"HTTP 401 - Unauthorized", null);

					// 403
				case HttpURLConnection.HTTP_FORBIDDEN:
					logger.trace(Level.FINER, "Received HTTP Error 403 - FORBIDDEN.");
					retries = 0;
					break;

				// 407
				case HttpURLConnection.HTTP_PROXY_AUTH:
					logger
							.trace(Level.FINER,
									"Received HTTP Error 407 - ERR PROXY AUTHENTICATION. Throwing CIMAuthenticationException!");
					connection.disconnect();
					throw new WBEMException(WBEMException.CIM_ERR_ACCESS_DENIED,
							"HTTP 407 - Err Proxy Authentication");

					// 405
				case HttpURLConnection.HTTP_BAD_METHOD:
					logger.trace(Level.FINER, "Received HTTP Error 405 - BAD METHOD.");
					retries = 0;
					break;

				// 505 Version Not Supported
				case 505:
					// 510 Not Extended
				case 510:
					logger.trace(Level.FINER, "Received HTTP Error " + resultCode
							+ " on M-POST. Retrying with POST.");
					if (useMPost) {
						this.iMPostFailTime = System.currentTimeMillis();
						useMPost = false;
						this.iMPostFailed = true;
						++retries;
					}
					break;

				default:
					logger
							.trace(Level.FINER,
									"No known HTTP error recognized. Retrying with POST.");
					if (useMPost) {
						this.iMPostFailTime = System.currentTimeMillis();
						useMPost = false;
						this.iMPostFailed = true;
						++retries;
					}
			}
		} while (retries-- > 0);

		// Benchmark.stopTransportTimer();
		String errorMsg = "HTTP "
				+ connection.getResponseCode()
				+ " - "
				+ connection.getResponseMessage()
				+ (connection.getHeaderField("CIMError") != null ? (", CIMError: " + connection
						.getHeaderField("CIMError")) : "");
		connection.disconnect();

		throw new WBEMException(WBEMException.CIM_ERR_FAILED, errorMsg);
	}

	private HttpUrlConnection newConnection(String pCimMethod, HttpHeader pHeader, boolean pUseMPost) {

		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		HttpUrlConnection connection = new HttpUrlConnection(this.iUri, this.iHttpClientPool,
				this.iAuthorizationHandler);
		if (pUseMPost) {
			connection.setRequestMethod(WBEMConstants.HTTP_MPOST);
		} else connection.setRequestMethod(WBEMConstants.HTTP_POST);
		connection.useHttp11("1.1".equals(this.iConfiguration.getHttpVersion()));

		String firstLocaleStr = this.iLocales[0].getLanguage();
		if (this.iLocales[0].getCountry().length() > 0) firstLocaleStr = firstLocaleStr + '-'
				+ this.iLocales[0].getCountry();
		String restLocaleStr = "";
		for (int i = 1; i < this.iLocales.length; i++) {
			if (this.iLocales[i] != null && this.iLocales[i].getLanguage().length() > 0) {
				restLocaleStr = restLocaleStr + ", " + this.iLocales[i].getLanguage();
				if (this.iLocales[i].getCountry().length() > 0) restLocaleStr = restLocaleStr + '-'
						+ this.iLocales[i].getCountry();
			}
		}

		connection.setDoOutput(true);
		connection.setDoInput(true);
		connection.setRequestProperty("Content-type", "application/xml; charset=\"utf-8\"");
		connection.setRequestProperty("Accept", "text/html, text/xml, application/xml");
		connection.setRequestProperty("Cache-Control", "no-cache");
		connection.setRequestProperty("Content-Language", firstLocaleStr);
		connection.setRequestProperty("Accept-Language", firstLocaleStr + restLocaleStr + ", *");
		if (this.iAuthorization != null) connection.setRequestProperty("Authorization",
				this.iAuthorization);

		String prefix = "";
		if (connection.getRequestMethod().equalsIgnoreCase(WBEMConstants.HTTP_MPOST)) {
			String ns = getNextNs();
			connection.setRequestProperty("Man", "http://www.dmtf.org/cim/mapping/http/v1.0;ns="
					+ ns);
			prefix = ns + "-";
		}
		connection.setRequestProperty(prefix + "CIMProtocolVersion", "1.0");

		connection.setRequestProperty(prefix + "CIMOperation", "MethodCall");

		try {
			connection.setRequestProperty(prefix + "CIMMethod", HttpHeader.encode(pCimMethod,
					"UTF-8", "US-ASCII"));
		} catch (UnsupportedEncodingException e) {
			logger.trace(Level.FINE, "Exception while encoding http header", e);
			connection.setRequestProperty(prefix + "CIMMethod", pCimMethod);
		}
		Iterator<Entry<HeaderEntry, String>> iter = pHeader.iterator();
		while (iter.hasNext()) {
			Entry<HeaderEntry, String> entry = iter.next();
			connection.setRequestProperty(prefix + entry.getKey().toString(), entry.getValue()
					.toString());
		}

		logger.exit();
		return connection;
	}

	private String getNextNs() {
		this.iNsCounter = (this.iNsCounter < 99) ? ++this.iNsCounter : 10;
		return String.valueOf(this.iNsCounter);
	}

	private HttpHeader parseHeaders(URLConnection pConnection) {
		String man = pConnection.getHeaderField("Man");
		String opt = pConnection.getHeaderField("Opt");
		HttpHeader headers = new HttpHeader();
		int i;
		String ns = null;

		HttpHeaderParser manOptHeader = null;
		if (man != null && man.length() > 0) manOptHeader = new HttpHeaderParser(man);
		else if (opt != null && opt.length() > 0) manOptHeader = new HttpHeaderParser(opt);
		if (manOptHeader != null) ns = manOptHeader.getValue("ns");

		if (ns != null) {
			i = 0;
			String key;
			while ((key = pConnection.getHeaderFieldKey(++i)) != null) {
				if (key.startsWith(ns + "-")) headers.addField(key.substring(3), pConnection
						.getHeaderField(i));
				else headers.addField(key, pConnection.getHeaderField(i));
			}
		} else {
			i = 0;
			String key;
			while ((key = pConnection.getHeaderFieldKey(++i)) != null) {
				headers.addField(key, pConnection.getHeaderField(i));
			}
		}

		return headers;
	}

	private String getCharacterSet(HttpHeader pHeader) {
		String contentType = pHeader.getField("Content-type");
		String charset = "UTF-8";
		if (contentType != null && contentType.length() > 0) {
			HttpHeaderParser contentTypeHeader = new HttpHeaderParser(contentType);
			charset = contentTypeHeader.getValue("charset", charset);
		}
		return charset;
	}

	/**
	 * getIterator : get generic CloseableIterator<T>
	 * 
	 * @param <T>
	 *            : Type Parameter
	 * @param pStream
	 *            : Input Stream Reader
	 * @param pPath
	 *            : CIMObjectPath
	 * @return generic CloseableIterator<T>
	 * @throws IOException
	 * @throws SAXException
	 * @throws ParserConfigurationException
	 * @throws WBEMException
	 */

	// :TODO : try to find solution of "unchecked" warning
	@SuppressWarnings("unchecked")
	private <T> CloseableIterator<T> getIterator(InputStreamReader pStream, CIMObjectPath pPath)
			throws IOException, SAXException, ParserConfigurationException, WBEMException {

		String parser = this.iConfiguration.getCimXmlParser();

		CloseableIterator<?> iter = null;

		if (WBEMConstants.SAX.equals(parser)) {
			iter = new CloseableIteratorSAX(pStream, pPath);
		} else if (WBEMConstants.PULL.equals(parser)) {
			iter = new CloseableIteratorPULL(pStream, pPath);
		} else if (WBEMConstants.DOM.equals(parser)) {
			iter = new CloseableIteratorDOM(pStream, pPath);
		} else {
			throw new IllegalArgumentException("Invalid CIM-XML parser configured (\"" + parser
					+ "\") ");
		}
		try {
			// check for CIMExceptions
			iter.hasNext();
			return (CloseableIterator<T>) iter;
		} catch (RuntimeException e) {
			iter.close();
			if (e.getCause() != null && e.getCause() instanceof WBEMException) { throw (WBEMException) e
					.getCause(); }
			throw e;
		}
	}

	private <T> EnumerateResponse<T> getEnumerateResponse(InputStreamReader pStream,
			CIMObjectPath pPath) throws IOException, SAXException, ParserConfigurationException,
			WBEMException {

		String parser = this.iConfiguration.getCimXmlParser();

		if (WBEMConstants.SAX.equals(parser)) return new EnumerateResponseSAX<T>(pStream, pPath)
				.getEnumResponse();
		else if (WBEMConstants.PULL.equals(parser)) return new EnumerateResponsePULL<T>(pStream,
				pPath).getEnumResponse();
		else if (WBEMConstants.DOM.equals(parser)) return new EnumerateResponseDOM<T>(pStream,
				pPath).getEnumResponse();

		throw new IllegalArgumentException("Invalid CIM-XML parser configured (\"" + parser
				+ "\") ");
	}

	private CIMResponse getSingleResponse(InputStreamReader pStream, CIMObjectPath pLocalPath)
			throws WBEMException {
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		Document dom;
		try {
			// Using factory get an instance of document builder
			DocumentBuilder db = dbf.newDocumentBuilder();
			// parse using builder to get DOM representation of the XML file
			dom = db.parse(new InputSource(pStream));
		} catch (TrailerException e) {
			throw e.getWBEMException();
		} catch (Exception e) {
			String msg = "Exception occurred during DOM parsing!";
			logger.trace(Level.SEVERE, msg, e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, msg, null, e);
		}
		CIMXMLParserImpl.setLocalObjectPath(pLocalPath);
		CIMMessage cimMsg;
		try {
			cimMsg = CIMXMLParserImpl.parseCIM(dom.getDocumentElement());
		} catch (CIMXMLParseException e) {
			String msg = "Exception occurred during parseCIM!";
			logger.trace(Level.SEVERE, msg, e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, msg, null, e);
		}
		if (!(cimMsg instanceof CIMResponse)) {
			String msg = "CIM message must be response!";
			logger.trace(Level.SEVERE, msg);
			throw new WBEMException(msg);
		}
		return (CIMResponse) cimMsg;
	}

	public Properties getLocalProperties() {
		return this.iConfiguration.getLocalProperties();
	}

	public void setLocalProperties(Properties pProperties) {
		this.iConfiguration.setLocalProperties(pProperties);
	}

	public void setLocalProperty(String pKey, String pValue) {
		this.iConfiguration.setLocalProperty(pKey, pValue);
	}

	private synchronized void checkState() throws IllegalStateException {
		if (this.iInitialized && !this.iClosed) return;
		String state = this.iClosed ? "closed." : "not initialized.";
		LogAndTraceBroker.getBroker().trace(Level.FINE, "Illegal state for operation: " + state);
		throw new IllegalStateException("WBEMClient is " + state);
	}

	public EnumerateResponse<CIMObjectPath> associatorPaths(CIMObjectPath pObjectName,
			String pAssociationClass, String pResultClass, String pRole, String pResultRole,
			String pFilterQueryLanguage, String pFilterQuery, UnsignedInteger32 pTimeout,
			boolean pContinueOnError, UnsignedInteger32 pMaxObjects) throws WBEMException {

		final String operation = "OpenAssociatorInstancePaths";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pObjectName == null || pObjectName.getNamespace() == null
					|| pObjectName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pObjectName.getNamespace(), "UTF-8",
					"US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();

			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper
					.OpenAssociatorInstancePaths_request(doc, pObjectName, pAssociationClass,
							pResultClass, pRole, pResultRole, pFilterQueryLanguage, pFilterQuery,
							pTimeout, pContinueOnError, pMaxObjects));

			InputStreamReader is = transmitRequest(operation, hh, doc);

			EnumerateResponse<CIMObjectPath> enumResp = getEnumerateResponse(is, pObjectName);
			return enumResp;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public EnumerateResponse<CIMInstance> associators(CIMObjectPath pObjectName,
			String pAssocClass, String pResultClass, String pRole, String pResultRole,
			boolean pIncludeClassOrigin, String[] pPropertyList, String pFilterQueryLanguage,
			String pFilterQuery, UnsignedInteger32 pTimeout, boolean pContinueOnError,
			UnsignedInteger32 pMaxObjects) throws WBEMException {

		final String operation = "OpenAssociatorInstances";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pObjectName == null || pObjectName.getNamespace() == null
					|| pObjectName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pObjectName.getNamespace(), "UTF-8",
					"US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();

			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.OpenAssociatorInstances_request(
					doc, pObjectName, pAssocClass, pResultClass, pRole, pResultRole,
					pIncludeClassOrigin, pPropertyList, pFilterQueryLanguage, pFilterQuery,
					pTimeout, pContinueOnError, pMaxObjects));

			InputStreamReader is = transmitRequest(operation, hh, doc);

			EnumerateResponse<CIMInstance> enumResp = getEnumerateResponse(is, pObjectName);
			return enumResp;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public void closeEnumeration(CIMObjectPath pObjectName, String pEnumerationContext)
			throws WBEMException {

		final String operation = "CloseEnumeration";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pObjectName == null || pObjectName.getNamespace() == null
					|| pObjectName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pObjectName.getNamespace(), "UTF-8",
					"US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();

			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.CloseEnumeration_request(doc,
					pObjectName, pEnumerationContext));

			InputStreamReader is = transmitRequest(operation, hh, doc);

			CloseableIterator<CIMInstance> iter = getIterator(is, pObjectName);

			// Check for exceptions
			try {
				iter.hasNext();
			} finally {
				iter.close();
			}
		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}

	}

	public EnumerateResponse<CIMObjectPath> enumerateInstancePaths(CIMObjectPath pObjectName,
			String pFilterQueryLanguage, String pFilterQuery, UnsignedInteger32 pTimeout,
			boolean pContinueOnError, UnsignedInteger32 pMaxObjects) throws WBEMException {

		final String operation = "OpenEnumerateInstancePaths";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pObjectName == null || pObjectName.getNamespace() == null
					|| pObjectName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pObjectName.getNamespace(), "UTF-8",
					"US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();

			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper
					.OpenEnumerateInstancePaths_request(doc, pObjectName, pFilterQueryLanguage,
							pFilterQuery, pTimeout, pContinueOnError, pMaxObjects));

			InputStreamReader is = transmitRequest(operation, hh, doc);

			EnumerateResponse<CIMObjectPath> enumResp = getEnumerateResponse(is, pObjectName);
			return enumResp;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public EnumerateResponse<CIMInstance> enumerateInstances(CIMObjectPath pObjectName,
			boolean pDeepInheritance, boolean pIncludeClassOrigin, String[] pPropertyList,
			String pFilterQueryLanguage, String pFilterQuery, UnsignedInteger32 pTimeout,
			boolean pContinueOnError, UnsignedInteger32 pMaxObjects) throws WBEMException {

		final String operation = "OpenEnumerateInstances";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pObjectName == null || pObjectName.getNamespace() == null
					|| pObjectName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pObjectName.getNamespace(), "UTF-8",
					"US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();

			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.OpenEnumerateInstances_request(
					doc, pObjectName, pDeepInheritance, pIncludeClassOrigin, pPropertyList,
					pFilterQueryLanguage, pFilterQuery, pTimeout, pContinueOnError, pMaxObjects));

			InputStreamReader is = transmitRequest(operation, hh, doc);
			EnumerateResponse<CIMInstance> enumResp = getEnumerateResponse(is, pObjectName);
			return enumResp;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	// not supported yet
	public UnsignedInteger64 enumerationCount(CIMObjectPath pObjectName, String pEnumerationContext)
			throws WBEMException {
		final String operation = "EnumerationCount";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pObjectName == null || pObjectName.getNamespace() == null
					|| pObjectName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pObjectName.getNamespace(), "UTF-8",
					"US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();

			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.EnumerationCount_request(doc,
					pObjectName, pEnumerationContext));

			InputStreamReader is = transmitRequest(operation, hh, doc);
			// Currently this is not supported by server. Server returns
			// error : "CIM_ERR_NOT_SUPPORTED"
			// This error is caught by parser and exception is thrown

			getEnumerateResponse(is, pObjectName);
			// Error mentioned above will go away if server starts to support
			// EnumerationCount, we need to update code i.e. remove exception
			// and return UnsignedInteger64

			// this exception will be thrown only if server starts to support
			// enumerationCount
			throw new WBEMException(operation + " is currently not supported by client");

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public EnumerateResponse<CIMInstance> execQueryInstances(CIMObjectPath pObjectName,
			String pFilterQuery, String pFilterQueryLanguage, Boolean pReturnQueryResultClass,
			UnsignedInteger32 pTimeout, Boolean pContinueOnError, UnsignedInteger32 pMaxObjects,
			CIMClass pQueryResultClass) throws WBEMException {

		final String operation = "OpenQueryInstances";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pObjectName == null || pObjectName.getNamespace() == null
					|| pObjectName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pObjectName.getNamespace(), "UTF-8",
					"US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();

			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.OpenQueryInstances_request(doc,
					pObjectName, pFilterQuery, pFilterQueryLanguage, pReturnQueryResultClass,
					pTimeout, pContinueOnError, pMaxObjects, pQueryResultClass));

			InputStreamReader is = transmitRequest(operation, hh, doc);
			EnumerateResponse<CIMInstance> enumResp = getEnumerateResponse(is, pObjectName);
			return enumResp;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public EnumerateResponse<CIMObjectPath> getInstancePaths(CIMObjectPath pObjectName,
			String pContext, UnsignedInteger32 pMaxObjects) throws WBEMException {

		final String operation = "PullInstancePaths";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pObjectName == null || pObjectName.getNamespace() == null
					|| pObjectName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pObjectName.getNamespace(), "UTF-8",
					"US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();

			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.PullInstancePaths_request(doc,
					pObjectName, pContext, pMaxObjects));

			InputStreamReader is = transmitRequest(operation, hh, doc);
			EnumerateResponse<CIMObjectPath> enumResp = getEnumerateResponse(is, pObjectName);
			return enumResp;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public EnumerateResponse<CIMInstance> getInstances(CIMObjectPath pObjectName, String pContext,
			UnsignedInteger32 pMaxObjects) throws WBEMException {

		final String operation = "PullInstances";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pObjectName == null || pObjectName.getNamespace() == null
					|| pObjectName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pObjectName.getNamespace(), "UTF-8",
					"US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();

			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.PullInstances_request(doc,
					pObjectName, pContext, pMaxObjects));

			InputStreamReader is = transmitRequest(operation, hh, doc);
			EnumerateResponse<CIMInstance> enumResp = getEnumerateResponse(is, pObjectName);
			return enumResp;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public EnumerateResponse<CIMInstance> getInstancesWithPath(CIMObjectPath pObjectName,
			String pContext, UnsignedInteger32 pMaxObjects) throws WBEMException {

		final String operation = "PullInstancesWithPath";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pObjectName == null || pObjectName.getNamespace() == null
					|| pObjectName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pObjectName.getNamespace(), "UTF-8",
					"US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();

			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.PullInstancesWithPath_request(
					doc, pObjectName, pContext, pMaxObjects));

			InputStreamReader is = transmitRequest(operation, hh, doc);
			EnumerateResponse<CIMInstance> enumResp = getEnumerateResponse(is, pObjectName);
			return enumResp;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public EnumerateResponse<CIMObjectPath> referencePaths(CIMObjectPath pObjectName,
			String pResultClass, String pRole, String pFilterQueryLanguage, String pFilterQuery,
			UnsignedInteger32 pTimeout, boolean pContinueOnError, UnsignedInteger32 pMaxObjects)
			throws WBEMException {

		final String operation = "OpenReferenceInstancePaths";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {
			if (pObjectName == null || pObjectName.getNamespace() == null
					|| pObjectName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pObjectName.getNamespace(), "UTF-8",
					"US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();

			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper
					.OpenReferenceInstancePaths_request(doc, pObjectName, pResultClass, pRole,
							pFilterQueryLanguage, pFilterQuery, pTimeout, pContinueOnError,
							pMaxObjects));

			InputStreamReader is = transmitRequest(operation, hh, doc);
			EnumerateResponse<CIMObjectPath> enumResp = getEnumerateResponse(is, pObjectName);
			return enumResp;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}

	public EnumerateResponse<CIMInstance> references(CIMObjectPath pObjectName,
			String pResultClass, String pRole, boolean pIncludeClassOrigin, String[] pPropertyList,
			String pFilterQueryLanguage, String pFilterQuery, UnsignedInteger32 pTimeout,
			boolean pContinueOnError, UnsignedInteger32 pMaxObjects) throws WBEMException {

		final String operation = "OpenReferenceInstances";
		final LogAndTraceBroker logger = LogAndTraceBroker.getBroker();
		logger.entry();

		checkState();

		try {

			if (pObjectName == null || pObjectName.getNamespace() == null
					|| pObjectName.getObjectName() == null) { throw new WBEMException(
					WBEMException.CIM_ERR_INVALID_PARAMETER, "Invalid object path"); }

			HttpHeader hh = new HttpHeader();
			hh.addField("CIMObject", HttpHeader.encode(pObjectName.getNamespace(), "UTF-8",
					"US-ASCII"));

			Document doc = this.iXmlHelper.newDocument();

			this.iXmlHelper.createCIMMessage(doc, this.iXmlHelper.OpenReferenceInstances_request(
					doc, pObjectName, pResultClass, pRole, pIncludeClassOrigin, pPropertyList,
					pFilterQueryLanguage, pFilterQuery, pTimeout, pContinueOnError, pMaxObjects));

			InputStreamReader is = transmitRequest(operation, hh, doc);
			EnumerateResponse<CIMInstance> enumResp = getEnumerateResponse(is, pObjectName);
			return enumResp;

		} catch (WBEMException e) {
			logger.trace(Level.FINE, operation + " request resulted in CIM Error", e);
			throw e;
		} catch (Exception e) {
			if (e.getCause() != null && e.getCause() instanceof WBEMException) {
				logger
						.trace(Level.FINE, operation + " request resulted in CIM Error", e
								.getCause());
				throw (WBEMException) e.getCause();
			}
			logger.trace(Level.FINE, operation + " request failed", e);
			throw new WBEMException(WBEMException.CIM_ERR_FAILED, null, null, e);
		} finally {
			logger.exit();
		}
	}
}
