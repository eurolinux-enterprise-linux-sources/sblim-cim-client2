/**
 * ThreadPool.java
 *
 * (C) Copyright IBM Corp. 2005, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Roberto Pineiro, IBM, roberto.pineiro@us.ibm.com  
 * @author : Chung-hao Tan, IBM, chungtan@us.ibm.com
 * 
 * 
 * Change History
 * Flag       Date        Prog         Description
 *------------------------------------------------------------------------------- 
 * 1535756    2006-08-07  lupusalex    Make code warning free
 * 1565892    2006-11-28  lupusalex    Make SBLIM client JSR48 compliant
 * 1649779    2007-02-01  lupusalex    Indication listener threads freeze
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2531371    2009-02-10  raman_arora  Upgrade client to JDK 1.5 (Phase 2) 
 */
package org.sblim.cimclient.internal.util;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;

import org.sblim.cimclient.internal.logging.LogAndTraceBroker;

/**
 * Class ThreadPool implements a pool that manages threads and executes
 * submitted tasks using this threads.
 * 
 */
public class ThreadPool {

	/**
	 * Class Worker implements a worker thread used by the thread pool
	 * 
	 */
	private static class Worker extends Thread {

		private boolean iAlive = true;

		private boolean iStarted;

		private ThreadPool iPool;

		private Runnable iTask;

		private long iIdleTimeout;

		private boolean iTimedOut = false;

		/**
		 * Ctor.
		 * 
		 * @param pool
		 *            The owning pool
		 * @param name
		 *            The name of the thread
		 */
		public Worker(ThreadPool pool, String name) {
			super(pool.getGroup(), name);
			this.iPool = pool;
			setDaemon(true);
		}

		@Override
		public synchronized void start() {
			this.iStarted = true;
			this.iAlive = true;
			super.start();
		}

		/**
		 * Kills the thread
		 */
		public synchronized void kill() {
			this.iAlive = false;
			this.iStarted = false;
			notify();
		}

		/**
		 * Assigns a new task to the thread
		 * 
		 * @param task
		 *            The task
		 * @return <code>true</code> if the task could be successfully assigned.
		 */
		public synchronized boolean assignTask(Runnable task) {
			if (this.iAlive) {
				this.iTask = task;
				if (!this.iStarted) {
					start();
				} else {
					notify();
				}
				return true;
			}
			return false;
		}

		/**
		 * Returns the idle timeout
		 * 
		 * @return The idle timeout
		 */
		public long getIdleTimeout() {
			return this.iIdleTimeout;
		}

		/**
		 * Set the idle timeout
		 * 
		 * @param pIdleTimeout
		 *            The new value
		 */
		public void setIdleTimeout(long pIdleTimeout) {
			this.iIdleTimeout = pIdleTimeout;
		}

		/**
		 * Waits for a new task execute
		 * 
		 * @return The task or <code>null</code>
		 */
		private synchronized Runnable waitForTask() {
			if (this.iTask != null) {
				Runnable tsk = this.iTask;
				this.iTask = null;
				return tsk;
			}
			this.iAlive = this.iPool.taskCompleted(this, this.iTimedOut);
			if (this.iAlive && (this.iTask == null)) {
				try {
					long idleTimeOut = getIdleTimeout();
					if (idleTimeOut > 0) {
						wait(idleTimeOut);
						this.iTimedOut = (this.iTask == null);
					} else {
						wait();
					}
				} catch (InterruptedException e) {
					// this is expected
				}
			}
			return null;
		}

		@Override
		public void run() {
			while (this.iAlive) {
				Runnable tsk = waitForTask();
				if (tsk != null) {
					try {
						tsk.run();
					} catch (Throwable t) {
						LogAndTraceBroker.getBroker().trace(Level.FINE,
								"Exception while executing task from thread pool", t);
					}
				}
			}
			this.iStarted = false;
			this.iPool.removeThread(this);
		}
	}

	private ThreadGroup iGroup;

	private List<Worker> iIdleThreads = new LinkedList<Worker>();

	private List<Worker> iThreadPool = new LinkedList<Worker>();

	private List<Runnable> iQueue = new LinkedList<Runnable>();

	private long iIdleTimeout;

	private int iMaxPoolSize;

	private int iMinPoolSize;

	private int iToleratedBacklog;

	private int iCntr = 0;

	private boolean iShutdown = false;

	private String iWorkerName;

	/**
	 * Ctor
	 * 
	 * @param pMinPoolSize
	 *            The minimal pool size. The pool will always keep at least this
	 *            number of worker threads alive even in no load situations.
	 * @param pMaxPoolSize
	 *            The maximal pool size. The pool will create up to that number
	 *            of worker threads on heavy load.
	 * @param pToleratedBacklog
	 *            The task backlog that is tolerated before an additional worker
	 *            is created
	 * @param pToleratedIdle
	 *            The idle time of a worker that is tolerated before the worker
	 *            is destroyed
	 * @param pGroup
	 *            Then thread group to put the worker threads in
	 * @param pWorkerName
	 *            The name to use for worker threads
	 */
	public ThreadPool(int pMinPoolSize, int pMaxPoolSize, int pToleratedBacklog,
			long pToleratedIdle, ThreadGroup pGroup, String pWorkerName) {
		this.iGroup = pGroup != null ? pGroup : new ThreadGroup("TreadPool Group");
		this.iMinPoolSize = pMinPoolSize;
		this.iMaxPoolSize = pMaxPoolSize;
		this.iToleratedBacklog = pToleratedBacklog;
		this.iIdleTimeout = pToleratedIdle;
		this.iWorkerName = pWorkerName != null ? pWorkerName : "Worker ";

		for (int i = 0; i < pMinPoolSize; ++i) {
			Worker worker = new Worker(this, this.iWorkerName + getID());
			this.iThreadPool.add(worker);
			worker.start();
		}
	}

	/**
	 * Returns the idle timeout
	 * 
	 * @return The timeout
	 */
	public synchronized long getIdleTimeOutMs() {
		return (this.iThreadPool.size() <= this.iMinPoolSize) ? -1 : this.iIdleTimeout;
	}

	/**
	 * Submits a task for execution
	 * 
	 * @param task
	 *            The task
	 * @param enqueue
	 *            if <code>true</code> the task will be enqueued if no worker is
	 *            free, otherwise the task is executed immediately or not at
	 *            all.
	 * @return <code>true</code> if the task was executed or enqueued,
	 *         <code>false</code> otherwise.
	 */
	public synchronized boolean execute(Runnable task, boolean enqueue) {
		if (this.iShutdown) return false;

		int totalIdle = this.iIdleThreads.size();
		if (totalIdle > 0) {
			// takes the last one that came back, so that the older ones have a
			// chance to timeout
			Worker worker = this.iIdleThreads.remove(totalIdle - 1);
			return worker.assignTask(task);
		}

		// is maximal pool size reached ?
		boolean mayCreateWorker = (this.iMaxPoolSize == -1)
				|| (this.iThreadPool.size() <= this.iMaxPoolSize);
		if (enqueue) {
			this.iQueue.add(task);
			// create a new worker when backlog exceeds toleration level or we
			// have no workers at all
			if (mayCreateWorker
					&& ((this.iQueue.size() > this.iToleratedBacklog) || this.iThreadPool.size() == 0)) {
				Worker worker = createWorker();
				worker.assignTask(this.iQueue.remove(0));
			}
			return true;
		} else if (mayCreateWorker) {
			Worker worker = createWorker();
			return worker.assignTask(task);
		}
		return false;
	}

	/**
	 * Creates a new worker thread
	 * 
	 * @return The worker thread
	 */
	private Worker createWorker() {
		Worker worker = new Worker(this, this.iWorkerName + getID());
		this.iThreadPool.add(worker);
		return worker;
	}

	/**
	 * Gets the associated thread group
	 * 
	 * @return The thread group
	 */
	protected ThreadGroup getGroup() {
		return this.iGroup;
	}

	/**
	 * Used by the worker to report task completion and ask for a new task
	 * 
	 * @param worker
	 *            The worker
	 * @param timedOut
	 *            <code>true</code> if the worker has been idle and reached
	 *            timeout
	 * @return <code>true</code> if the worker shall stay alive,
	 *         <code>false</code> if it shall shut down itself
	 */
	public synchronized boolean taskCompleted(Worker worker, boolean timedOut) {
		if (this.iShutdown) return false;

		if (this.iQueue.size() > 0) {
			this.iIdleThreads.remove(worker);
			worker.assignTask(this.iQueue.remove(0));
			return true;
		} else if (timedOut && (this.iThreadPool.size() > this.iMinPoolSize)) {
			this.iIdleThreads.remove(worker);
			this.iThreadPool.remove(worker);
			return false;
		}
		if (!this.iIdleThreads.contains(worker)) {
			this.iIdleThreads.add(worker);
		}
		worker.setIdleTimeout(getIdleTimeOutMs());
		return true;
	}

	/**
	 * Removes a worker from the pool.
	 * 
	 * @param worker
	 *            The worker
	 */
	protected synchronized void removeThread(Worker worker) {
		if (worker != null && this.iThreadPool != null) this.iThreadPool.remove(worker);
	}

	/**
	 * Shuts down the thread pool and all workers
	 */
	public synchronized void shutdown() {
		if (!this.iShutdown) {
			this.iShutdown = true;
			Iterator<Worker> iter;
			if (this.iIdleThreads != null) {
				iter = this.iIdleThreads.iterator();
				while (iter.hasNext()) {
					Worker worker = iter.next();
					worker.kill();
				}
				this.iIdleThreads = null;
			}

			if (this.iThreadPool != null) {
				iter = this.iThreadPool.iterator();
				while (iter.hasNext()) {
					Worker worker = iter.next();
					worker.kill();
				}
				this.iThreadPool = null;
			}
		}
	}

	/**
	 * Generates an &quot;unique&quot; id for a worker thread
	 * 
	 * @return The id
	 */
	private String getID() {
		if (++this.iCntr >= 10000) this.iCntr = 1;
		return String.valueOf(this.iCntr);
	}

}
