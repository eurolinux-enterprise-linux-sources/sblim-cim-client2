/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Endre Bak, IBM, ebak@de.ibm.com
 * 
 * Change History
 * Flag       Date        Prog         Description
 *------------------------------------------------------------------------------- 
 * 1745282    2007-06-29  ebak         Uniform time stamps for log files
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 */

package org.sblim.cimclient.internal.logging;

import java.util.Calendar;

/**
 * Class TimeStamp is responsible for building uniform date/time strings for
 * logging and tracing.
 * 
 */
public class TimeStamp {

	private static String pad(int pDigits, int pNum) {
		String str = Integer.toString(pNum);
		int len = Math.max(pDigits, str.length());
		char[] cA = new char[len];
		int paddingDigits = pDigits - str.length();
		int dIdx = 0;
		while (dIdx < paddingDigits)
			cA[dIdx++] = '0';
		int sIdx = 0;
		while (dIdx < len)
			cA[dIdx++] = str.charAt(sIdx++);
		return new String(cA);
	}

	/**
	 * format
	 * 
	 * @param pMillis
	 *            - total milliseconds
	 * @return formatted date/time String. ( YYYY.MM.DD HH:mm:SS )
	 */
	public static String format(long pMillis) {
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(pMillis);
		return Integer.toString(cal.get(Calendar.YEAR)) + '.' + pad(2, cal.get(Calendar.MONTH) + 1)
				+ '.' + pad(2, cal.get(Calendar.DAY_OF_MONTH)) + ' '
				+ pad(2, cal.get(Calendar.HOUR_OF_DAY)) + ':' + pad(2, cal.get(Calendar.MINUTE))
				+ ':' + pad(2, cal.get(Calendar.SECOND));
	}

}
