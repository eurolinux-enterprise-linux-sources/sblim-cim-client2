/**
 * (C) Copyright IBM Corp. 2006, 2009
 *
 * THIS FILE IS PROVIDED UNDER THE TERMS OF THE ECLIPSE PUBLIC LICENSE 
 * ("AGREEMENT"). ANY USE, REPRODUCTION OR DISTRIBUTION OF THIS FILE 
 * CONSTITUTES RECIPIENTS ACCEPTANCE OF THE AGREEMENT.
 *
 * You can obtain a current copy of the Eclipse Public License from
 * http://www.opensource.org/licenses/eclipse-1.0.php
 *
 * @author : Alexander Wolf-Reber, IBM, a.wolf-reber@de.ibm.com
 * 
 * Change History
 * Flag       Date        Prog         Description
 *------------------------------------------------------------------------------- 
 * 1565892    2006-11-28  lupusalex    Make SBLIM client JSR48 compliant
 * 1715482    2007-05-10  lupusalex    CIM_ERR_FAILED thrown when access denied
 * 2003590    2008-06-30  blaschke-oss Change licensing from CPL to EPL
 * 2524131    2009-01-21  raman_arora  Upgrade client to JDK 1.5 (Phase 1)
 * 2903373    2009-11-24  blaschke-oss Java doc incorrect
 */

package org.sblim.cimclient;

/**
 * Class WBEMTransportException represents communication problems
 * 
 * @deprecated No more thrown anywhere. Replaced by
 *             <code>WBEMExpception(CIM_ERR_FAILED)</code>
 * 
 */
@Deprecated
public class WBEMTransportException extends RuntimeException {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 3079080300352602377L;

	/**
	 * Server name could not be resolved
	 * 
	 * @deprecated
	 */
	@Deprecated
	public static int EXT_ERR_UNKNOWN_SERVER = 1;

	/**
	 * Unable to connect to server.
	 * 
	 * @deprecated
	 */
	@Deprecated
	public static int EXT_ERR_UNABLE_TO_CONNECT = 2;

	/**
	 * Connection timed out
	 * 
	 * @deprecated
	 */
	@Deprecated
	public static int EXT_ERR_TIME_OUT = 3;

	private int iId;

	/**
	 * Ctor.
	 * 
	 * @param pExtendedId
	 *            One of the id constants in this class
	 * @param pMessage
	 *            The corresponding message
	 * @deprecated
	 */
	@Deprecated
	public WBEMTransportException(int pExtendedId, String pMessage) {
		super(pMessage);
		this.iId = pExtendedId;
	}

	/**
	 * Ctor.
	 * 
	 * @param pExtendedId
	 *            One of the id constants in this class
	 * @deprecated
	 */
	@Deprecated
	public WBEMTransportException(int pExtendedId) {
		super();
		this.iId = pExtendedId;
	}

	/**
	 * Ctor.
	 * 
	 * @param pExtendedId
	 *            One of the id constants in this class
	 * @param pMessage
	 *            The corresponding message
	 * @param pCause
	 *            The corresponding exception
	 * @deprecated
	 */
	@Deprecated
	public WBEMTransportException(int pExtendedId, String pMessage, Throwable pCause) {
		super(pMessage, pCause);
		this.iId = pExtendedId;
	}

	/**
	 * Returns the extended id. This is one of the id constants in this class.
	 * 
	 * @return The value of extended id.
	 * @deprecated
	 */
	@Deprecated
	public int getId() {
		return this.iId;
	}

}
